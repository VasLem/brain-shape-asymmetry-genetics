function mydisp(flag,ss)
if (flag == 0);disp(ss);end
