% Hull: From a set of point coordinates, find convex hull.  Returns only hull
%       vertex points, disregarding non-vertex hull points.
%
%     Usage: [hullPts,hullIndex] = Hull(crds)
%
%        crds =      [n x 2] matrix of x,y point coordinates
%        ---------------------------------------------------------------
%        hullPts =   [h x 2] matrix of x,y hull coordinates
%        hullIndex = [h x 1] vector of indices to hull points in 'crds'
%

% Sedgewick, R. 1988  Algorithms, 2nd ed. Addison Wesley (Ch. 25).
%   Uses the package-wrapping algorithm.

% RE Strauss, 1/5/96
%   10/4/01 - changed 'continue' variable due to v6 usage.

function [hullPts,hullIndex] = Hull(crds)

  [n,p] = size(crds);
  if (p~=2)
    error('  Hull: only 2-dimensional hulls allowed');
  end;

  if (n<3)                            % Fewer than 3 points passed
    if (n==1)                           % Single point passed
      hullIndex = 1;
      hullPts = crds;
    else                                % Two points passed
      [m,miny] = min(crds(:,2));
      if (miny==1)
        hullIndex = [1 2 1]';
      else
        hullIndex = [2 1 2]';
      end;
      hullPts = crds(hullIndex,:);
    end;
    return;
  end;

  m = min(crds(:,2));                 % Find min y value ("canonical form")
  minPt = find(crds(:,2)==m);
  if (length(minPt)>1)                % If ties,
    xi = 1;                           %   find min x among set of min y's
    xiValue = crds(minPt(1),1);
    for i=2:length(minPt)
      if (crds(minPt(i),1) < xiValue)
        xi = i;
        xiValue = crds(minPt(i),1);
      end;
    end;
    minPt = minPt(xi);
  end;

  crds = [crds; crds(minPt,:)];       % Append min-y pt to end of coords
  seq = (1:n+1)';                     % Input sequence of points

  minAngle = 0;
  maxAngle = ThetaFn([0 0],[1 -eps]);
  nh = 0;

  contin = true;
  while (contin)
    if (nh>1 && all(crds(minPt,:)==crds(1,:)))
      contin = false;
    else
      nh = nh+1;                      % Update current hull point
      tPt = crds(nh,:);               % Switch current and min-angle points
      tSeq = seq(nh);
      crds(nh,:) = crds(minPt,:);
      seq(nh) = seq(minPt);
      crds(minPt,:) = tPt;
      seq(minPt) = tSeq;

      [angle,ident] = ThetaFn(crds(nh,:),crds((nh+1):(n+1),:)); % Get angles from hull pt
      angle = angle - minAngle;                                 % With respect to prev angle

      while (min(angle)<0)                          % Wrap negative angles around
        indx = find(angle<0);                       %   to positive
        angle(indx) = angle(indx) + maxAngle;
      end;

      indx = find(ident>0);                         % Disregard pts identical to hull pt
      angle(indx) = maxAngle * ones(length(indx),1);

      [ma,minPt] = min(angle);                      % Find min angle and point
%       prevminAngle = minAngle;
      minAngle = minAngle + ma;
      minPt = minPt + nh;
    end;
  end;

  hullIndex = [seq(1:nh); seq(1)];     % Stash point indices
  hullPts = [crds(1:nh,:); crds(1,:)]; % Coordinates of hull points

%  i = 0;
%  while (i < nh-2)
%    i = i+1;
%    hp = hullPts(i:(i+2),:);           % Check for colinear triplets of hull points
%    if (ptdir(hp)==0)                  % If found, delete the center one
%      hullPts(i+1,:) = [];
%      hullIndex(i+1) = [];
%      nh = nh-1;
%      i = i-1;
%    end;
%  end;

  return;
  
%% ---------------------------------------------------------------------------  
  
% ThetaFn: Returns value (0-360) having the same order properties as the angle
%         made by p0 & pt with respect to the horizontal; does not return the
%         actual angle.  Useful for angular sorting of points.  Returns a flag 
%         if point coordinates of p0 & pt are identical.
%
%     Syntax: [value,ident] = ThetaFn(p0,pt)
%
%         p0 =    [1 x 2] vector specifying reference-point coordinates
%         pt =    [n x 2] matrix specifying point coordinates
%         ----------------------------------------------------------------
%         value = [n x 1] vector of corresponding angular values
%         ident = [n x 1] vector of identity flags (TRUE [=1] if the point is 
%                   identical to p0, FALSE [=0] if not)
%

% RE Strauss, 1/29/96

% Sedgewick, R. 1988  Algorithms, 2nd ed. Addison Wesley (p. 353).

function [value,ident] = ThetaFn(p0,pt)
  n = size(pt,1);
  value = zeros(n,1);
  ident = zeros(n,1);

  for i = 1:n
    if (p0(1,:)==pt(i,:))
      value(i) = 0;
      ident(i) = 1;
    else
      dx = pt(i,1)-p0(1,1);
      ax = abs(dx);
      dy = pt(i,2)-p0(1,2);
      ay = abs(dy);

      if ((ax<eps) && (ay<eps))
        t = 0;
      else
        t = dy / (ax+ay);
      end;

      if (dx<0)
        t = 2-t;
      elseif (dy<0)
        t = 4+t;
      end;

      value(i) = t*90;
    end;
  end;

  return;

