% BetaBinomLogLikelihood: Returns the negative of the log-likelihood.
%
%     Usage: L = BetaBinomLogLikelihood(mu,theta,x,n)
%
%         mu,theta - alternate parameters of beta-binomial distribution (mu = p).
%         x - vector of counts of number of successes out of n trials.
%         n - corresponding vector of n; if a scalar, it is used for all x.
%         -----------------------------------------------------------------------
%         L - log-likelihood of data given parameters.
%

% Williams, DA. 1975. The analysis of binary responses from toxicological experiments
%   involving reproduction and teratogenicity.  Biometrics 31:949-952.
% Smith, DM. 1983. Maximum likelihood estimation of the parameters of the beta binomial
%   distribution. Algorithm AS 189.  Applied Statistics 32:196-204.

% RE Strauss, 11/7/08

function L = BetaBinomLogLikelihood(params,x,n)
  mu = params(1);
  theta = max([params(2),eps]);
  m = length(x);
  
  L = 0;
  for j = 1:m
    r = (0:(x(j)-1));
    L = L + sum(log(mu+r*theta));
    
    r = (0:(n(j)-x(j)-1));
    L = L + sum(log(1-mu+r*theta));
      
    r = (0:(n(j)-1));
    L = L - sum(log(1+r*theta));
  end;
  L = -L;
    
  return;
  
