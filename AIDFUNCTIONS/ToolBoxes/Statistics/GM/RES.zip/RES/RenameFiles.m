% RenameFiles: Sorts filenames within a specified directory into ascii collating sequence, and then
%     renames them in the form ppp999, where ppp is a fixed prefix and 999 represents a sequence of
%     counting numbers.
%
%   Usage: RenameFiles(directoryName,filePrefix,{nDigits})
%
%         directoryName = character string containing full directory name.
%         filePrefix =    character string containing prefix for all filenames.
%         nDigits =       optional number of digits for sequence numbers; default = sufficient for
%                           number of files in directory, minimum 2.
%

% RE Strauss, 7/13/06

function RenameFiles(directoryName,filePrefix,nDigits)
  if (nargin < 3), nDigits = []; end;
  
  minDigits = 2;
  
  files = dir(directoryName);                           % Return structure containing directory information
  if (isempty(files))
    error('  Invalid directory');
  end;
  
  filenames = char(files.name);                         % Place elements of cell array of strings into character matrix
  nFiles = size(filenames,1);                           % Number of files + directory entries
  
  isdirFlags = [];                                      % Construct boolean matrix of directory flags
  for i = 1:nFiles
    isdirFlags(i) = files(i).isdir;
  end;
  
%   i = find(isdirFlags == false);                        
  filenames = filenames(isdirFlags == false,:);         % Isolate filenames
  nFiles = size(filenames,1);
  filenames = SortCharMatrix(filenames);                % Sort filenames into ascii collaging sequence
  
  if (isempty(nDigits))                                 % Default number of digits
    nDigits = max([minDigits,ceil(log10(nFiles))]);
  end;
  
  photoNumber = 1;
  for i = 1:nFiles                                      % For all files in directory
    curFilename = [directoryName,filesep,filenames(i,:)]; % Get current filename
    pos = findstr(curFilename,'.')+1;                     % Isolate extension
    extension = lower(curFilename(pos:end));
    
    digits = char('0'*ones(1,nDigits));                   % Create string with number right justified & with leading zeros
    value = int2str(photoNumber);
    pos = nDigits-length(value)+1;
    digits(pos:end) = value;
    
    newFilename = [directoryName,filesep,filePrefix,digits,'.',extension];
    renameSuccessful = movefile(curFilename,newFilename);
    if (renameSuccessful)
      disp(sprintf('  Changed %s to %s',curFilename,newFilename));
      photoNumber = photoNumber + 1;
    else
      disp(sprintf('  File %s not renamed',curFilename));
    end;
  end;

  return;
  
  
