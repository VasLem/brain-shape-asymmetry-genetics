% NormalMixtureFit: fits a mixture of normal distributions multivariate data.
%     Number and types of plots depends on number of variables in data matrix.
%
%     Usage: [fitingCriteria,optResults] = ...
%                           NormalMixtureFit(dataX,{nComponents},{criterion},{noPlots})
%
%         dataX = [n x p] data matrix.
%         nComponents = optional vector of numbers of distributions to fit 
%                       [default = 1:4].
%         criterion = optimality criterion for optimal number of components:
%                       'aic' = Akaike information criterion [default].
%                       'bic' = Bayesian information criterion.
%                       'lik' = log-likelihood.
%         noPlots = optional boolean flag indicating, if true, that plots are to be
%                     suppressed [default = false].
%         ------------------------------------------------------------------------------
%         fittingCriteria = structure containing goodness-of-fit criteria:
%                     aic = vector of Akaike information-statistic values (minimized).
%                     bic = vector of Bayesian information-statistic values (minimized).
%                     logL = vector of log-likelihood statistic values (maximized).
%         optResults = structure containing results:
%                     criterion = optimality criterion.
%                     nOptComponents = k, the optimal number of fitted components.
%                     cMeans = [1 x k] vector of component means.
%                     cCovars = [k x k x k] matrix of covariance matrices (for >1 variable)
%                               or [1 x k] vector of variances (for 1 variable).
%                     mixture = [1 x k] vector of mixture proportions
%   

% RE Strauss, 1/18/11

function [fittingCriteria,optResults] = ...
                                    NormalMixtureFit(dataX,nComponents,criterion,noPlots)
                                    
  if (~nargin), help NormalMixtureFit; return; end;
  
  if (nargin < 2), nComponents = []; end;
  if (nargin < 3), criterion = []; end;
  if (nargin < 4), noPlots = []; end;
  
  if (isempty(nComponents)), nComponents = 1:4; end;
  if (isempty(criterion)),   criterion = 'aic'; end;
  if (isempty(noPlots)),     noPlots = false; end;
  
  if (isvector(dataX))
    dataX = dataX(:);
  end;
  
  [nObs,nVars] = size(dataX);
  nFittings = length(nComponents);
  
  obj =   cell(1,nFittings);
  aic =  zeros(1,nFittings);
  bic =  zeros(1,nFittings);
  logL = zeros(1,nFittings);
  
  options = statset('MaxIter',500);

  for k = 1:nFittings
    obj{k} = gmdistribution.fit(dataX,nComponents(k),'Options',options);
    aic(k)= obj{k}.AIC;
    bic(k) = obj{k}.BIC;
    logL(k) = -obj{k}.NlogL;
  end
  
  switch (lower(criterion))
    case 'aic', [optVal,k] = min(aic);
    case 'bic', [optVal,k] = min(bic);
    case 'lik', [optVal,k] = max(logL);
    otherwise
      error('  NormalMixtureFit: invalid optimization criterion');
  end;
  
  nOptComponents = nComponents(k);
  model = obj{k};

  cMeans = model.mu;
  cVars = model.Sigma;
  mixtureProportions = model.PComponents;
  
  fittingCriteria.aic = aic;                  % Save results into output structures
  fittingCriteria.bic = bic;
  fittingCriteria.logL = logL;
  
  optResults.criterion = criterion;
  optResults.nOptComponents = nOptComponents;
  optResults.cMeans = cMeans;
  optResults.cVars = cVars;
  optResults.mixture = mixtureProportions;
  
  if (~noPlots)
    if (nFittings>1)
      DoScatterplot(nComponents,aic,'AIC');
      DoScatterplot(nComponents,bic,'BIC');
      DoScatterplot(nComponents,logL,'Log-likelihood');
    end;
  
    if (nVars==1)
      DoPdfHistogram(dataX,model);
    elseif (nVars==2)
      yPdf = pdf(model,dataX);
      plotType = 4;
      figure;
      PlotSurface(dataX(:,1),dataX(:,2),yPdf,plotType);
      hold on;
      plot(dataX(:,1),dataX(:,2),'ko');
      putbnd(dataX);
      hold off;
    end;
  end;

  return;
  
%% ---------------------------------------------------------------------

function DoScatterplot(x,y,yLabel)
  Scatterplot(x,y);
  hold on;
  plot(x,y,'k');
  set(gca,'XTick',x);
  hold off;
  PutXLab('Number of components');
  PutYLab(yLabel);

  return;
  
%% ---------------------------------------------------------------------

function DoPdfHistogram(x,model)
  figure;
  [n,freqs] = Histgram(x,[],[],[],[],true,[],[],'w');
  xPred = freqs(:,1);
  yPred = freqs(:,2);

  xPdf = linspace(min(x)-1.05*range(x),max(x)+1.05*range(x),300)';
  yPdf = pdf(model,xPdf);
  
  yPdf = MatchPdfHistogram(xPred,yPred,xPdf,yPdf);

  hold on;
  plot(xPdf,yPdf,'k');
  PutYBnd(0,1.03*max(yPdf));

  hold off;

  return;
  
function yPdfScaled = MatchPdfHistogram(xPred,yPred,xPdf,yPdf)
  n = length(xPred);
  iPdfPred = zeros(1,n);
  
  % Find xPdf positions corresponding to histogram bar centers
  for i = 1:n
    [m,iPdfPred(i)] = min(abs(xPred(i)-xPdf));
  end;

  % Find optimal scaling factor for yPdf
  f = @(x)HistPdfDiff(x,yPred,yPdf(iPdfPred));      % Anonymous function
  options = optimset('LargeScale','off','Display','off');
  scaleFactor = fminunc(f,1,options);
  
  yPdfScaled = yPdf*scaleFactor;

  return;
  
function sse = HistPdfDiff(scaleFactor,yPred,yPdf)
  d = yPred-(yPdf.*scaleFactor);
  sse = d'*d;
  
  return;
