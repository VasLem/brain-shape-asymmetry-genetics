% ShortestPath: Finds shortest topological paths between nodes from an adjacency matrix of
%         inter-node distances using Disjkstra's algorithm.
%
%     Usage:  [shortestDist,paths] = ShortestPath(adjMat,{sourceNodes},{terminalNodes})
% 
%         adjMat -        square weighted adjacency matrix in which non-zero elements   
%                           represent lengths of existing links among pairs of nodes.  
%                           Matrix can be sparse.
%         sourceNodes -   optional vector of indices of source nodes 
%                         	[default = all nodes].
%         terminalNodes - optional vector of indices of terminal nodes
%                           [default = all nodes].
%         ---------------------------------------------------------------------------------
%         shortestDist - 	square symmetric matrix of shortest internode distances on graph.
%         paths -         [nNodes x LongestPath+2] matrix of paths between all
%                           connected pairs of nodes:
%                             cols 1:2 - node indices, with smaller value first.
%                             cols 3:end - indices of intermediate nodes, in sequence.
%

%  Ahuja, Magnanti, & Orlin. 1993. Network Flows. Prentice-Hall, p. 109 (Fig 4.6).

% RE Strauss, 5/11/08

function [shortestDist,nPaths,paths] = ShortestPath(adjMat,sourceNodes,terminalNodes)
  if (~nargin), help ShortestPath; return; end;
  
  if (nargin<2), sourceNodes = []; end;
  if (nargin<3), terminalNodes = []; end;
  
  getPaths = false;
  if (nargout>2), getPaths = true; end;
  
  [nNodes,cadjMat] = size(adjMat);

  if (isempty(sourceNodes)),   sourceNodes = (1:nNodes)'; end;
  if (isempty(terminalNodes)), terminalNodes = (1:nNodes)'; end;

  sourceNodes = sourceNodes(:);
  terminalNodes = terminalNodes(:);
  nSourceNodes = length(sourceNodes);
  nTerminalNodes = length(terminalNodes);

  if (nNodes~=cadjMat || any(any(adjMat<0)))
    error('  ShortestPath: a must be a non-negative square matrix');
  elseif (any(sourceNodes<1 | sourceNodes>nNodes))
    error(['  ShortestPath: ''sourceNodes'' must be integer between 1 and ',num2str(nNodes)]);
  elseif any(terminalNodes<1 | terminalNodes>nNodes)
    error(['  ShortestPath: ''terminalNodes'' must be integer between 1 and ',num2str(nNodes)]);
  end;

  adjMat = adjMat';		% Use transpose to speed-up find for sparse adjacency matrix

  shortestDist = zeros(nSourceNodes,nTerminalNodes);
  if (getPaths)
    prior = zeros(nSourceNodes,nNodes);
  end;

  for vi = 1:nSourceNodes
    v = sourceNodes(vi);
   
    di = Inf*ones(nNodes,1); 
    di(v) = 0;
   
    isVisited = false(nTerminalNodes,1);
    nVisited = 0;
    unVisited = 1:nNodes;
    isUnvisited = true(nNodes,1);
   
    while (nVisited<nNodes && ~all(isVisited))
      [dj,pos] = min(di(isUnvisited));
      v = unVisited(pos);     % Vertex selection
      unVisited(pos) = [];
      isUnvisited(v) = false;
      
      nVisited = nVisited+1;
      if (nTerminalNodes < nNodes)
        isVisited = (isVisited | (v==terminalNodes));
      end;
      
      [aj,ak,anz] = find(adjMat(:,v));
      anz(isnan(anz)) = 0;
            
      if (isempty(anz))
        distk = Inf; 
      else
        distk = dj + anz; 
      end;
      
      if (getPaths)
        prior(vi,aj(distk<di(aj))) = v;
      end;
      di(aj) = min(di(aj),distk);
    end;
    shortestDist(vi,:) = di(terminalNodes)';    
  end;
  
  nPaths = sum(isfinite(trilow(shortestDist)));
  
  if (getPaths)                              % Reconstruct paths from lists of prior nodes
    paths = sparse(nPaths,nNodes+2);
    longestPath = 0;
    nPairs = 0;
    for v1 = 1:(nNodes-1)                      % Cycle thru pairs of nodes
      for v2 = (v1+1):nNodes
        if (prior(v1,v2)>0)                         % If path exists, reconstruct backwards
          nPairs = nPairs+1;
          p = [];
          v = prior(v1,v2);
          while (v~=v1)
            p = [p,v]; %#ok<AGROW>
            v = prior(v1,v);
          end;
          pLen = length(p);
          paths(nPairs,1:(pLen+2)) = [v1,v2,fliplr(p)];
          if (pLen>longestPath)
            longestPath = pLen;
          end;
        end;
      end;
    end;
    paths = full(paths(1:nPairs,1:longestPath+2));
  end;

  return;
  
