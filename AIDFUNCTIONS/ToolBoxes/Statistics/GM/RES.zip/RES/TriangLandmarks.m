% TriangLandmarks: Calls Triangulate.m.

function [distSpecs,plotCrds] = TriangLandmarks(crds,specimens,distThreshold,...
                                      missRefPt,ptsIgnore,distsIgnore,pairedPts,averageBilat,noPlot)
  if (~nargin), help TriangLandmarks; return; end;

  if (nargin < 2), specimens = []; end;
  if (nargin < 3), distThreshold = []; end;
  if (nargin < 4), missRefPt = []; end;
  if (nargin < 5), ptsIgnore = []; end;
  if (nargin < 6), distsIgnore = []; end;
  if (nargin < 7), pairedPts = []; end;
  if (nargin < 8), averageBilat = []; end;
  if (nargin < 9), noPlot = []; end;
  
  [distSpecs,plotCrds] = Triangulate(crds,specimens,distThreshold,...
                                      missRefPt,ptsIgnore,distsIgnore,pairedPts,averageBilat,noPlot);
                                    
  return;

