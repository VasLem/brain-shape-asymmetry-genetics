% Classify: If "unknown" observations are provided, singly or in groups, classifies them into 
%           the "known" groups.  If only "known" groups are provided, reclassifies each 
%           observation into one of the known groups by jackknifing the observations.
%
%           In either case, classification is based on minimum Mahalanobis distances, either 
%           original or size-adjusted, and is based on the assumption that both known and 
%           unknown groups have identical covariance structures.  The training set can 
%           optionally be bootstrapped to estimate frequency distributions of classification.
%
%     Usage: [classifResults,percentCorrectClassif] = Classify(dataKnown,grpsKnown,...
%                                                {dataUnknown},{grpsUnknown},{sizeAdj},{nIters})
%
%           dataKnown = [n x p] data matrix (obs x vars) for the n "known" training 
%                       observations.
%           grpsKnown = [n x 1] corresponding vector of group identifiers for k groups.
%           dataUnknown = optional [m x p] data matrix for the m "unknown" observations.
%           grpsUnknown = optional vector of group identifiers for "unknown" 
%                       observations.  If passed, the unknowns are classified as 
%                       entire groups, based on Mahalanobis distances among group 
%                       centroids; if not passed, the unknowns are classified 
%                       individually based on Mahalanobis distances between 
%                       individuals and group centroids.
%           sizeAdj = optional boolean flag indicating, if true, that Mahalanobis 
%                       distances are to be based on residuals from a "size-free" 
%                       discriminant analysis [default = 0].
%           nIters =    optional number of bootstrap nItersations [default = 0].
%           --------------------------------------------------------------------------
%           classifResults = [n x k] matrix for the n "known" observations and k groups, or 
%                       [m x k] matrix for the m "unknown" observations and k training
%                       groups (if provided), specifying the proportion of times 
%                       (original solution + bootstrap nItersations) in which each 
%                       unknown (rows) is classified into one of the k groups 
%                       (cols).
%           percentCorrectClassif =[k x k] matrix of percent correct classifications, for known 
%                       groups, specifying percentage of time that observations 
%                       from known groups (rows) are reclassified into the same 
%                       or different groups (cols).
%           D2 =      [n x k] of jackknifed Mahalanobis distances of each "known"
%                       observation from each of the k group centroids, or [m x k]
%                       matrix of Mahalanobis distances of each "unknown" observation
%                       from each of the k group centroids.
%

% RE Strauss, 7/13/98
%   11/29/99 - changed calling sequence.
%   1/25/00 -  changed error messages; changed name of unique().
%   5/18/00 -  added calculations for percent correct classifications.
%   9/23/00 -  updated help documentation.
%   8/27/01 -  base percent correct classifications on bootstrapped results if nIters>0.
%   12/8/04 -  temporarily remove 'D2' (Mahalanobis distances) as output argument.
%   3/11/07 -  upgrade variable names; combine classify(), classifyk() and classifyu()
%                into single m.file.
%   9/10/08 - changed mahal() to MahalDist().

function [classifResults,percentCorrectClassif] = Classify(dataKnown,grpsKnown,dataUnknown,grpsUnknown,sizeAdj,nIters)
  if (nargin < 3), dataUnknown = []; end;
  if (nargin < 4), grpsUnknown = []; end;
  if (nargin < 5), sizeAdj = []; end;
  if (nargin < 6), nIters = []; end;
  
  if (isempty(nIters)),  nIters = 0; end;               % Default input argument values
  if (isempty(sizeAdj)), sizeAdj = 0; end;

  doClassifyUnknowns = false;
  doClassifyKnowns = false;
  if (isempty(dataUnknown))                             % Determine whether data on
    doClassifyKnowns = true;                            %   "unknowns" has been passed
  else
    [nUnknownObs,nUnknownVars] = size(dataUnknown);
    doClassifyUnknowns = true;
    grpsUnknown = grpsUnknown(:);
  end;
    
  [nKnownObs,nKnownVars] = size(dataKnown);
  grpsKnown = grpsKnown(:);
  uGrpsKnown = UniqueValues(grpsKnown);                	% Training-group identifiers
  nGrpsKnown = length(uGrpsKnown);

  if (length(grpsKnown) ~= nKnownObs)
    disp('  Classify: group vector and data matrix incompatible');
    disp('            for training observations');
    error(' ');
  end;

  percentCorrectClassif = [];
  
  if (doClassifyKnowns)                                 % Jackknife and reclassify 'known' obs
    classifResults = ClassifyKnowns(dataKnown,grpsKnown,uGrpsKnown,sizeAdj);
    binaryResults = classifResults;

    if (nIters)                                           % Bootstrap
      for it = 1:nIters
        bootsampDataKnown = bootsamp(dataKnown,grpsKnown);
        classifResults = classifResults + ClassifyKnowns(bootsampDataKnown,grpsKnown,uGrpsKnown,sizeAdj);
      end;
      classifResults = classifResults/(nIters+1);
      [m,pos] = max(classifResults,[],2);
      
      binaryResults = zeros(size(binaryResults));
      for ibr = 1:size(binaryResults,1)
        binaryResults(ibr,pos(ibr)) = 1;
      end;
    end;
    
    percentCorrectClassif = zeros(nGrpsKnown,nGrpsKnown);
    for i = 1:nGrpsKnown
      pos = find(grpsKnown == uGrpsKnown(i));
      percentCorrectClassif(i,:) = 100*sum(binaryResults(pos,:))/length(pos);
    end;
  end;

  if (doClassifyUnknowns)
    if (nKnownVars ~= nUnknownVars)
      disp('  Classify: numbers of variables for training and unknown observations');
      disp('            must be equal');
      error(' ');
    end;

    lenGrpsUnknown = length(grpsUnknown);
    if (lenGrpsUnknown > 0)
      if (lenGrpsUnknown ~= nUnknownObs)
        disp('  Classify: group vector and data matrix incompatible');
        disp('            for unknown observations');
        error(' ');
      end;
    else
      grpsUnknown = (1:nUnknownObs)';
    end;

    nGrpsKnown = length(uGrpsKnown);                    % Number of training groups
    maxUGrpsKnown = max(uGrpsKnown);                    % Max training-group label

    grpsUnknown = grpsUnknown + maxUGrpsKnown;          % Ensure that unknown grp-ids are unique
    uGrpsUnknown = UniqueValues(grpsUnknown);           % Groups of unknowns

    classifResults = ClassifyUnknowns(dataKnown,grpsKnown,dataUnknown,grpsUnknown,nGrpsKnown,uGrpsUnknown,sizeAdj);

    if (nIters)                                         % Bootstrap the training groups
      for it = 1:nIters
        bootsampDataKnown = bootsamp(dataKnown,grpsKnown);
        classifResults = classifResults + ClassifyUnknowns(bootsampDataKnown,grpsKnown,dataUnknown,grpsUnknown,nGrpsKnown,uGrpsUnknown,sizeAdj);
      end;
      classifResults = classifResults/(nIters+1);
    end;
  end;

  return;
  
% --------------------------------------------------------------------------------------------

% ClassifyKnowns: Classifies each of the "known" observations by jackknifing it and 
%           determining its group membership based on Mahalanobis distances.  
%           Called by classify().
%
%     Usage: classifResults = ClassifyKnowns(dataKnown,grpsKnown,grpvals,sizeAdj)
%
%           dataKnown =         [n x p] data matrix (obs x vars) for the n "known" training 
%                         observations.
%           grpsKnown =      [n x 1] column vector of group identifiers for k groups.
%           grpvals =   [k x 1] vector of unique group identifiers in 'grpsKnown'.
%           sizeAdj =   boolean flag indicating, if true, that Mahalanobis 
%                         distances are to be based on residuals from a "size-free" 
%                         discriminant analysis [default = 0].
%           -----------------------------------------------------------------------
%           classifResults =   [n x k] boolean matrix specifying the classification of 
%                         each observation into one of the k groups, allowing 
%                         for possible ties.
%

% RE Strauss, 7/13/98
%   11/29/99 - changed calling sequence.
%   3/12/07 -  changed name of function from classifk()

function classifResults = ClassifyKnowns(dataKnown,grpsKnown,grpvals,sizeAdj)
  nKnownObs = size(dataKnown,1);                        % Number of observations
  nGrpsKnown = length(grpvals);                         % Number of groups
  newGrpValue = max(grpsKnown)+1;                       % Group identifier for "unknown"

  classifResults = zeros(nKnownObs,nGrpsKnown);         % Allocate output matrix

  for iObs = 1:nKnownObs                                % Cycle thru observations
    x = [dataKnown; dataKnown(iObs,:)];                 % Move current obs to end
    x(iObs,:) = [];

    g = grpsKnown;                                      % Assign to its own grp
    g(iObs) = [];
    g = [g; newGrpValue];

    if (sizeAdj)                                        % Get Mahalanobis distances
      [l,p,s,f,D2] = sizefree(x,g,1);
    else
      D2 = MahalDist(x,g);
    end;

    [minD2,closest] = min(D2(nGrpsKnown+1,1:nGrpsKnown));   % Set boolean classification
    classifResults(iObs,closest) = ones(1,length(closest)); %   flag(s)
  end;

  return;

% --------------------------------------------------------------------------------------------

% ClassifyUnknowns: Classifies "unknown" observations, singly or in groups, based on a  
%           training set of observations.  Called by classify().
%
%     Usage: classifResults = ClassifyUnknowns(dataKnown,grpsKnown,dataUnknown,grpsUnknown,nGrpsKnown,uGrpsUnknown,sizeAdj)
%           dataKnown =         [n x p] data matrix (obs x vars) for the n "known"  
%                         training observations.
%           grpsKnown =      [n x 1] vector of group identifiers for k training grps.
%           dataUnknown =        [m x p] data matrix for the m "unknown" observations.
%           grpsUnknown =     [m x 1] vector of group identifiers for "unknown"
%                         observations; if not passed, the unknowns are 
%                         classified individually.
%           nGrpsKnown =    number of training groups.
%           uGrpsUnknown =  vector of unique group identifiers in 'grpsKnown'.
%           sizeAdj =   boolean flag indicating, if true, that Mahalanobis 
%                         distances are to be based on residuals from a 
%                         "size-free" discriminant analysis.
%           ---------------------------------------------------------------------
%           classifResults =   [m x k] boolean matrix specifying the classification of 
%                         each "unknown" observation into one of the k training 
%                         groups, allowing for possible ties.
%

% RE Strauss, 7/13/98
%   11/29/99 - changed calling sequence.
%   3/12/07 -  changed name of function from classifu()

function classifResults = ClassifyUnknowns(dataKnown,grpsKnown,dataUnknown,grpsUnknown,nGrpsKnown,uGrpsUnknown,sizeAdj)
  nGrpsUnknown = length(uGrpsUnknown);                % Number of groups of unknowns
  nUnknownObs = size(dataUnknown,1);                 	% Number of unknown observations
  classifResults = zeros(nUnknownObs,nGrpsKnown);    	% Allocate output matrix

  for iu = 1:nGrpsUnknown                             % Cycle thru unknowns groups
    i = find(grpsUnknown == uGrpsUnknown(iu));        % Isolate unknowns for current grp

    g = [grpsKnown; grpsUnknown(i)];                  % Append unknown(s) to training matrices
    x = [dataKnown; dataUnknown(i,:)];

    if (sizeAdj)                                      % Get Mahalanobis distances
      [l,p,s,f,D2] = sizefree(x,g,1);
    else
      D2 = MahalDist(x,g);
    end;

    [minD2,closest] = min(D2(nGrpsKnown+1,1:nGrpsKnown));
    classifResults(i,closest) = ones(length(i),length(closest));
  end;

  return;




