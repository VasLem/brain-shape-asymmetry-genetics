% PutWhite: Sets the background color for the current figure to be white rather than gray.
%
%     Usage: PutWhite
%

% RE Strauss, 8/28/08

function PutWhite
  set(gcf,'Color',[1 1 1]);
  return;
  
