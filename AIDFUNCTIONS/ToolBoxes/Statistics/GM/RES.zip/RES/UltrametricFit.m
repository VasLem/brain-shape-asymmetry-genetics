% UltrametricFit: heuristically estimates a least-squares ultrametric dendrogram 
%         using iterative projection on a symmetric proximity matrix in the L^2-norm.
%         Based on ultrafnd.m and ultrafit.m of Hubert, Arabie & Meulman (2006).
%
%     Syntax: [cophenCorr,cophenRankCorr,varExpl,mse,uDist,topology,support] = ...
%                                    UltrametricFit(dist,{nRestarts},{labels},{noPlot})
%
%         dist - [n x n] square symmetric distance matrix with zeros on diagonal.
%         nRestarts - optional number of restarts attempted to find 'best' ultrametric 
%                       distance matrix [default = n].
%         labels -  optional character labels (rows) for objects being clustered.
%         noPlot -  optional boolean flag indicating that dendrogram plot is not to be
%                     produced [default = false].
%         ------------------------------------------------------------------------------
%         cophenCorr - cophenetic correlation.
%         cophenRankCorr - cophenetic rank correlation.
%         varExpl - variance accounted for by fitted distances (square of cophenetic
%                     correlation).
%         mse - mean squared deviation between original and fitted distances.
%         uDist -  best-fitting ultrametric distance matrix.
%         topology = [(n-1) x 4] matrix summarizing dendrogram topology:
%                       col 1 = 1st object/cluster being grouped at current step
%                       col 2 = 2nd object/cluster
%                       col 3 = ID of cluster being produced
%                       col 4 = distance at node
%         support =  [(n-2) x (n-1)] matrix, with one row for all but the base 
%                       node, specifying group membership (support) at each node.
%

% Hubert, Arabie, & Meulman. 2006. 

% RE Strauss, 6/7/08, modified from ultrafnd.m and ultrafit.m of 
%                       Hubert, Arabie & Meulman (2006).

function [cophenCorr,cophenRankCorr,varExpl,mse,uDist,topology,support] = ...
                                          UltrametricFit(dist,nRestarts,labels,noPlot)
  if (~nargin), help UltrametricFit; return; end;
  
  if (nargin < 2), nRestarts = []; end;
  if (nargin < 3), labels = []; end;
  if (nargin < 4), noPlot = []; end;
  
  nObj = size(dist,1);
  if (isempty(nRestarts)), nRestarts = nObj; end;
  if (isempty(noPlot)),    noPlot = false; end;

  bestVarExpl = 0;
  uDist = [];
  for ir = 1:nRestarts
    randSeq = randperm(nObj);
    [uD,varExpl] = UltraFnd(dist,randSeq);
    if (varExpl > bestVarExpl)
      bestVarExpl = varExpl;
      uDist = uD;
    end;
  end;
  
  if (~noPlot), figure; end;
  [topology,support] = upgma(uDist,labels,noPlot);
  index = Cophenetic(dist,uDist,noPlot);
  
  cophenCorr = index.coCorr;
  cophenRankCorr = index.rankCoCorr;
  mse = index.mse;
  varExpl = bestVarExpl;

  if (~noPlot)
    putxlab('Original distances');
    putylab('Fitted ultrametric distances');
    puttext(0.05,0.90,sprintf('r = %5.3f',cophenCorr));
  end;
  
  return;

% ----------------------------------------------------------------------------------------

% UltraFnd: Finds and fits an ultrametric using iterative projection
% heuristically on a symmetric proximity matrix in the L2-norm.

% Modified from ultrafnd.m, downloaded from <http://cda.psych.uiuc.edu/srpm_mfiles/ultrafnd.m>.
% See Hubert, Arabie & Meulman (2006).

function [uDist,varExpl] = UltraFnd(dist,randSeq)
  nObj = size(dist,1);
  work = zeros(nObj*(nObj-1)*(nObj-2),1);
  uDist = dist;
  cr = 1.0;
  nIters = 0;
  tol = 1e-6;

  while (cr >= tol)
    cr = 0.0;
    ind = 0;
    nIters = nIters + 1;
   
    for i1 = 1:(nObj-2)
      for i2 = (i1+1):(nObj-1)
        for i3 = (i2+1):nObj
          indOrd = randSeq([i1,i2,i3]);
            
          for i = 1:2
            for j = (i+1):3
              if (indOrd(i) > indOrd(j))
                indOrd([i,j]) = indOrd([j,i]);
              end;
            end;
          end;
              
          j1 = indOrd(1);
          j2 = indOrd(2);
          j3 = indOrd(3);
          p1 = uDist(j1,j2);
          p2 = uDist(j1,j3);
          p3 = uDist(j2,j3);
            
          if (nIters <= 100)
            uDist(j1,j2) = uDist(j1,j2) - work(ind+1);
            uDist(j1,j3) = uDist(j1,j3) - work(ind+2);
            uDist(j2,j3) = uDist(j2,j3) - work(ind+3);
          end;
            
        	if ((uDist(j1,j2) <= uDist(j1,j3)) && (uDist(j1,j2) <= uDist(j2,j3))) 
            ave = (uDist(j1,j3) + uDist(j2,j3))/2.0;
            work(ind+1) = 0.0;
            work(ind+2) = ave - uDist(j1,j3);
            work(ind+3) = ave - uDist(j2,j3); 
            uDist(j1,j3) = ave;
            uDist(j2,j3) = ave;
            ind = ind + 3;
          elseif ((uDist(j1,j3) <= uDist(j1,j2)) && (uDist(j1,j3) <= uDist(j2,j3))) 
            ave = (uDist(j1,j2) + uDist(j2,j3))/2.0;
            work(ind+1) = ave - uDist(j1,j2);
            work(ind+2) = 0.0;
            work(ind+3) = ave - uDist(j2,j3); 
            uDist(j1,j2) = ave;
            uDist(j2,j3) = ave;
            ind = ind + 3;
          elseif((uDist(j2,j3) <= uDist(j1,j3)) && (uDist(j2,j3) <= uDist(j1,j2))) 
            ave = (uDist(j1,j3) + uDist(j1,j2))/2.0;
            work(ind+1) = ave - uDist(j1,j2);
            work(ind+2) = ave - uDist(j1,j3);
            work(ind+3) = 0.0; 
            uDist(j1,j2) = ave;
            uDist(j1,j3) = ave;
            ind = ind + 3;
          end;
            
          cr = cr + abs(p1-uDist(j1,j2)) + abs(p2-uDist(j1,j3)) + abs(p3-uDist(j2,j3)); 
        end;
      end;
    end;
  end;

  for j1 = 1:(nObj-1)
    for j2 = (j1+1):nObj
      uDist(j2,j1) = uDist(j1,j2);
    end;
  end;

  uDist = ultrafit(dist,uDist);
  m = sum(sum(dist))/(nObj*(nObj-1));
  distMean = m*ones(nObj,nObj);
  distMean = putdiag(distMean,0);

  diff = sum(sum((dist-uDist).^2));
  denom = sum(sum((dist-distMean).^2));
  varExpl = 1-(diff/denom);

  return;
  
% ----------------------------------------------------------------------------------------
   
% ULTRAFIT fits a given ultrametric using iterative projection to
% a symmetric distimity matrix in the $L_{2}$-norm.
%
% syntax: [uDist,varExpl] = ultrafit(dist,ultrametTarg)
%
% PROX is the input distimity matrix (with a zero main diagonal
% and a dissimilarity interpretation);
% TARG is an ultrametric matrix of the same size as PROX;
% FIT is the least-squares optimal matrix (with 
% variance-accounted-for of VAF) to PROX satisfying the ultrametric
% constraints implicit in TARG.

% Modified from ultrafit.m, downloaded from <http://cda.psych.uiuc.edu/srpm_mfiles/ultrafit.m>.
% See Hubert, Arabie & Meulman (2006).

function [uDist,varExpl] = ultrafit(dist,ultrametTarg)
  nObj = size(dist,1);
  work = zeros(nObj*(nObj-1)*nObj*(nObj-1),1);
  uDist = dist;
  cr = 1.0;
  tol = 1e-6;

  while (cr >= tol)
    cr = 0.0;
    ind = 0;
   
    for j1 = 1:(nObj-2)
      for j2 = (j1+1):(nObj-1)
      	for j3 = (j2+1):nObj
          p1 = uDist(j1,j2);
          p2 = uDist(j1,j3);
          p3 = uDist(j2,j3);
          uDist(j1,j2) = uDist(j1,j2) - work(ind+1);
          uDist(j1,j3) = uDist(j1,j3) - work(ind+2);
          uDist(j2,j3) = uDist(j2,j3) - work(ind+3);
            
          if ((ultrametTarg(j1,j2) <= ultrametTarg(j1,j3)) && (ultrametTarg(j1,j2) <= ultrametTarg(j2,j3))) 
            ave = (uDist(j1,j3) + uDist(j2,j3))/2.0;
            work(ind+1) = 0.0;
            work(ind+2) = ave - uDist(j1,j3);
            work(ind+3) = ave - uDist(j2,j3); 
            uDist(j1,j3) = ave;
            uDist(j2,j3) = ave;
            ind = ind + 3;
          elseif ((ultrametTarg(j1,j3) <= ultrametTarg(j1,j2)) && (ultrametTarg(j1,j3) <= ultrametTarg(j2,j3))) 
            ave = (uDist(j1,j2) + uDist(j2,j3))/2.0;
            work(ind+1) = ave - uDist(j1,j2);
            work(ind+2) = 0.0;
            work(ind+3) = ave - uDist(j2,j3); 
            uDist(j1,j2) = ave;
            uDist(j2,j3) = ave;
            ind = ind + 3;
          elseif ((ultrametTarg(j2,j3) <= ultrametTarg(j1,j3)) && (ultrametTarg(j2,j3) <= ultrametTarg(j1,j2))) 
            ave = (uDist(j1,j3) + uDist(j1,j2))/2.0;
            work(ind+1) = ave - uDist(j1,j2);
            work(ind+2) = ave - uDist(j1,j3);
            work(ind+3) = 0.0; 
            uDist(j1,j2) = ave;
            uDist(j1,j3) = ave;
            ind = ind + 3;
          end;
            
          cr = cr + abs(p1-uDist(j1,j2)) + abs(p2-uDist(j1,j3)) + abs(p3-uDist(j2,j3)); 
        end;
      end;
    end;
   
    for j1 = 1:(nObj-1)
      for j2 = (j1+1):nObj
       	for j3 = 1:(nObj-1)
         	for jfour = (j3+1):nObj
          	if ((j1 ~= j3) || (j2 ~= jfour))
              p1 = uDist(j1,j2);
              p2 = uDist(j3,jfour);
              uDist(j1,j2) = uDist(j1,j2) - work(ind+1);
              uDist(j3,jfour) = uDist(j3,jfour) - work(ind+2);
                                    
              if (abs(ultrametTarg(j1,j2) - ultrametTarg(j3,jfour)) <= tol)
                ave = (uDist(j1,j2) + uDist(j3,jfour))/2.0;
                work(ind+1) = ave - uDist(j1,j2);
                work(ind+2) = ave - uDist(j3,jfour);
                uDist(j1,j2) = ave;
                uDist(j3,jfour) = ave;
                     
                ind = ind + 2;
              elseif ((abs(ultrametTarg(j1,j2)-ultrametTarg(j3,jfour)) > tol) && (ultrametTarg(j1,j2) < ultrametTarg(j3,jfour)))
                if (uDist(j1,j2) < uDist(j3,jfour))
                  work(ind+1) = 0;
                  work(ind+2) = 0;
                        
                  ind = ind + 2;
                elseif (uDist(j1,j2) >= uDist(j3,jfour))
                  ave = (uDist(j1,j2) + uDist(j3,jfour))/2.0;
                  work(ind+1) = ave - uDist(j1,j2);
                  work(ind+2) = ave - uDist(j3,jfour);
                  uDist(j1,j2) = ave;
                  uDist(j3,jfour) = ave;
                        
                  ind = ind + 2;
                end;
              elseif ((abs(ultrametTarg(j1,j2)-ultrametTarg(j3,jfour)) > tol) && (ultrametTarg(j1,j2) > ultrametTarg(j3,jfour)))
                if (uDist(j1,j2) > uDist(j3,jfour))
                  work(ind+1) = 0;
                  work(ind+2) = 0;
                        
                  ind = ind + 2;
                elseif (uDist(j1,j2) <= uDist(j3,jfour))
                  ave = (uDist(j1,j2) + uDist(j3,jfour))/2.0;
                  work(ind+1) = ave - uDist(j1,j2);
                  work(ind+2) = ave - uDist(j3,jfour);
                  uDist(j1,j2) = ave;
                  uDist(j3,jfour) = ave;
                        
                  ind = ind + 2;
                end;
              end;
                             
             	cr = cr + abs(p1-uDist(j1,j2)) + abs(p2-uDist(j3,jfour));
            end;
         	end;
      	end;
    	end;
    end;
  end;

	for j1 = 1:(nObj-1)
   	for j2 = (j1+1):nObj
      uDist(j2,j1) = uDist(j1,j2);
  	end;
	end;

  m = sum(sum(dist))/(nObj*(nObj-1));
  distMean = m*ones(nObj,nObj);
  distMean = putdiag(distMean,0);

  diff2 = sum(sum((dist-uDist).^2));
  denom = sum(sum((dist-distMean).^2));
  varExpl = 1-(diff2/denom);

  return;
     
                        
               
      
               
   
   
   
   
