% VectorPlot: Plot vector diagram of loadings (correlations), centered on origin
%
%     Syntax:  VectorPlot(loadings,{vectorLabels},{confInts},{floatBounds},{noVectorLabels},{vectorLabelDisplacement},...
%                         {thresholdVectorLength},{plotArrowheads},{fontSize})
%
%         loadings -       [n x 1] or [n x 2] matrix coordinates (loadings).
%         vectorLabels -   optional matrix of labels (by row) corresponding to vectors
%                             [default: integer labels].
%         confInts -       optional [n x 2] matrix of lower & upper confidence limits for a 
%                             single column of loadings.  Ignored for 2D vector plots.
%         floatBounds -    optional boolean flag indicating, if true, that axis 
%                             bounds are not to be fixed at {-1, +1} [default = false].
%         noVectorLabels - optional boolean flag indicating, if true, that labels are not 
%                             to be printed [default = false].
%         vectorLabelDisplacement - optional multiplicative scale factor to increase or decrease 
%                             distances of labels from vectors [default = 1].
%         thresholdVectorLength - optional threshold vector length for plotting labels [default = 0].
%         plotArrowheads - optional boolean flag indicating, if true, that vectors are 
%                             to be plotted with arrowheads [default = true].
%         fontSize -       optional font size for labels [default = 10].
%

% RE Strauss, 6/95
%   7/17/98 - added options: noVectorLabels, vectorLabelDisplacement, thresholdVectorLength, plotArrowheads.
%   9/10/98 - added plot for 1-dimensional loadings, fontSize.
%   9/16/98 - added ability to plot confidence limits for 1-dimensional loadings.
%   7/13/99 - added ability to plot 1-dimensional allometric coefficients.
%   9/3/99 -  changes to plots for Matlab v5.
%   1/2/00 -  allow for confidence limits out of sequence (high, low).
%   2/26/00 - allow for axis bounds beyond 1; changed use of arrow().
%   5/4/00 -  allow for loadings matrix to have >2 cols.
%   5/27/00 - print all labels to the right for 1-dimensional plots.
%   6/27/00 - added floatBounds option; isolated vectplot1 and vectplot2.
%   7/1/02 -  added size-check for loadings and vectorLabels matrices.
%   9/9/02 -  corrected problem with 7/1/02 correction.
%   4/26/06 - appended vectplot1 and vectplot2 to vectplot, renamed functions;
%               renamed variables.
%   6/2/08 -  misc improvements.
%   6/3/08 -  fixed problem with plotting vector labels on confidence intervals.
%   8/28/08 - changed figure background to white.

function VectorPlot(loadings,vectorLabels,confInts,floatBounds,noVectorLabels,vectorLabelDisplacement,...
            thresholdVectorLength,plotArrowheads,fontSize)

  if (~nargin), help VectorPlot; return; end;
          
  if (nargin < 1), help VectorPlot; return; end;
  if (nargin < 2), vectorLabels = []; end;
  if (nargin < 3), confInts = []; end;
  if (nargin < 4), floatBounds = []; end;
  if (nargin < 5), noVectorLabels = []; end;
  if (nargin < 6), vectorLabelDisplacement = []; end;
  if (nargin < 7), thresholdVectorLength = []; end;
  if (nargin < 8), plotArrowheads = []; end;
  if (nargin < 9), fontSize = []; end;

  [nVars,nAxes] = size(loadings);
  if (nAxes>2)
    loadings = loadings(:,1:2);
    [nVars,nAxes] = size(loadings);
  end;

  plotConfInts = false;
  if (~isempty(confInts) && nAxes==1)
    [nConfInts,nConfLimits] = size(confInts);
    if (nConfLimits~=2)
      error('  VectorPlot: must have 2 cols of confidence limits for loadings.');
    end;
    if (nConfInts~=nVars)
      disp('  VectorPlot: loadings and confidence-interval matrices');
      error('            must have same number of rows.');
    end;
    plotConfInts = true;
  end;
  
  if (isvect(vectorLabels))
    vectorLabels = vectorLabels(:);
  end;
  if (~isempty(vectorLabels) && size(vectorLabels,1)~=size(loadings,1))
    error('  VectorPlot: loadings and labels must have same number of rows.');
  end;

  if (isempty(floatBounds)),             floatBounds = 0;             end;
  if (isempty(noVectorLabels)),          noVectorLabels = 0;          end;
  if (isempty(vectorLabelDisplacement)), vectorLabelDisplacement = 1; end;
  if (isempty(thresholdVectorLength)),   thresholdVectorLength = 0;   end;
  if (isempty(plotArrowheads)),          plotArrowheads = 1;          end;
  if (isempty(fontSize)),                fontSize = 10;               end;

  if (~isempty(vectorLabels) && ~ischar(vectorLabels))     % Convert numeric labels to char
    vectorLabels = tostr(vectorLabels);
  end;
  if (isempty(vectorLabels))                              % Default labels
    vectorLabels = tostr(1:nVars);
  end;

  switch (nAxes)
    case 1,
      VectorPlot1D(loadings,vectorLabels,confInts,plotConfInts,floatBounds,noVectorLabels,...
                   vectorLabelDisplacement,thresholdVectorLength,plotArrowheads,fontSize);

    case 2,
      VectorPlot2D(loadings,vectorLabels,floatBounds,noVectorLabels,vectorLabelDisplacement,...
                   thresholdVectorLength,plotArrowheads,fontSize);

    otherwise
      error('  VectorPlot: loadings matrix must have 1 or 2 columns (axes)');
  end;

  return;
  
% --------------------------------------------------------------------------------------  
  
% Vectplot1D: Plot 1D vector diagram of loadings (correlations), centered on origin
%
%     Syntax:  VectorPlot1D(loadings,{vectorLabels},{confInts},{floatBounds},{noVectorLabels},{vectorLabelDisplacement},...
%                         {thresholdVectorLength},{plotArrowheads},{fontSize})
%
%         loadings -      [n x 1] or [n x 2] matrix coordinates (loadings).
%         vectorLabels -      optional matrix of labels (by row) corresponding to vectors
%                       [default: integer labels].
%         confInts -        optional [n x 2] matrix of lower & upper confidence limits 
%                       for a single column of loadings.
%         plotConfInts -    boolean flag indicating whether confidence intervals are 
%                       to be plotted.
%         floatBounds - boolean flag indicating, if true, that axis 
%                       bounds are not to be fixed at {-1, +1}.
%         noVectorLabels -    boolean flag indicating, if true, that labels are not 
%                       to be printed.
%         vectorLabelDisplacement -  multiplicative scale factor to increase or decrease 
%                       distances of labels from vectors.
%         thresholdVectorLength -    thresholdVectorLengthhold vector length for plotting labels.
%         plotArrowheads -  boolean flag indicating, if true, that vectors are 
%                       to be plotted with arrowheads.
%         fontSize -  font size for labels.
%

% RE Strauss, 6/27/00 (isolated from vectplot)
%   1/2/02 -  changed arrow() to putarrow().
%   6/12/02 - corrected syntax error for single-variable plot.
%   6/11/03 - change headsize in putarrow() to default value.
%   5/4/06 -  alter placement of labels for left-pointing allometry vectors 

function VectorPlot1D(loadings,vectorLabels,confInts,plotConfInts,floatBounds,...
                      noVectorLabels,vectorLabelDisplacement,thresholdVectorLength,plotArrowheads,fontSize)
                    
  nVars = size(loadings,1);

  if (~plotConfInts)                                    % Find min & max values to be plotted
    vals = loadings(:);
  else
    vals = [loadings(:); confInts(:)];
  end;
  minVal = min(vals);
  maxVal = max(vals);

  areAlloms = 0;                                        % Check if values are allometries
  if (minVal<1 && maxVal>1)
    areAlloms = 1;
  end;

  if (areAlloms || floatBounds)
    rangeVals = maxVal - minVal;
    v = [minVal-0.05*rangeVals maxVal+0.05*rangeVals -(nVars+1) 0];
  else
    v = [-1.1 1.1 -(nVars+1) 0];
  end;
  rangeAxis = v(2)-v(1);

  plot([0 0],[0 0]);
  axis(v);
  axis('square');
  hold on;
    
  if (areAlloms)
    plot([1 1],[-(nVars+1) 0],'k:');
    origin = 1;
  else
    plot([0 0],[-(nVars+1) 0],'k:');
    origin = 0;
  end;

  if (~plotConfInts)
    confInts = [loadings loadings];
  end;

  for iVar = 1:nVars
    lenVector = abs(loadings(iVar)-origin);               

    confInts1 = min(confInts(iVar,:));                  % Confidence limits
    confInts2 = max(confInts(iVar,:));
    confInts1 = confInts1(1);
    confInts2 = confInts2(1);

    if (~plotConfInts)                                  % Plot arrows or lines
      if (plotArrowheads && lenVector>0.06)
        putarrow([origin -iVar],[loadings(iVar) -iVar],1);
      else
        putarrow([origin -iVar],[loadings(iVar) -iVar],1,0);
      end;

    else                                                % Plot confidence limits
      deltaX = 0.01*rangeAxis;
      deltaY = 0.2;

      plot([confInts1 confInts2],[-iVar -iVar],'k');                          % Horizontal line
      plot([loadings(iVar) loadings(iVar)],[-iVar-deltaY -iVar+deltaY],'k');    % Tick mark

      plot([confInts1 confInts1],[-iVar-deltaY -iVar+deltaY],'k');            % Lower conf limit
      plot([confInts1 confInts1+deltaX],[-iVar-deltaY -iVar-deltaY],'k');
      plot([confInts1 confInts1+deltaX],[-iVar+deltaY -iVar+deltaY],'k');
      plot([confInts2 confInts2],[-iVar-deltaY -iVar+deltaY],'k');            % Upper conf limit
      plot([confInts2 confInts2-deltaX],[-iVar-deltaY -iVar-deltaY],'k');
      plot([confInts2 confInts2-deltaX],[-iVar+deltaY -iVar+deltaY],'k');
    end;

    deltaX = 0.008*rangeAxis;
    deltaY = 0.03;

    if (lenVector > thresholdVectorLength)                       % Plot labels
      if (~noVectorLabels)
%         if (loadings(iVar) > origin)
        if (confInts2 > origin)
          h = text(confInts2+vectorLabelDisplacement*deltaX, deltaY-iVar, vectorLabels(iVar,:));
          set(h,'fontsize',fontSize);
        elseif (~plotConfInts)
          h = text(vectorLabelDisplacement*deltaX+origin, deltaY-iVar, vectorLabels(iVar,:));
          set(h,'fontsize',fontSize);
        else
          h = text(confInts2+vectorLabelDisplacement*deltaX+origin, deltaY-iVar, vectorLabels(iVar,:));
          set(h,'fontsize',fontSize);
        end;
      end;  % if (~noVectorLabels)
    end; % if (lenVector > thresholdVectorLength)
  end; % for iVar

  puttick([],'off');
  hold off;
  Putwhite;

  return;
  
% --------------------------------------------------------------------------------------  
  
% Vectplot2D: Plot 2D vector diagram of loadings (correlations), centered on origin
%
%     Syntax:  VectorPlot2D(loadings,vectorLabels,floatBounds,noVectorLabels,vectorLabelDisplacement,thresholdVectorLength,plotArrowheads,fontSize)
%
%         loadings -      [n x 1] or [n x 2] matrix coordinates (loadings).
%         vectorLabels -      matrix of labels (by row) corresponding to vectors.
%         floatBounds - boolean flag indicating, if true, that axis 
%                       bounds are not to be fixed at {-1, +1}.
%         noVectorLabels -    boolean flag indicating, if true, that labels are not 
%                       to be printed.
%         vectorLabelDisplacement -  multiplicative scale factor to increase or decrease 
%                       distances of labels from vectors.
%         thresholdVectorLength -    thresholdVectorLengthhold vector length for plotting labels.
%         plotArrowheads -  boolean flag indicating, if true, that vectors are 
%                       to be plotted with arrowheads.
%         fontSize -  font size for labels.
%

% RE Strauss, 6/27/00 (isolated from vectplot)
%   1/2/02 - changed arrow() to putarrow().
%   4/12/02 - corrected syntax problem with call to putarrow().
%   6/11/03 -  change headsize in putarrow() to default value.

function VectorPlot2D(loadings,vectorLabels,floatBounds,noVectorLabels,vectorLabelDisplacement,thresholdVectorLength,plotArrowheads,fontSize)
  if (floatBounds)                                                  
    bound = 1.1*max([abs(min(loadings)), abs(max(loadings))]);        % Square plot bounds
  else
    bound = 1.1*max([abs(min(loadings)), abs(max(loadings)), 1]);
  end;

  plot([0 0],[0 0]);
  axis([-bound bound -bound bound]);
  axis('square');
  hold on;

  for i = 1:max(size(loadings))
    lenVector = sqrt(sum(loadings(i,:).^2));
    if (plotArrowheads)
      putarrow([0 0],loadings(i,:),1);
    else
      putarrow([0 0],loadings(i,:),1,0);
    end;

    if (loadings(i,1)>=0 && loadings(i,2)>=0)
      deltaX = 0.03;
      deltaY = 0.03;
    elseif (loadings(i,1)<0 && loadings(i,2)>=0)     
      deltaX = -0.07;
      deltaY = 0.03;
    elseif (loadings(i,1)<0 && loadings(i,2)<0)   
      deltaX = -0.07;
      deltaY = -0.04;
    elseif (loadings(i,1)>=0 && loadings(i,2)<0)
      deltaX = 0.03;
      deltaY = -0.04;
    end;
    deltaX = deltaX*bound;
    deltaY = deltaY*bound;

    if (lenVector > thresholdVectorLength)
      if (~noVectorLabels)
        h = text(loadings(i,1)+vectorLabelDisplacement*deltaX, loadings(i,2)+vectorLabelDisplacement*deltaY, vectorLabels(i,:));
        set(h,'fontsize',fontSize);
      end;
    end;
  end;

  hold off;
  PutWhite;
  
  return;
