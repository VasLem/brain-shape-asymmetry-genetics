% SplitGrp: Given a vector 'grp' containing grouping codes for 2-9 groups,
%     and a matrix X containing corresponding data, this procedure splits
%     the data matrix X into 2-9 separate matrices, one per group.  Groups are 
%     identified in the sequence in which they are encountered in 'grp'; corresponding 
%     group labels are given in the column vector 'grp_id'.
%
%     Usage: [grp_id,X1,X2,...,X9] = SplitGrp(grps,X)
%
%     Matrices X3-X9 are empty if only 2 groups are present, and so on.
%

% RE Strauss.  Rewritten 9/98.
%   11/29/99 - reversed calling sequence.
%   1/25/00 -  revised error message; changed name of unique().
%   1/27/10 -  miscellaneous minor improvements.

function [index,X1,X2,X3,X4,X5,X6,X7,X8,X9] = SplitGrp(X,grps)
  [rx] = size(X,1);
  [rg] = size(grps,1);
  if (rx ~= rg),
    error('   Group and data matrices must have same number of rows');
  end;

  X2=[]; X3=[]; X4=[]; X5=[];         % Allocate output matrices
  X6=[]; X7=[]; X8=[]; X9=[];
  
  index = UniqueValues(grps);         % Get set of group labels
  nGrps = length(index);

  if (nGrps > 9)
    error('  SPLITGRP: Max of 9 groups allowed.');
  end;

  i = (grps==index(1));
  X1 = X(i,:);

  if (nGrps>1 && nargout>2)
    i = (grps==index(2));
    X2 = X(i,:);
  end;

  if (nGrps>2 && nargout>3)
    i = (grps==index(3));
    X3 = X(i,:);
  end;

  if (nGrps>3 && nargout>4)
    i = (grps==index(4));
    X4 = X(i,:);
  end;

  if (nGrps>4 && nargout>5)
    i = (grps==index(5));
    X5 = X(i,:);
  end;

  if (nGrps>5 && nargout>6)
    i = (grps==index(6));
    X6 = X(i,:);
  end;

  if (nGrps>6 && nargout>7)
    i = (grps==index(7));
    X7 = X(i,:);
  end;

  if (nGrps>7 && nargout>8)
    i = (grps==index(8));
    X8 = X(i,:);
  end;

  if (nGrps>8 && nargout>9)
    i = (grps==index(9));
    X9 = X(i,:);
  end;


  return;
