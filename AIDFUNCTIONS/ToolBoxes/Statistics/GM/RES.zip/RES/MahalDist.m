% MahalDist: Mahalanobis distances among groups, based on the pooled covariance  
%        matrix among all groups.  Reduces the number of variables to an optimal 
%        subset if the pooled covariance matrix is singular.
%        Note: D2 is summed across variables, and therefore is dependent on
%          (not adjusted for) the number of variables.
%
%     Syntax: [dist,ciDist,prDist] = MahalDist(data,grps,{nIters},{ciLevel})
%
%        data =     [n x p] data matrix (obs x vars).
%        grps =     row or column vector of group identifiers.
%        nIters =   number of randomization iterations [default=0].
%        ciLevel =  percent width of confidence intervals [default=95].
%        ---------------------------------------------------------------------
%        dist =     [g x g] symmetric distance matrix.
%        ciDist =   [g x g] matrix of low (lower triangular matrix) and
%                     high (upper triangular matrix) confidence limits.
%                   If nIters=0, they are asymptotic estimates using an
%                     F-distribution.
%                   If nIters>0, they are bootstrapped estimates.
%        prDist =   [g x g] matrix of probabilities of H0:d2=0.
%                   If nIters=0, they are asymptotic estimates based on an
%                     F-statistic.
%                   If nIters>0, both asymptotic (lower triangular matrix) and
%                     randomized (upper triangular matrix) estimates are given.
%

% Q: Because the pooled covar matrix is diminished as a function of the number
%    of groups, should it be estimated separately for each pair of groups?
% Tentative answer: No, because then the pairwise distances within the matrix 
%    will not be comparable.

% RE Strauss, 5/21/95
%   3/20/98 -  major rewrite.
%   11/27/99 - handle singular covariance matrix.
%   11/29/99 - reversed data and grps in calling sequence.
%   6/13/00 -  added check for missing data.
%   8/29/08 -  major rewrite (simplification) of randomization functions;
%              removed post-hoc power estimates.

function [dist,ciDist,prDist] = MahalDist(data,grps,nIters,ciLevel)
  if (~nargin), help MahalDist; return; end;

  if (nargin < 3), nIters = []; end;
  if (nargin < 4), ciLevel = []; end;

  if (isempty(nIters)), nIters = 0; end;
  if (isempty(ciLevel)), ciLevel = 0.95; end;
  if (ciLevel > 1), ciLevel = 0.01 * ciLevel; end;
  
  nObs = size(data,1);                          % Numbers of observations & variables
  if (length(grps) ~= nObs)
    error('  MahalDist: Group vector and data matrix incompatible.');
  end;

  getCI = false;                                % Initialize action flags
  getProb =   false;
  if (nargout > 1), getCI = true; end;
  if (nargout > 2), getProb = true; end;

  if (misscheck(data,grps))
    error('  MahalDist: data matrix or grouping vector contains missing data.');
  end;

  distVect = MahalObj(data,grps);               % Get upper-triangular distance matrix
  dist = trisqmat(distVect);                    % Convert to square symmetric matrix
  
  if (getCI)                                    % Confidence intervals
    if (nIters>0)
      ciDist = MahalCIRand(data,grps,distVect,nIters,ciLevel); % Randomized by bootstrap
    else
      ciDist = MahalCIAsympt(data,grps,dist,ciLevel); % Asymptotic
    end;
  end;
  
  if (getProb)                                  % Significance levels
    if (nIters>0)
      prDist = MahalProbRand(data,grps,distVect,nIters); % Randomized by permutation
    else
      prDist = MahalProbAsympt(data,grps,dist);   % Asymptotic
    end;
  end;
  
  return;
  
% ----------------------------------------------------------------------------------------

% MahalObj: Objective function for finding Mahalanobis distances among groups.
%
%     Syntax: dist = MahalObj(data,grps)
%
%        grps =     row or column vector of group identifiers.
%        data =        [n x p] data matrix (obs x vars).
%        ---------------------------------------------------------------------------
%        dist =       [1 x g*(g-1)/2] row vector representing the upper triangular
%                     off-diagonal portion of the [g x g] symmetric distance matrix.
%

% RE Strauss, 3/20/98
%   11/27/99 - handle singular pooled within-grp covar matrix.
%   11/16/00 - added warning message for singular covar matrix.
%   12/12/00 - use covpool() to find pooled within-group covar matrix.
%    8/29/08 - update variable names;
%              make symmetric covariance matrix an error.

function dist = MahalObj(data,grps)
  nGrps = length(unique(grps));                	% Number of groups
  dist = zeros(1,nGrps*(nGrps-1)/2);            % Allocate distance matrix as upper-triangular row vector

%   [cP,wMean,isSingular] = covpool(data,grps);   % Pooled within-group covar matrix
%                                                 %   and within-group means
%   if (isSingular)                               % If covar matrix is singular, error
%     error('  MahalDistObj warning: covariance matrix is singular.');
%   end;

  incl = StepDiscrim(data,grps);                % Reduce variables if necessary
  [cP,wMean] = covpool(data(:,incl),grps);      % Pooled within-group covar matrix

  pos = 0;
  for g1 = 1:(nGrps-1)                          % Stash distances
    for g2 = (g1+1):nGrps
      diff = wMean(g1,:) - wMean(g2,:);
      d = diff * (cP \ diff');
      pos = pos+1;
      dist(pos) = d;
    end;
  end;

  return;

% ----------------------------------------------------------------------------------------

% MahalCIRand: Estimate confidence intervals by bootstrapping.

function ciDist = MahalCIRand(data,grps,distVect,nIters,ciLevel)
  nGrps = length(unique(grps));
  
  distrib = zeros(1,nGrps*(nGrps-1)/2);   % Allocate bootstrap distribution
  distrib(1,:) = distVect;                % Seed with observed solution
  
  for it = 2:nIters                       % Bootstrapped sampling distribution
    dataBoot = BootSamp(data,grps);
    distrib(it,:) = MahalObj(dataBoot,grps);
  end;
  
  ciDist = BootCIBounds(distrib,[],[],ciLevel); % Get conficence limits
  ciDist = trisqmat(ciDist');             % Convert to square matrix

  return;
  
% ----------------------------------------------------------------------------------------

function prDist = MahalProbRand(data,grps,distVect,nIters)
  nObs = size(data,1);
  nGrps = length(unique(grps));
  
  distrib = zeros(1,nGrps*(nGrps-1)/2);   % Allocate bootstrap distribution

  for it = 1:nIters                       % Randomized null distribution
    dataPerm = data(randperm(nObs),:);
    distrib(it,:) = MahalObj(dataPerm,grps);
  end;
  
  prDist = bootprob(distVect,distrib);    % Get significance levels
  prDist = trisqmat(prDist);              % Convert to square matrix
  
  return;
  
% ----------------------------------------------------------------------------------------

% MahalCI: Asymptotic confidence interval for Mahalanobis distances among groups, 
%          based on non-central F distribution.
%
%     Syntax: ciDist = MahalCIAsympt(data,grps,dist,ciLevel)
%
%        data =         [n x p] data matrix (obs x vars).
%        grps =      row or column vector of group identifiers.
%        dist =        [g x g] matrix of Mahalanobis distances.
%        ciLevel =  percent width of confidence intervals [default=95].
%        ---------------------------------------------------------------------
%        ci =    [g x g] matrix of low (lower triangular matrix) and
%                  high (upper triangular matrix) confidence limits.
%

% RE Strauss, 5/6/98
%   11/29/99 - changed calling sequence.
%   11/26/03 - replace RES noncentral F-inv function by Matlab stat toolbox function.
%   11/29/03 - rewrite based on MahalPr().

function ciDist = MahalCIAsympt(data,grps,dist,ciLevel)
  intLow = (1-ciLevel)/2;
  intHigh = 1 - intLow;

  [index,N] = UniqueValues(grps);       % Vector of within-group sample sizes
  nGrps = length(index);                % Number of groups
  [nObs,p] = size(data);                % Numbers of observations & variables
  ciDist = NaN*ones(nGrps,nGrps);       % Allocate output matrix of confidence intervals
  ciDist = putdiag(ciDist,0);

  n = (N*ones(1,nGrps) + ones(nGrps,1)*N'); % ni + nj
  c = (N*N')./n;                    % (ni*nj)/(ni+nj)
  m = n-p-1;
%   k = p*(n-2);
  lambda = c;

  df1 = p;
  df2 = m;
  df2_save = df2;

  [ok,intLow,intHigh,df1,df2,lambda] = samelength(intLow,intHigh,df1,df2(:),lambda(:));

  [i,j] = find(df2_save>0);               % Find ci for df2>0
  distLow = ncfinv(intLow,df1,df2,lambda);
  distHigh = ncfinv(intHigh,df1,df2,lambda);
  
  for k = 1:length(i)
    ik = i(k);
    jk = j(k);
    if (ik < jk)
      ciDist(ik,jk) = distHigh(k);
    elseif (ik > jk)
      ciDist(ik,jk) = distLow(k);
    end;
  end;
  
  return;

% ----------------------------------------------------------------------------------------

% MahalPr: Asymptotic probabilities for Mahalanobis distances among groups,
%          based on a central F-distribution.
%
%     Syntax: prDist = MahalProbAsympt(data,grps,dist)
%
%        data =      [n x p] data matrix (obs x vars).
%        grps =      row or column vector of group identifiers.
%        dist =        [g x g] matrix of Mahalanobis distances.
%        ---------------------------------------------------------------------
%        prDist =      [g x g] matrix of probabilities of H0:dist=0.
%

% SPSS 7.5 Statistical Algorithms, p 136.

% RE Strauss, 5/6/98
%   11/29/99 - changed calling sequence.
%   11/26/03 - replace nonpositive df2 values with NaNs;
%              enforce 1s on diagonal of prob matrix;
%              altered values for m and k based on 2 grps.

function prDist = MahalProbAsympt(data,grps,dist)
  [index,freqs] = UniqueValues(grps);
  nGrps = length(index);                        % Number of groups
  [nObs,nVars] = size(data);                    % Numbers of observations & variables
  
  n = (freqs*ones(1,nGrps) + ones(nGrps,1)*freqs'); % ni + nj
  c = (freqs*freqs')./n;                            % (ni*nj)/(ni+nj)
  m = n-nVars-1;
  k = nVars*(n-2);

  df1 = nVars;
  df2 = m;

  Fhat = dist.*m.*c./k;
  prDist = 1-fcdf(Fhat,df1,df2);
  prDist = putdiag(prDist,1);

  return;

