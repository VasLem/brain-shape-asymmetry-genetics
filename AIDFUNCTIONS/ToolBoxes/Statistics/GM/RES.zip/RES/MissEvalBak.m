% MissEval: Evaluate performance of missing-data estimation methods (EM and PCA) 
%           by randomly introducing missing values into a complete data matrix, 
%           and assessing the difference between the original and predicted 
%           values.  Criterion of performance is the mean squared error (MSE) 
%           from the regression of predicted missing values on original values, 
%           accumulated across iterations.
%
%     Usage: [goodresults,allbouts] = MissEval(X,method,{pMissing},{nIters},{nObs},{nChars})
%
%         X =           complete [n x p] data matrix.
%         method =      estimation method: 0 for EM, 1 for PCA.
%         pMissing =    optional vector of proportions (0-1) or numbers (>1) of 
%                         missing data to be randomly introduced into data matrix
%                         [default = 0.01:0.01:0.50].
%         nIters =      vector (length 3) containing optional numbers of 
%                         randomization iterations for each value of 'pMissing': 
%                         [total iterations, iterations per bout, maximum bouts]
%                         where number of bouts = (total iterations)/(iterations per 
%                         bout), but max number of bouts can be greater
%                         (default = [1000,200,10]).
%         nObs =        optional number of randomized observations to be included 
%                         in matrix having missing data [default = all].
%         nChars =      optional number of randomized variables to be included 
%                         in matrix having missing data [default = all].
%         --------------------------------------------------------------------------
%         goodresults = matrix containing results from bouts in which all 
%                         iterations were successful.  Also written to 
%                         'MissevalGoodResults.txt' (see below).
%         allbouts =    3-column matrix containing numbers of successful iterations
%                         per bout: [cur_pMissing, bout_number, percentSuccess]
%                         (see below).  Also written to 'MissevalAllBouts.txt'.
%
%     Output stored in 'goodresults',and written to 'MissevalGoodResults':
%         cur_pMissing =   current value of pMissing.
%         bout_number = current bout within current value of pMissing.
%         mse =         residual variance for regression of predicted missing 
%                         values versus original.
%         deltavar =    signed proportional change in total variance from original 
%                         to predicted missing values: [mean, stderr] 
%                         across iterations.
%         nonuni =      [1 x 4] vector of mean-squared differences between observed and 
%                       expected marginal totals.
%                         1) relative difference for matrix;
%                         2) relative difference for rows;
%                         3) relative difference for columns;
%                         4) contingency MAD statistic;
%

% RE Strauss, 3/17/99
%   10/2/00 -  added time limit to call to missem().
%   10/3/00 -  allow proportion or number of missing values.
%   10/6/00 -  upgraded standardization and documentation;
%                added doplot option.
%   10/10/00 - allowed for 'pMissing' to be a vector rather than scalar.
%   2/2/01 -   removed 'do_deltavar' flag from input arguments.
%   3/6/01 -   move tofile to within 1:np loop.
%   2/28/02 -  general overhaul; automated many functions, provided for 
%                iterations within bouts.
%   4/12/02 -  change default value for 'nIters'.
%   10/30/02 - changed misspca() to misspc().
%   6/26/07 -  set initial rand seed via clock.
%   7/6/07 -   general update of variable names.

function [goodresults,allbouts] = MissEval(X,method,pMissing,nIters,nObs,nChars)
  if (nargin < 3), pMissing = []; end;
  if (nargin < 4), nIters = []; end;
  if (nargin < 5), nObs = []; end;
  if (nargin < 6), nChars = []; end;
  
  maxtime = 30*60;                      % 30 minute time limit per iteration
  rand('state',sum(100*clock));         % Reset seed
  
  if (sum(~isfinite(X(:))>0))
    error('  Misseval: input data matrix contains missing data.');
  end;

  [nRows,nCols] = size(X);              % Size of data matrix

  if (isempty(pMissing)), pMissing = (0.01:0.01:0.50); end;   % Default arguments
  if (isempty(nIters)),   nIters = [1000,200,10]; end;
  if (isempty(nObs)),     nObs = nRows; end;
  if (isempty(nChars)),   nChars = nCols; end;

  if (length(nIters)~=3)
    error('  Misseval: iterations vector must contain 3 elements.');
  end;

  nPMissing = length(pMissing);
  nMissing = pMissing;
  for i = 1:nPMissing
    if (pMissing(i)<1)
      nMissing(i) = round(pMissing(i)*nObs*nChars);
    end;
  end;

  if (max(max(X)) > 10)                     % Log-transform if needed
    X = log(X);
  end;

  maxTotalIters = nIters(1);                % Isolate iteration information
  nItersPerBout = nIters(2);
  maxBouts = nIters(3);
%   nBouts = round(maxTotalIters / nItersPerBout);

  nResultCols = 10;
  nResultRows = nPMissing*maxBouts;
  results = zeros(nResultRows,nResultCols);
  curResults = 0;
  
  oldX = X;

  for np = 1:nPMissing                      % Cycle through proportions of missing values
    cumOldX = zeros(nMissing(np)*nItersPerBout,1);
    cumNewX = zeros(nMissing(np)*nItersPerBout,1);
    dVar =    zeros(nItersPerBout,1);

    failFlag = false;
    totIters = 0;
    in = 0;
    
    allBoutsFailed = true;
    
    for bout_number = 1:maxBouts            % Cycle thru bouts
      percentSuccess = 0;
      nonUniformities = zeros(nItersPerBout,4);
      
      for it = 1:nItersPerBout                % Randomization iterations
        X = oldX;
  
        if (nObs < nRows)
          robs = randperm(r);
          X = X(robs(1:nObs),:);
        end;
        if (nChars < nCols)
          rchars = randperm(c);
          X = X(:,rchars(1:nChars));
        end;

        prevX = X;
        [X,failFlag] = RandMiss(X,nMissing(np));    % Introduce random missing values
        
        if (~failFlag)
          nonUniformities(it,:) = MissRandMeas(X);    % Measure nonuniformity of missing values

          [rn,cn] = find(~finite(X));                 % Save addresses of missing values

          if (method==0)
%             [newX,M,C,propMissing,failFlag,stoptime] = missem(X,maxtime);
            [newX,M,C,propMissing,failFlag] = Missem(X,maxtime);
          else
            [newX,propMissing,failFlag] = Misspc(X);
          end;
        end;

        if (failFlag)
          save missevalmat;
          break;
        end;
        percentSuccess = percentSuccess+(100/nItersPerBout);

%         diff = newX - prevX;
%         nonzero = diff(diff~=0);

        oldVariance = sum(diag(cov(prevX)));
        newVariance = sum(diag(cov(newX)));
        dVar(it) = (newVariance-oldVariance)/oldVariance;
 
        for i = 1:nMissing(np)
          in = in+1;
          cumOldX(in) = oldX(rn(i),cn(i));
          cumNewX(in) = newX(rn(i),cn(i));
        end;
      end; % for it = 1:nIters
      
      if (~failFlag)                            % Results for this bout
        totIters = totIters + nItersPerBout;
%         cum_nonzero = cumNewX - cumOldX;
  
        [b,stats] = linregr(cumOldX(:),cumNewX(:));
        mse = stats(2);
        m = mean(dVar);
        s = std(dVar);
        deltavar = [m, s];
        nonuni = mean(nonUniformities);
        allBoutsFailed = false;
      else
        mse = NaN;
        deltavar = [NaN, NaN];
        nonuni = [NaN, NaN, NaN, NaN];
      end;
      
      pMissing_bout_percsuccess_totnIters = ...
        [pMissing(np) bout_number percentSuccess totIters]      

      curResults = curResults+1;
      res = [pMissing(np) bout_number percentSuccess mse deltavar nonuni];
      results(curResults,:) = res;
    
      save missevalmat;
      
      if (totIters >= maxTotalIters)
        break;
      end;
    end; % for bout_number = 1:maxBouts
    
    if (allBoutsFailed)
      break;
    end;
  end;  % for np = 1:nPMissing

  allbouts = results(1:curResults,1:3);
%   tofile(allbouts,'MissevalAllBouts.txt',-5);
  
  pos = (isfinite(results(1:curResults,4)));
  goodresults = results(pos,[1,2,4:end]);
%   tofile(goodresults,'MissevalGoodResults.txt',-5);

  return;




