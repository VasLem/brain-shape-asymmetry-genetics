% PlotSurface: Given a set of 3D point coordinates, plots a mesh, surface, or contour plot.
%              A colorized, smoothed surface plot is produced by default.
%              If 2D coordinates are provided, they are automatically binned to produce 3D
%              coordinates.
%
%     Usage: [xOut,yOut,zOut] = PlotSurface(x,y,z,{plotType},{nGrids},{ptSymbol},{extraPts},...
%                        {doContours},{colorScheme},{noSmoothing})
%
%         x,y,z =       corresponding column vectors of length nPts.  If z is empty, the
%                         points (x,y) are binned to form (x,y,z) coordinates.
%         plotType =    optional flag indicating the type of plot to be produced:
%                         0: no plot;
%                         1: surface plot [default];
%                         2: mesh plot;
%                         3: waterfall plot;
%                         4: 2D contour plot.
%         nGrids =      optional 2-element vector of numbers of grid positions
%                         in the x- and y-directions [default = [40,40]]; if a single
%                         value is passed, it is used for both dimensions.
%         ptSymbol =    optional plot symbol for points to be superimposed onto 
%                         the surface plot (e.g., 'ko'), either the original points 
%                         (if 'extraPts' are not supplied) or extra points (if they
%                         are).
%         extraPts =    optional 3-column matrix of (x,y,z) coordinates to be superimposed
%                         onto the plot.
%         doContours =  optional boolean flag indicating that a contour plot is to 
%                         be superimposed onto the floor of the surface plot
%                         [default = false].
%         colorScheme = optional flag indicating the color scheme for the plot:
%                         0: default colormap [default];
%                         1: gray-scale;
%                         2: black (for mesh or waterfall plots).
%         noSmoothing = optional boolean flag indicating that the surface is not to 
%                         be smoothed (via cubic interpolation) before being plotted
%                         [default = false].
%         ---------------------------------------------------------------------------------
%         xOut,yOut,zOut = corresponding square matrices in standard Matlab 3D format.
%

% RE Strauss, 11/1/02
%   11/12/02 - added ability to superimpose points onto surface plot;
%              rearranged input arguments; other miscellaneous changes.
%   2/25/03 -  allow for superimposition of additional points.
%   4/19/03 -  output coordinate matrices in standard Matlab 3D format.
%   7/31/07 -  added option of binning 2D coordinates; 
%              standardized variable names.

function [xOut,yOut,zOut] = PlotSurface(x,y,z,plotType,nGrids,ptSymbol,extraPts,...
                               doContours,colorScheme,noSmoothing)
                             
  if (nargin <  4), plotType = []; end;
  if (nargin <  5), nGrids = []; end;
  if (nargin <  6), ptSymbol = []; end;
  if (nargin <  7), extraPts = []; end;
  if (nargin <  8), doContours = []; end;
  if (nargin <  9), colorScheme = []; end;
  if (nargin < 10), noSmoothing = []; end;
  
  plotPoints = false;
  if (~isempty(ptSymbol)),   plotPoints = true; end;
  if (isempty(nGrids)),      nGrids = [40,40]; end;
  if (length(nGrids)==1),    nGrids = [nGrids,nGrids]; end;
  if (isempty(plotType)),    plotType = 1; end;
  if (isempty(doContours)),  doContours = false; end;
  if (isempty(colorScheme)), colorScheme = 0; end;
  
  switch (colorScheme)                          % Set colormap
    case 0,
    case 1,
      colormap('gray');
    case 2,
      colormap(zeros(size(colormap)));
    otherwise
      error('  PlotSurface: invalid value for color scheme');  
  end;
  
  if (isempty(z))                               % Bin the 2D coordinates
    [x,y,z] = SurfaceBin([x,y],nGrids);
    x = x + 0.01*range(x)*randn(size(x));         % Jiggle the x,y coordinates
    y = y + 0.01*range(y)*randn(size(y));
  end;
  
  xi = linspace(min(x),max(x),nGrids(1));       % Create grid via Delaunay triangulation
  yi = linspace(min(y),max(y),nGrids(2));
  [xOut,yOut] = meshgrid(xi,yi);   
  if (noSmoothing)
    zOut = griddata(x,y,z,xOut,yOut,'linear');
  else
    zOut = griddata(x,y,z,xOut,yOut,'cubic');
  end;

  switch (plotType)
    case 0,                                     % No plot
    case 1,                                     % Surface plot
      if (doContours)                       
        surfc(xOut,yOut,zOut);
      else
        surf(xOut,yOut,zOut);
      end;
    case 2,                                     % Mesh plot
      if (doContours)
        meshc(xOut,yOut,zOut);
      else
        mesh(xOut,yOut,zOut);
      end;
    case 3,                                     % Waterfall plot
      waterfall(xOut,yOut,zOut);
    case 4,                                     % Contour plot
      contour(xOut,yOut,zOut);
    otherwise
      error('  PlotSurface: invalid plot type');
  end;
  
  if (plotPoints)
    hold on;
    if (isempty(extraPts))
      plot3(x,y,z,ptSymbol);
    else
      plot3(extraPts(:,1),extraPts(:,2),extraPts(:,3),ptSymbol);
    end;
    hold off;
  end;
  
  return;
  
