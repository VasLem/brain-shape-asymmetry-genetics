% KsTest2Sample: Kolmogorov-Smirnov two-sample test of identity of two data
%           distributions, for continuous data, with optional randomization.
%           Calculates either the KS-statistic (max difference between distributions)
%           or an MSE-statistic (mean squared difference).  Returns either the 
%           asymptotic probability (for the KS-statistic only) or a randomized 
%           probability.
%
%     Syntax: [pValue,statHat] = KsTest2Sample(x,grps,nIters,statistic,noPlot)
%
%         x =      data vector (length n1+n2=N).
%         grps =    corresponding group-membership vector.
%         nIters  =   number of iterations; if nIters=0 [default], then only the
%                     observed statistic value is returned.
%         statistic  =   flag indicating the statistic to be calculated:
%                     0 = KS statistic [default],
%                     1 = MSE statistic.
%         noPlot =  boolean flag indicating that plot of cumulative distributions
%                     is not to be produced [default = false].
%         -----------------------------------------------------------------------
%         pValue =      estimated significance level.
%         statHat = observed statistic value.
%

% Two-tailed probability level of Dmax is based on: 
%   Press, WH, SA Teukolsky, WT Vetterling, and BP Flannery. 1992.  Numerical recipes in C: 
%     the art of scientific programming.  Cambridge University Press. Pp. 623-626.

% RE Strauss, 9/26/96
%   5/10/99 - miscellaneous improvements (modified from KSTEST2).
%   5/28/03 - addition of "if (~nargin)" statement.
%  11/30/06 - renamed variables; substituted permutation for bootstrapping of
%               null distribution; remove post-hoc power estimation;
%               added optional plot of null distribution.

function [pValue,statHat] = KsTest2Sample(x,grps,nIters,statistic,noPlot)
  if (~nargin) help KsTest2Sample; return; end;
  
  KS = 0; MSE = 1;

  if (nargin < 3) nIters = []; end;
  if (nargin < 4) statistic = []; end;
  if (nargin < 5) noPlot = []; end;

  if (isempty(nIters))    nIters = 0; end;
  if (isempty(statistic)) statistic = KS; end;
  if (isempty(noPlot))    noPlot = false; end;

  [g,n] = UniqueValues(grps,1);
  if (length(g)~=2)
    error('KsTest2Sample: this is a 2-sample test.');
  end;
  
  doPlot = ~noPlot;

  statHat = KsTest2SampleObj(x,grps,[],[],statistic,doPlot);    % Get observed statistic value

  pValue = [];
  if (nIters==0 & statistic==KS)                    % Get probability of Dmax
    pValue = KsProb(statHat,n);
  end;

  if (nIters)
    distrib = zeros(nIters,1);
    for it = 1:nIters
      g = grps(randperm(length(grps)));
      distrib(it) = KsTest2SampleObj(x,g,[],[],statistic);
    end;
    pValue = sum(distrib>=statHat)/nIters;
    if (pValue < 1./nIters)
      pValue = 1./nIters;
    end;
  end;
  
  if (noPlot & nIters)
    figure;
    histgram(distrib,[],[],[],[],true,'rel');
    v = axis;
    v(4) = 1.05*v(4);
    axis(v);
    hold on;
    plot([statHat,statHat],[0,v(4)],'k:');
    hold off;
    putxlab('D_{max}');
    putylab('Frequency');
    fontsize = 14;
    puttitle(sprintf('Randomized null distribution, %d iterations',nIters),fontsize);
  end;

  return;
  
% ------------------------------------------------------------------------------------  
  
% KsTest2SampleObj: Objective function for KsTest2Sample.
%
%     Syntax: solution = KsTest2SampleObj(x,grps,nu1,nu2,stat,doPlot)
%
%         x =       [n x 1] vector of data scores.
%         grps =    [n x 1] vector of group membership (0,1).
%         nu1,nu2 = variables passed by BOOTSTRP but unused.
%         stat  =   flag indicating the statistic to be calculated:
%                     0 = KS statistic [default],
%                     1 = MSE statistic.
%         doPlot =  boolean flag indicating that plot of cumulative distributions
%                     is to be produced [default=false].
%         ------------------------------------------------------------------------
%         solution = test-statistic value
%

% RE Strauss, 9/26/96
%   9/3/99 -  changed plot colors for Matlab v5.
%   1/25/00 - changed name and usage of uniquef().
%   11/30/06 - changed cum-distribution plot.

function solution = KsTest2SampleObj(x,grps,nu1,nu2,stat,doPlot)
  if (nargin < 6) doPlot = []; end;
  
  if (isempty(doPlot)) doPlot = false; end;

  KS = 0; MSE = 1;

  groupIds = UniqueValues(grps);
  x1 = x(find(grps==groupIds(1)));      % Separate data by group
  x2 = x(find(grps==groupIds(2)));
  n1 = length(x1);
  n2 = length(x2);

  dist = UniqueValues([x1;x2],1);       % Create common abscissa
  nx = length(dist);
  dist = [dist, zeros(nx,2)];           % Add 2 cols for cum distribs

  incr = 1./n1;
  for i = 1:n1                          % Put cum distrib 1 on common abscissa
    j = find(dist(:,1)==x1(i));
    dist(j,2) = dist(j,2)+incr;
  end;

  incr = 1./n2;
  for i = 1:n2                          % Put cum distrib 2 on common abscissa
    j = find(dist(:,1)==x2(i));
    dist(j,3) = dist(j,3)+incr;
  end;

  dist(:,2) = cumsum(dist(:,2));        % Convert to cum distribs
  dist(:,3) = cumsum(dist(:,3));

  diff = dist(:,2)-dist(:,3);           % Difference between distribs
  if (stat==KS)                           % Calc KS statistic
    solution = max(abs(diff));
  elseif (stat==MSE)                      % Calc MSE statistic
    solution = mean(diff.*diff);
  end;

  if (doPlot)
    cdf1 = cumstep(x1);
    cdf2 = cumstep(x2);
    if (min(cdf1(:,1)) < min(cdf2(:,1)))
      cdf2 = [cdf1(1,1),0; cdf2];
    elseif (min(cdf2(:,1)) < min(cdf1(:,1)))
      cdf1 = [cdf2(1,1),0; cdf1];
    end;
    if (max(cdf1(:,1)) > max(cdf2(:,1)))
      cdf2 = [cdf2; cdf1(end,:)];
    elseif (max(cdf2(:,1)) > max(cdf1(:,1)))
      cdf1 = [cdf1; cdf2(end,:)];
    end;
    
    figure;
    plot(cdf1(:,1),cdf1(:,2),'k',cdf2(:,1),cdf2(:,2),'k:');
    xmin = min(x) - 0.05*range(x);
    xmax = max(x) + 0.05*range(x);
    axis([xmin xmax -0.05 1.05]);
    putxlab('X');
    putylab('Cumulative relative frequency');
    drawnow;
  end;

  return;

