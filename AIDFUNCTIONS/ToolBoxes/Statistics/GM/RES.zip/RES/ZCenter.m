% ZCenter: Zero-center a data matrix by column.
%
%     Usage: Z = ZCenter(X)
%
%           X = [n x p] data matrix.
%           ---------------------------------
%           Z = [n x p] centered data matrix.
%

% RE Strauss, 6/19/93

function Z = ZCenter(X)
   n = size(X,1);
   Z = X - ones(n,1)*mean(X);

   return;
