% Upgma: Unweighted pair-group hierarchical cluster analysis of a distance
%        matrix.  Produces plot of dendrogram.  To bootstrap cluster support,
%        see cluster().
%
%     Usage: [topology,support,patrist] = Upgma(dist,{labels},{noPlot},{fontSize})
%
%         dist =     [n x n] symmetric distance matrix.
%         labels =   optional [n x q] matrix of group labels for dendrogram.
%         noPlot =   optional boolean flag indicating that dendrogram is to be
%                      suppressed [default = false].
%         fontSize = optional font size for labels [default = 10].
%         -----------------------------------------------------------------------
%         topology = [(n-1) x 4] matrix summarizing dendrogram topology:
%                       col 1 = 1st OTU/cluster being grouped at current step
%                       col 2 = 2nd OTU/cluster
%                       col 3 = ID of cluster being produced
%                       col 4 = distance at node
%         support =  [(n-2) x (n-1)] matrix, with one row for all but the base 
%                       node, specifying group membership (support) at each node.
%         patrist =  [n x n] symmetric patristic distance matrix.
%

% To boostrap cluster support, see cluster().

% RE Strauss, 5/27/96
%   9/7/99 -  miscellaneous changes for Matlab v5.
%   9/24/01 - check diagonal elements against eps rather than zero.
%   3/14/04 - changed 'suppress' flag to 'noPlot'.
%   5/21/08 - standardized variables names.
%   5/25/08 - calculate patristic distances.
%   2/6/09 -  fix problem with calculation of patristic distances.

function [topology,support,patrist] = Upgma(dist,labels,noPlot,fontSize)
  if (nargin < 2), labels = []; end;
  if (nargin < 3), noPlot = []; end;
  if (nargin < 4), fontSize = []; end;

  getClustMembership = false;
  getPatrist = false;
  if (nargout > 1), getClustMembership = true; end;
  if (nargout > 2), getPatrist = true; end;
  
  if (isempty(noPlot)), noPlot = false; end;

  [nTaxa,p] = size(dist);
  if (nTaxa~=p || any(diag(dist)>eps))
    error('  Upgma: input matrix is not a distance matrix.');
  end;

  if (~isempty(labels))
    if (~ischar(labels))
      labels = tostr(labels);
    end;
    if (size(labels,1)~=nTaxa)
      error('  Upgma: numbers of taxa and taxon labels do not match.');
    end;
  end;

  clustSize = ones(1,nTaxa);                        % Number of elements in clusters/otus
  clustId = 1:nTaxa;                                % Cluster IDs
  topology = zeros(nTaxa-1,4);                      % Output dendrogram-topology matrix

  plug = 1e6;
  dist = dist + eye(nTaxa)*plug;                    % Replace diagonal with plugs

  for step = 1:(nTaxa-1)                            % Clustering steps
    minDist = min(dist(:));                           % Find minimum pairwise distance
    [ii,jj] = find(dist==minDist);                    % Find location of minimum
    k = 1;                                            % Use first identified minimum
    while (ii(k)>jj(k))                               %   for which i<j
      k = k+1;
    end;
    i = ii(k);
    j = jj(k);
    if (clustId(i)<clustId(j))
      topology(step,:) = [clustId(i) clustId(j) nTaxa+step minDist];
    else
      topology(step,:) = [clustId(j) clustId(i) nTaxa+step minDist];
    end;
    clustId(i) = nTaxa+step;
    dist(i,j) = plug;
    dist(j,i) = plug;

    newClustSize = clustSize(i) + clustSize(j);
    alphaI = clustSize(i) / newClustSize;
    alphaJ = clustSize(j) / newClustSize;
    gamma = 0;
    clustSize(i) = newClustSize;

    for k = 1:nTaxa                                 % For all other clusters/OTUs,
      if (k~=i && k~=j)                             %   adjust distances to new cluster
        dist(k,i) = alphaI * dist(k,i) + alphaJ * dist(k,j) + gamma;
        dist(i,k) = alphaI * dist(i,k) + alphaJ * dist(j,k) + gamma;
        dist(k,j) = plug;
        dist(j,k) = plug;
      end;
    end;
  end; % for step

  if (getClustMembership || getPatrist)             % Specify group membership at nodes
    support = ClusterSupport(topology);    
  end;

  if (getPatrist)                                   % Get pairwise distances on dendrogram
    patrist = topology(end,4)*ones(nTaxa,nTaxa);      % Initialize to root distance
    patrist = putdiag(patrist,0);                     % Put zeros on diagonal
    for c = size(support,1):-1:1                      % Consider group membership at nodes, backwards
      s = support(c,:);                                 % Isolate current row
      s = s(s>0);                                       % Non-zero values
      ns = length(s);
      
      st = s;
      for t = 1:size(topology,1)
      	if (isin(topology(t,1),st) && isin(topology(t,2),st))
          st = [st,topology(t,3)]; %#ok<AGROW>
        end;
      end;
      st = unique(st);
      
      stmax = max(st);
      pos = find(topology(:,3)==stmax);
      d = topology(pos,4);
      
      for t1 = 1:(ns-1)                                 % Stash into all pairwise entries for current cluster
        for t2 = (t1+1):ns
          patrist(s(t1),s(t2)) = d;
          patrist(s(t2),s(t1)) = d;
        end;
      end;
    end;
  end;

  if (~noPlot)                                      % Plot dendrogram
    dendplot(topology,labels,fontSize);
  end;

  return;
  
% ----------------------------------------------------------------------------------------------------------  
  
% ClusterSupport: Finds cluster-support matrix from dendrogram topology matrix.
%
%			Usage: support = ClusterSupport(topology)
%
%         topology =  [(n-1) x 4] matrix summarizing dendrogram topology:
%                       col 1 = 1st OTU/cluster being grouped at current step
%                       col 2 = 2nd OTU/cluster
%                       col 3 = ID of cluster being produced
%                       col 4 = distance at node
%					-----------------------------------------------------------------------
%         support =   [(n-2) x (n-1)] matrix, with one row for all but the base
%                       node, specifying group membership (support) at each node.
%

%	RE Strauss, 1/26/99
%   5/27/08 - appended to Upgma.m; standardized variable names.

function support = ClusterSupport(topology)
	nRows = size(topology,1);
	nRowsP1 = nRows+1;

  support = zeros(nRowsP1-2,nRowsP1-1);

  for iNode = 1:(nRowsP1-2)
    pos = 0;
    t1 = topology(iNode,1);
    t2 = topology(iNode,2);

    pos = pos+1;
    if (t1 <= nRowsP1)
      support(iNode,pos) = t1;
    else
      mem = find(support(t1-nRowsP1,:)>0);
      support(iNode,pos:(pos+length(mem)-1)) = support(t1-nRowsP1,mem);
      pos = pos+length(mem)-1;
    end;
    
    pos = pos+1;
    if (t2 <= nRowsP1)
      support(iNode,pos) = t2;
    else
      mem = find(support(t2-nRowsP1,:)>0);
      support(iNode,pos:(pos+length(mem)-1)) = support(t2-nRowsP1,mem);
      pos = pos+length(mem)-1; %#ok<NASGU>
    end;

    len = length(find(support(iNode,:)>0));
    support(iNode,1:len) = sort(support(iNode,1:len));
  end;

	return;
  
