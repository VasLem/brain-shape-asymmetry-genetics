% PatristDistance: Given an ancestor function for a dichotomous tree, calculates the distance matrix
%           and step matrix among terminal taxa.  The step matrix gives the number of resolved nodes 
%           between pairs of taxa after resolving polytomies with zero branch lengths.  
%           If branch lengths are not passed, lengths are assumed to be unity for resolved nodes.
%
%     Usage: [distanceMatrix,stepMatrix] = PatristDistance(ancFn,{branchLengths})
%
%           ancFn =          an ancestor-function vector, or a 2- or 3-column matrix specifying
%                              descendant labels (col 1), ancestor labels (col 2), and optional
%                              branch lengths (col 3).
%           branchLengths =  optional corresponding vector of corresponding branch (edge) 
%                              lengths.
%           -----------------------------------------------------------------------------------
%           distanceMatrix = patristic distances among pairs of terminal taxa.
%           stepMatrix =     step matrix, measuring the number of nodes between pairs of 
%                              terminal taxa.
%           ancFn =          ancestor function for resolved tree.
%           branchLengths =  corresponding branch lengths for resolved tree.
%

% RE Strauss, 7/14/95
%    9/20/99 - update handling of null input arguments.
%   10/18/02 - add error message for ancestor function lacking 0.
%   10/28/02 - call ancestorfunction() to resolve polytomies;
%              adjust step matrix for zero branch lengths.
%    5/23/06 - complete rewrite.

function [distanceMatrix,stepMatrix,ancFn,branchLengths] = PatristDistance(ancFn,branchLengths)
  if (nargin < 2) branchLengths = []; end;

  [ancFn,branchLengths] = AncestorFunction(ancFn,branchLengths);  % Put ancestor fn into proper form
  
  nTaxa = (length(ancFn)+1)/2;                  % Number of taxa
  stepMatrix = zeros(nTaxa,nTaxa);              % Allocate step matrix
  distanceMatrix = zeros(nTaxa,nTaxa);          % Allocate patristic-distance matrix

  ancList = [];
  ancSteps = [];
  ancDistance = [];
  for iTaxon = 1:nTaxa                          % Make list of ancestors for each taxon
    list = [];
    cumSteps = [];
    cumDistance = [];
    t = iTaxon;
    while (ancFn(t)>0)
      list = [list ancFn(t)];
      cumSteps = [0,cumSteps] + 1;
      cumDistance = [0,cumDistance] + branchLengths(t);
      t = ancFn(t);
    end;
    ancList = AppendRows(ancList,list);
    ancSteps = AppendRows(ancSteps,cumSteps);
    ancDistance = AppendRows(ancDistance,cumDistance);
  end;
  
  for iTaxon1 = 1:(nTaxa-1)                     % Find most recent common ancestors for all pairs of taxa
    for iTaxon2 = (iTaxon1+1):nTaxa 
      list1 = ancList(iTaxon1,:);                 % Lists of ancestors of two taxa
      list2 = ancList(iTaxon2,:);
      pos1 = 1;
      [b,pos2] = isin(list1(pos1),list2);
      while (~b)                                  % Find most recent common ancestor
        pos1 = pos1 + 1;
        [b,pos2] = isin(list1(pos1),list2);
      end;
      stepMatrix(iTaxon1,iTaxon2) = ancSteps(iTaxon1,pos1) + ancSteps(iTaxon2,pos2) - 1;
      distanceMatrix(iTaxon1,iTaxon2) = ancDistance(iTaxon1,pos1) + ancDistance(iTaxon2,pos2);
    end;
  end;
  
  stepMatrix = stepMatrix + stepMatrix';
  distanceMatrix = distanceMatrix + distanceMatrix';
 
  return;
