% MissEMReg: Schneider's (2001) functions for imputation of missing values via a
%         regularized expectation-maximization algorithm.
%
%     Usage: [dataComplete,xMeans,xCov,xStderr,propMiss,isTimeout] = MissEMReg(data)
%
%         data =         [n x p] data matrix containing NaNs for missing values.
%         ----------------------------------------------------------------------------
%         dataComplete = data matrix containing imputed values in place of NaNs.
%         xMeans =       estimated mean vector of data matrix.
%         xCov =         estimated covariance matrix of data matrix.
%         xStderr =      sparse matrix of estimated standard errors of imputed values.
%         propMiss =     proportion of missing data to be estimated.
%         isTimeout =    boolean flag indicating that convergence was not attained; 
%                         if so, other output matrices are set to null.
%

% Schneider, T. (2001). Analysis of incomplete climate data: estimation of mean values and 
%   covariance matrices and imputation of missing values. Journal of Climate, 14, 853�871.
% Modified from function regem at <//www.gps.caltech.edu/~tapio/imputation/#installation>.

function [X,M,C,Xerr,propMiss,isTimeout] = MissEMReg(X)
  isTimeout = false;
  Xerr = [];

  ndX = ndims(X);
  if (ndX > 2), error('  MissEMReg: X must be vector or 2-D array.'); end;
  if (ndX == 1)      
    X = X(:);                      
  end;
  [n,p] = size(X);
  dofC = n-1;                           % DF for estimation of covariance matrix       
  
  propMiss = sum(sum(~isfinite(X)))/numel(X);
  optreg       = [];                    % Initialize options structure for regression modules
  
  stagtol    = 5e-3;                    % Default options
  maxit      = 30;
  inflation  = 1;
  optreg.relvar_res = 5e-2;   
  optreg.minvarfrac = 0; 
    
  indmis = find(isnan(X));              % Indices of missing values
  nmis = length(indmis);
  if (nmis == 0)                        % If no missing values, return
    M = mean(X);
    C = cov(X);
    return;                                    
  end;
  
  [jmis,kmis]  = ind2sub([n, p], indmis);
  Xmis = sparse(jmis, kmis, NaN, n, p); % Initialize matrix of imputed values
  Xerr = sparse(jmis, kmis, Inf, n, p); % Initialize standard error imputed vals.
  
  kavlr = cell(n,1);
  kmisr = cell(n,1);
  for j=1:n                             % For each row of X, assemble column indices
    kavlr{j} = find(~isnan(X(j,:)));    %   of available values
    kmisr{j} = find(isnan(X(j,:)));     %   and of missing values
  end;

  [X, M] = center(X);                   % Center data to mean zero
  X(indmis) = zeros(nmis, 1);           % Fill missing entries with zeros
  C = X'*X / dofC;                      % Initial estimate of covariance matrix
  
  it = 0;
  rdXmis = Inf;
  while (it<maxit && rdXmis>stagtol)    % EM iteration
    it = it + 1;    

    CovRes = zeros(p,p);                  % Initialize residual covariance matrix for this iteration
    peff_ave = 0;                         % Initialize average effective number of variables 
    
    D = sqrt(diag(C));                    % Scale variables to unit variance
    const = (abs(D) < eps);               % Do not scale constant variables
    nconst = ~const;
    if (sum(const)~=0)             
      D = D .* nconst + 1*const;
    end;
    
    X = X ./ repmat(D', n, 1);
    C = C ./ repmat(D', p, 1) ./ repmat(D, 1, p);  % Correlation matrix
    
    for j=1:n                             % Cycle over records
      pm = length(kmisr{j});                % Number of missing values in this record
      if (pm>0)
        [B,S,h,peff] = mridge(C(kavlr{j},kavlr{j}), ...  % One multiple ridge regression per record
                              C(kmisr{j},kmisr{j}), ...
                              C(kavlr{j},kmisr{j}), n-1, optreg);
        peff_ave = peff_ave + peff*pm/nmis;	% Tally effective number of variables
        dofS = dofC - peff;                 % Residual degrees of freedom
        S = inflation * S;                  % Inflation of residual covariance matrix
        Xerr(j,kmisr{j}) = dofC/dofS * sqrt(diag(S))'; % Bias-corrected estimate of stderr of imputed values
        Xmis(j,kmisr{j}) = X(j,kavlr{j}) * B; % Missing value estimates
        CovRes(kmisr{j},kmisr{j}) = CovRes(kmisr{j},kmisr{j}) + S; % Tally contribution from residual covar matrices
      end;	
    end;  % Cycle over records                            
    
    X = X .* repmat(D',n,1);            % Rescale variables to original scaling 
    Xerr = Xerr .* repmat(D',n,1);
    Xmis = Xmis .* repmat(D',n,1);
    CovRes = CovRes .* repmat(D',p,1) .* repmat(D,1,p);
    
    dXmis = norm(Xmis(indmis)-X(indmis))/sqrt(nmis); % RMS change of missing values
    
    nXmis_pre  = norm(X(indmis)+M(kmis)')/sqrt(nmis);    % relative change of missing values
    if (nXmis_pre<eps)
      rdXmis = Inf;
    else
      rdXmis = dXmis/nXmis_pre;
    end;
    
    X(indmis) = Xmis(indmis);           % Update data matrix X
    [X,Mup] = center(X);                % Recenter data
    M = M + Mup;                        % Update mean vector
    C = (X'*X + CovRes)/dofC;           % Update covariance matrix estimate
  end;	% EM iteration
  
  X  = X + repmat(M,n,1);               % Restore means to centered data matrix
  
  return;
  
% ----------------------------------------------------------------------------------------
% center: Centers data matrix columns by subtraction of the mean.

function [xc,xm] = center(x)
  m = size(x,1);
  if (any(any(isnan(x))))               % Missing values in x
    xm  = nanmean(x);
  else                                  % No missing values
    xm  = mean(x);
  end;
  
  xc    = x - repmat(xm, m, 1);         % Remove means
  return;
  
% ----------------------------------------------------------------------------------------
% gcvridge: Finds minimum of generalized cross-validation function for ridge regression.

%   Adapted from GCV in Per Christian Hansen's REGUTOOLS toolbox:
%   P.C. Hansen, "Regularization Tools: A Matlab package for
%       analysis and solution of discrete ill-posed problems,"
%       Numer. Algorithms, 6 (1994), 1--35.

function h_opt = gcvridge(F,d,trS0,n,r,trSmin,options)
  error(nargchk(6,7,nargin))            % Check number of input arguments 

  d = d(:);                             
  if (length(d)<r)
    error('  MissEMReg (gcvridge): All nonzero eigenvalues must be given.')
  end;

  if (nargin==6 || isempty(options))
    fopts = [];
  else
    fopts = fieldnames(options);
  end;
    
  minvarfrac = 0;
  if strmatch('minvarfrac', fopts)
    minvarfrac = options.minvarfrac;
    if (minvarfrac<0 || minvarfrac>1)
      error('  MissEMReg (gcvridge): OPTIONS.minvarfrac must be in [0,1].')
    end;
  end;
  
  p = size(F,1);
  if (p<r)
    error(['  MissEMReg (gcvridge): F must have at least as many rows as there are nonzero' ...
	   ' eigenvalues d.']) 
  end;
  fc2 = sum(F.^2, 2);                   % Row sum-of-squared Fourier coefficients
  h_tol = .2/sqrt(n);                   % Accuracy of regularization parameter
  
  varfrac = cumsum(d)/sum(d);           % Heuristic upper bound on regularization parameter
  if (minvarfrac > min(varfrac))
    d_max = interp1(varfrac,d,minvarfrac, 'linear');
    h_max = sqrt(d_max);
  else            
    h_max = sqrt(max(d))/h_tol;    
  end;
  
  if (trS0 > trSmin)                    % Heuristic lower bound on regularization parameter
    h_min	= sqrt(eps);                    % Squared residual norm is greater than a priori bound for all
                                          %   regularization parameters
  else
    rtsvd = zeros(r,1);                   % Find squared residual norms of truncated SVD solutions
    rtsvd(r) = trS0;
    for j = r-1:-1:1
      rtsvd(j) = rtsvd(j+1) + fc2(j+1);
    end;
     
    [dummy, rmin] = min(abs(rtsvd-trSmin)); % Take regularization parameter equal to square root of eigenvalue 
    h_min = sqrt(max(d(rmin),min(d)/n));    %   that corresponds to TSVD truncation level with residual norm closest
                                            %   to a priori bound trSmin
  end;

  if (h_min < h_max)
    minopt = optimset('TolX',h_tol,'Display','off');  % Find minimizer of GCV function
    h_opt = fminbnd('gcvfctn',h_min,h_max,minopt,d(1:r),fc2(1:r),trS0,n-r);
  else
    disp(['  MissEMReg (gcvridge): Upper bound on regularization parameter smaller' ...
	     ' than lower bound.'])
    h_opt  = h_min; 
  end;

  return;
  
% ----------------------------------------------------------------------------------------
% mridge: Multiple ridge regression with generalized cross-validation.
function [B,S,h,peff] = mridge(Cxx,Cyy,Cxy,dof,options)
  px = size(Cxx, 1);
  py = size(Cyy, 1);
  if (size(Cxx,2)~=px || size(Cyy,2)~=py || any(size(Cxy)~=[px,py]))
    error('  MissEMReg (mridge): Incompatible sizes of covariance matrices.')
  end;
  
  if (isempty(options))
    fopts = [];
  else
    fopts = fieldnames(options);
  end;
    
  if (strmatch('regpar', fopts))
    h = options.regpar; 
    h_given = true;
  else
    h_given = false;
  end;
  
  if (strmatch('relvar_res', fopts))
    relvar_res = options.relvar_res; 
  else
    relvar_res = 5e-2;
  end;
  
  rmax = min(dof,px);                   % Maximum possible rank of Cxx
  [V,d,r] = peigs(Cxx,rmax);            % Eigendecomposition of Cxx
  
  F = repmat(ones(r,1)./sqrt(d),1,px).* V'*Cxy;  % Fourier coefficients
  
  if (dof>r)                            % Part of residual covariance matrix that does not 
    S0 = Cyy-F'*F;                      %   depend on the regularization parameter h:
  else
    S0 = sparse(py, py);
  end;
  
  if (~h_given)
    trSmin = relvar_res*trace(Cyy);                   % Approximate minimum squared residual
    h = gcvridge(F,d,trace(S0),dof,r,trSmin,options); % Regularization parameter that minimizes the GCV object function
  end;
  
  B = V * (repmat(sqrt(d)./(d+h^2),1,py).*F);         % Matrix of regression coefficients
  S = S0 + F'*(repmat(h^4./(d + h^2).^2,1,py).*F);    % Estimate of covariance matrix of residuals
  peff = sum(d./(d + h^2));                           % Effective number of adjusted parameters: peff = trace(Mxx_h Cxx)

  return;
  
% ----------------------------------------------------------------------------------------
% nanmean: Mean of available data, ignoring NaNs.

function mx = nanmean(x)
  max_miss = 0.99;                      % Maximum admissible fraction of missing values
  
  if (isempty(x))                       % Check for empty input.
    mx = NaN;
    return;
  end;
  
  if (length(x)==numel(x))              % If x is vector, make sure it is a row vector
    x = x(:);                         
  end;
  [m,n] = size(x);
  
  inan = find(isnan(x));                % Replace NaNs with zeros.
  x(inan) = zeros(size(inan));
  
  % Determine number of available observations on each variable
  [i,j] = ind2sub([m,n], inan);         % Subscripts of missing entries
  nans = sparse(i,j,1,m,n);             % Indicator matrix for missing values
  nobs = m - sum(nans);
    
  minobs  = m * (1 - max_miss); % NaN if too few entries to form robust average
  k = (nobs < minobs);
  nobs(k) = NaN;
  mx = sum(x)./nobs;

  return;
  
%----------------------------------------------------------------------------------------
% peigs: Finds positive eigenvalues and corresponding eigenvectors. 

function [V,d,r] = peigs(A,rmax)
  [m,n] = size(A);
 
  if (rmax > min(m,n))
    rmax  = min(m,n);                   % Rank cannot exceed size of A 
  end;
  
  warning off %#ok<WNOFF>
  eigsopt.disp = 0;                     % Do not display eigenvalues
  [V,d] = eigs(A,rmax,'lm',eigsopt);    % Get first rmax eigenvectors of A
  warning on %#ok<WNON>
  
  if (numel(d) > rmax)
    d = diag(d);                        % Ensure d is vector
  end;
  
  [d,I] = sort(-d);                     % Ensure that eigenvalues are monotonically decreasing
  d = -d;
  V = V(:,I);
  
  d_min = max(d)*max(m,n)*eps;          % Estimate number of positive eigenvalues of A
  r = sum(d>d_min);
  
  d = d(1:r);                           % Discard eigenpairs with eigenvalues that are close to or less than zero
  V = V(:,1:r);
  d = d(:);                             % Ensure d is column vector

  return;
  
