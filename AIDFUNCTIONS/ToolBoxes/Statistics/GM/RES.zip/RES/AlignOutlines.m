% AlignOutlines: Given two sets of 2D boundary coordinates that are not assumed to 
%     correspond point-for-point, matches the angular orientation of the second form 
%     by Procrustes superimposition.
%
%     Usage: form2Rot = AlignOutlines(form1,form2)
%
%         form1 =    [nPts1 x 2] matrix of point coordinates describing first outline.
%         form2 =    [nPts2 x 2] matrix of point coordinates describing second outline.
%         doPlots =  optional boolean flag indicating that plot of outlines is to be 
%                      produced [default = false].
%         -----------------------------------------------------------------------------
%         form2Rot = [nPts2 x 2] matrix of points for second outline rotated about
%                      its centroid to be maximally congruent with the first outline.
%

% RE Strauss, 6/12/08

function form2Rot = AlignOutlines(form1,form2)
  if (~nargin), help AlignOutlines; return; end;
  
  [nPts1,p] = size(form1);
  [nPts2,q] = size(form2);
  
  if (p~=2 || q~=2)
    error('  AlignOutlines: forms must be 2D.');
  end;
  
  nPts = 100;
  tol = 1e-6;
  
  if (eucl(form1(1,:),form1(end,:)) > tol)        % Close forms if necessary
    form1 = [form1; form1(1,:)];
  end;
  if (eucl(form2(1,:),form2(end,:)) > tol)        % Close forms if necessary
    form2 = [form2; form2(1,:)];
  end;
  
  crds1 = pathpts(form1,nPts+1);                  % Evenly distribute points along form boundaries
  crds2 = pathpts(form2,nPts+1);
  
  crds1(end,:) = [];                              % Open forms
  crds2(end,:) = [];
  
  sse = zeros(nPts,1);
  noScale = true;
  noPlot = true;
  for iPt = 1:nPts
    if (iPt>1)
      crds2New = [crds2(iPt:nPts,:); crds2(1:(iPt-1),:)]; % Slide starting point
    else
      crds2New = crds2;
    end;
    [map1,map2,mapa,sse(iPt)] = Lstra(crds1,crds2New,[],noScale,[],noPlot);
  end;
  
  [sseMin,pos] = min(sse);                            % Find arrangement of points giving best fit
  if (pos>1)
    crds2 = [crds2(pos:nPts,:); crds2(1:(pos-1),:)];  % Slide form2 boundary points
  end;
  crds2Centered = crds2 - ones(nPts,1)*mean(crds2);           % Center on centroid
  [map1,map2] = Lstra(crds1,crds2Centered,[],noScale,[],noPlot);   % Procrustes superimposition
  theta = AngleRotation([0,0],crds2Centered(1,:),map2(1,:));  % Find angle of rotation
  form2Rot = Rotate(form2,theta);                     % Rotate form2 about centroid
  form2Rot = [form2Rot; form2Rot(1,:)];           % Close rotated form
  
  return;
  
