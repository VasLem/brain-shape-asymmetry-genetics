% BinaryAutocorr: produces a pseudorandom NxP binary matrix, where the rows are autocorrelated.
%         Autocorrelated binary strings are generated using a stationary 1st-order Markov process.
%
%     Usage: binMat = BinaryAutocorr(r,matSize)
%
%         r = target autocorrelation coefficient.
%         matSize = 2-element vector specifying size of resulting matrix.  If 'matsize' is
%                     a scalar, a row vector is produced.
%         --------------------------------------------------------------------------------
%         binMat = resulting binary matrix.
%

% RE Strauss, 2/1/07

function binMat = BinaryAutocorr(r,matSize)
  if (~nargin), help BinaryAutocorr; return; end;
  
  if (length(matSize)==2)
    nRows = matSize(1);
    nCols = matSize(2);
  elseif (length(matSize)==1)
    nRows = 1;
    nCols = matSize;
  else
    error('  BinaryAutocorr: invalid matrix size.');
  end;

  p = 0.5*r+0.5;                    % Convert autocorrelation coeff to transition probability
  T = [p 1-p; 1-p p];               % Transition matrix
  
  binMat = zeros(nRows,nCols);
  binaryString = zeros(1,nCols);

  for row = 1:nRows
    binaryString(1) = round(rand);
    for pos = 2:nCols
      probVector = T(binaryString(pos-1)+1);
      binaryString(pos) = sum(rand>=cumsum(probVector));
    end;
    binMat(row,:) = binaryString;
  end;
  
  return;

