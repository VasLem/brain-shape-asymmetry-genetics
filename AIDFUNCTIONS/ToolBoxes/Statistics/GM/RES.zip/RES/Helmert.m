% Helmert: produces a Helmert matrix of size n x n, a permutation of a lower Hessenberg matrix,
%         with a first row of ones(1:n)/sqrt(n) and a triangle of zeros above the principal 
%         diagonal.  A Helmert matrix is a type of an orthogonal contrast matrix:
%           The first row constructs an average.
%           The second row contrasts the second element with the first element.
%           The third row contrasts the third element with the mean of the first two elements.
%           The fourth row contrasts the fourth element with the mean of the first three elements.
%           Etc.
%

% RE Strauss, 5/20/08

function h = Helmert(m)
  h = gallery('orthog',m,4);
  return;
  
