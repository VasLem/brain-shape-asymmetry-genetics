% NNSpatialPattern: Given a set of 2D point coordinates, determines whether the distribution of
%     points is consistent with a random distribution, is clustered, or is overdispersed, based
%     on k-nearest neighbor distances.  If a polygon for the domain is provided, the test is 
%     based on all points.  If the domain is not provided, uses the convex hull of the points 
%     and tests only the interior points.  
%       Uses the Po modification of Pollard's (1971) statistic, as described by Liu (2001).
%     For each distance order, approximately Po =1 for complete spatial randomness (CSR), >1 
%     for aggregation, and <1 for overdispersion.  Pollard's statistic M/C = (n-1)Po, which is 
%     approximately distributed as chi-square with n-1 df.
%
%     Usage: [pObs,pRand,pProb,pSignif] = ...
%                   NNSpatialPattern(crds,{domain},{maxOrder},{nIters},{noPlots},{alpha})
%
%         crds =     [nPts x 2] matrix of point coordinates.
%         domain =   optional set of point coordinates defining the convex domain of the coordinates
%                      [default = null].
%         maxOrder = optional maximum distance order (kth nearest neighbor) considered
%                      [default = lesser of 10 or (number of interior points)-1].
%         nIters =   optional number of randomization iterations [default = 1000].
%         noPlots =   optional boolean flag indicating that plot of points and of Pollard statistics 
%                      are to be suppressed [default = false].
%         alpha =    optional overall alpha-level for significance tests [default = 0.05].
%         ------------------------------------------------------------------------------------------
%         pObs =     [maxOrder x 1] vector of observed Po values.
%         pRand =    corresponding vector of mean randomized Po values.
%         pProb =    corresponding vector of 2-tailed significance levels (p-values).
%         pSignif =  corresponding boolean results of significance tests at alpha, based on
%                      sequential Bonferroni adjustments.
%

% Pollard, JH. 1971. On distance estimators of density in randomly distributed forests.
%     Biometrics 27:991-1002.
% Liu, C. 2001. A comparison of five distance-based methods for spatial pattern analysis.
%     Journal of Vegatation Science 12:411-416.

% RE Strauss, 4/23/08

function [pObs,pRand,pProb,pSignif] = NNSpatialPattern(crds,domain,maxOrder,nIters,noPlots,alpha)
  if (~nargin), help NNSpatialPattern; return; end;
  
  if (nargin<2), domain = []; end;
  if (nargin<3), maxOrder = []; end;
  if (nargin<4), nIters = []; end;
  if (nargin<5), noPlots = []; end;
  if (nargin<6), alpha = []; end;
  
  if (isempty(maxOrder)), maxOrder = 10; end;
  if (isempty(nIters)),   nIters = 1000; end;
  if (isempty(noPlots)),   noPlots = false; end;
  if (isempty(alpha)),    alpha = 0.05; end;
  
  [nPts,nDimens] = size(crds);
  if (nDimens~=2)
    error('  NNSpatialPattern: 2-dimensional coordinates only.');
  end;
  
  usePts = 1:nPts;                            % Set domain polygon and indices of points to test
  if (isempty(domain))
    [domain,pos] = hull(crds);
    usePts(pos) = [];
    nPts = length(usePts);
  else
    domain = hull(domain);
  end;
	maxOrder = min([maxOrder,nPts-1]);          % Adjust max order if necessary

  
  xMin = min(domain(:,1));                    % Enclosing rectangle of domain
  xMax = max(domain(:,1));
  yMin = min(domain(:,2));
  yMax = max(domain(:,2));
  xRange = xMax-xMin;
  yRange = yMax-yMin;
  
  pObs = GetPoValues(crds,usePts,maxOrder); 	% Get observed Po statistics
  
  pRand = zeros(nIters,maxOrder);             % Allocate randomized distributions of Po
  randCrds = zeros(nPts,2);                   % Allocate randomized interior points
  
  for it = 1:nIters                           % Get randomized distributions for random points
    n = 0;
    while (n<nPts)                              % Get random points within domain
      n = n+1;
      randPt = [xMin-1,yMin-1];                   % Get single random pt
      while (~isinpoly(randPt,domain))
        randPt(1) = rand*xRange + xMin;
        randPt(2) = rand*yRange + yMin;
      end;
      randCrds(n,:) = randPt;
    end;
    pRand(it,:) = GetPoValues(randCrds,1:nPts,maxOrder);  % Accumulate null distributions
  end;
  
  pProbRight = bootprob(pObs,pRand)';       	% Estimate 2-tailed p-values
  pProbLeft = 1-pProbRight;
  pProb = 2*min([pProbRight; pProbLeft]);
  pProb = max([pProb; ones(1,maxOrder)/nIters]);
  
  pSignif = seqbonf(pProb,alpha);
  pRand = mean(pRand);                        % Return means of null distributions
  
  if (~noPlots)                               % Plot of points and domain
    figure;
    plot(crds(:,1),crds(:,2),'ko',domain(:,1),domain(:,2),'k');
    axis equal;
    axis off;
  end;
  
  if (~noPlots)                                % Plot of observed and mean randomized Po values
    figure;
    j = 1:maxOrder;
    pos = find(pProb<=alpha);
    plot(j,pObs,'b',j,pRand,'k');
    putbnds([j,j],[pObs,pRand]);
    legend('Observed','Randomized');
    hold on;
    plot(j,pObs,'bo',j,pRand,'ko');
    plot(j(pos),pObs(pos),'b*');
    hold off;
    putxlab('Nearest-neighbor order');
    putylab('Pollard statistic value P_{o}');
  end;
  
  return;
  
% ---------------------------------------------------------------------------------------------

function p = GetPoValues(crds,usePts,maxOrder)
  nPts = length(usePts);
  nnDists = zeros(nPts,maxOrder);             % Allocate k-nearest neighbor distances
  p = zeros(1,maxOrder);                      % Allocate Po statistics

  for pt = 1:nPts                             % Cycle thru interior points
    otherPts = usePts;
    otherPts(pt) = [];
    d = sort(eucl(crds(usePts(pt),:),crds(otherPts,:))); % Sorted dists to other points
    nnDists(pt,:) = d(1:maxOrder);            % Stash in distance matrix
  end;
  
  n = nPts;
  for j = 1:maxOrder                          % Modified Pollard's statistic for each distance order
    d = nnDists(:,j);                           % Distances for current order
    t1 = 12*j*j*n;
    t21 = d'*d/n;
    t22 = log(d.*d);
    t2 = n*log(t21)-sum(t22);
    t3 = (6*j*n+n+1)*(n-1);
    p(j) = t1*t2/t3;
  end;

  return;
  
