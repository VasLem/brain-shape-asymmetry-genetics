% GsscRescaleScores

function scores = GsscRescaleScores(colsEL)
  [nStudents,nCols] = size(colsEL);
  if (nCols ~= 8)
    error('  GsscRescaleScores: invalid input columns');
  end;
  
  [verbal,quant,analytical,vq,gpa,toefl,category,subjective] = ExtractCols(colsEL);
  greScore = zeros(nStudents,1);
  gpaScore = zeros(nStudents,1);
  subjectiveScore = zeros(nStudents,1);
  gre = zeros(nStudents,1);
  
  for i = 1:nStudents
    analytical(i) = analytical(i)*100+200;          % Convert 1-6 scale to 200-800
    gre(i) = verbal(i) + quant(i) + analytical(i);	% Rescale GRE
    switch (category(i))
      case 3, greScore(i) = (gre(i)/150) - 8.5;
      case 2, greScore(i) = (gre(i)/150) - 8.5;
      case 1, greScore(i) = (gre(i)/150) - 7.5;
    end;
  
    switch (category(i))                            % Rescale GPA
      case 3, gpaScore(i) = 4*gpa(i) - 10.5;
      case 2, gpaScore(i) = 4*gpa(i) - 10.0;
      case 1, gpaScore(i) = 4*gpa(i) - 9.5;
    end;
  
    subjectiveScore(i) = subjective(i);             % Copy subjective score
  end;
  
  totalScore = 0.4*subjectiveScore + 0.3*greScore + 0.3*gpaScore; % Weighted mean
  scores = [subjectiveScore greScore gpaScore totalScore];        % Concatenate
  scores = min(scores,5);                                         % Enforce limits 0-5
  scores = max(scores,0);
  
  return;
  