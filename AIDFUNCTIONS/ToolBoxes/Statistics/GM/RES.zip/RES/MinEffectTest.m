% MinEffectTest: Given the observed F-statistic value and corresponding degrees of freedom
%                from a linear model, performs a minimum-effect hypothesis test based on
%                Murphy & Myors (1998).
%
%     Usage: [pME,pC,fCrit,power] = MinEffectTest(fStat,nu1,nu2,{pv},{alpha},{noPlot})
%
%         fStat =   observed F-statistic value from statistical test.
%         nu1,nu2 = degrees of freedom corresponding to F.
%         PV =      optional desired minimum-effect, as proportion of total variance
%                     [default = 0.01].
%         alpha =   optional alpha-level of test [default = 0.05].
%         noplot =  optional boolean flag indicating, if true, that the plot of
%                     null and sampling distributions is to be suppressed.
%         --------------------------------------------------------------------------
%         pME =    significance level for minimum-effect test of null hypothesis.
%         pC =     significance level for conventional nil hypothesis.
%         fCrit =  critical minimum-effect F value for the given value of alpha.
%         power =   estimate of post-hoc power.
%

% Murphy, K.R. and B. Myors. 1998. Statistical Power Analysis.  Lawrence Erlbaum Assoc.,
%   Mahwah NJ, 120 p.

% RE Strauss, 10/19/04

function [pME,pC,Fcrit,power] = MinEffectTest(fStat,nu1,nu2,pv,alpha,noPlot)
  if (nargin < 1), help MinEffectTest; return; end;
  
  if (nargin < 4), pv = []; end;
  if (nargin < 5), alpha = []; end;
  if (nargin < 6), noPlot = []; end;
  
  if (isempty(pv)),     pv = 0.01; end;
  if (isempty(alpha)),  alpha = 0.05; end;
  if (isempty(noPlot)), noPlot = 0; end;
  
  if (pv > 1),    pv = pv/100; end;
  if (alpha > 1), alpha = alpha/100; end;
  
  nPts = 200;                                   % Number of points to sample pdf

  pvF = (nu1*fStat)/(nu1*fStat+nu2);            % Convert F to percent variance
  lambdaSamp = nu2*pvF/(1-pvF);                 % Noncentrality parameter of sampling distribution
  lambdaNull = nu2*pv/(1-pv);                   % Noncentrality parameter of null distribution
  
  Fcrit = ncfinv(1-alpha,nu1,nu2,lambdaNull);   % Get critical value and power
  pME = 1-ncfcdf(fStat,nu1,nu2,lambdaNull);   	% Min-effect significance level
  pC = 1-fcdf(fStat,nu1,nu2);                 	% Conventional significance level
  power = 1-ncfcdf(Fcrit,nu1,nu2,lambdaSamp);   % Post-hoc power

  if (~noPlot)                                  % Plot null and sampling distributions
    f = linspace(0,50,nPts);                      % Get distributions
    fSamp = ncfpdf(f,nu1,nu2,lambdaSamp); 
    i = nPts;                                     % Truncate X-axis at upper end
    while (fSamp(i)<0.008)
      i = i-1;
    end;
    fMax = f(i);
    f = linspace(0,fMax,nPts);
    fNull = ncfpdf(f,nu1,nu2,lambdaNull);
    fSamp = ncfpdf(f,nu1,nu2,lambdaSamp);
    maxFreq = max([fNull,fSamp]);
    
    figure;
    plot(f,fNull,'k');
    hold on;
    plot(f,fSamp,'k',[Fcrit,Fcrit],[0,ncfpdf(Fcrit,nu1,nu2,lambdaSamp)],'k');
    hold off;
    axis([0 fMax 0 1.1*maxFreq]);
    putxlab('F');
    putylab('Frequency');
    puttext(0.55,0.90,sprintf('F =%5.2f, df = %d,%d',fStat,nu1,nu2));
    puttext(0.55,0.82,['\alpha',sprintf(' = %5.3f',alpha)]);
    puttext(0.55,0.74,sprintf('F_{crit} = %4.2f',Fcrit));
    if (pME<0.001)
      puttext(0.55,0.66,'p_{ME} < 0.001');
    else
      puttext(0.55,0.66,sprintf('p_{ME} = %5.3f',pME));
    end;
    if (pC<0.001)
      puttext(0.55,0.58,'p_{Conv} < 0.001');
    else
      puttext(0.55,0.58,sprintf('p_{Conv} = %5.3f',pC));
    end;
    puttext(0.55,0.50,sprintf('Power = %4.2f',power));
    s = num2str(pv*100);
    puttitle([s,'% minimum-effect test']);
  end;

  return;
  
