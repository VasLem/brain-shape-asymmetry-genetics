% PolygonOverlap:  Finds the area of overlap (intersection) of two 2-dimensional 
%                  polygons, which need not be convex.
%
%     Usage:  [absArea,relArea] = PolygonOverlap(polygon1,polygon2)
%
%            polygon1 = [np x 2] matrix of vertex coordinates for polygon P.
%            polygon2 = [nq x 2] matrix of vertex coordinates for polygon Q.
%            ---------------------------------------------------------------
%            absArea = absolute area of overlap.
%            relArea = relative area of overlap.
%        

% Zerzan, J.M. 1989. OVERLAP: a FORTRAN program for rapidly evaluating the area
%   of overlap between two polygons.  Computers & Geosciences 15:1109-1114.

% RE Strauss, 5/7/97
%   7/13/07 - updated and renamed from 'polyolap'.

function [absArea,relArea] = PolygonOverlap(polygon1,polygon2)
  if (~nargin), help PolygonOverlap; return; end;
  
  absArea = 0;
  relArea = 0;

  [nPoly1,nCols1] = size(polygon1);
  [nPoly2,nCols2] = size(polygon2);
  
  if (nCols1~=2 || nCols2~=2)
    error('  PolygonOverlap: Polygon coordinate matrices must each have two columns.');
  end;

  calcRelArea = false;                                 % Flag to calculate relative area
  if (nargout>1), calcRelArea = true; end;
  
  if ((rowsum(polygon1(1,:))-rowsum(polygon1(end,:)))>eps)  % Close polygons if open
    polygon1 = [polygon1; polygon1(1,:)];
  else
    nPoly1 = nPoly1-1;    
  end;
  if ((rowsum(polygon2(1,:))-rowsum(polygon2(end,:)))>eps)  % Close polygons if open
    polygon2 = [polygon2; polygon2(1,:)];
  else
    nPoly2 = nPoly2-1;    
  end;

  % Determine the vertices of each polygon that lie within the other, 
  % and the intersection points of the polygons.  
  % Make list of subpolygon vertex ordinates, sorted vertically.

  poly1InPoly2 = [Isinpoly(polygon1(1:nPoly1,:),polygon2); false];
  poly2InPoly1 = [Isinpoly(polygon2(1:nPoly2,:),polygon1); false];

  polyEdges1 = [polygon1(1:nPoly1,:), polygon1(2:nPoly1+1,:)];
  polyEdges2 = [polygon2(1:nPoly2,:), polygon2(2:nPoly2+1,:)];

  [doIntersect,x,y] = intrsect(polyEdges1,polyEdges2);
  doIntersect = doIntersect(:);
  y = y(:);
  
  if (~any(doIntersect))                                % Exit if no overlap
    return;
  end;

  yValues = sort([polygon1(poly1InPoly2,2); polygon2(poly2InPoly1,2); y(doIntersect)]);

  % Find heights and vertical addresses (y values) of lateral 
  % midpoints of trapezoids.  Find all horizontal intersections 
  % of midpoints with both polygons.

  xMin = min([polygon1(:,1);polygon2(:,1)]);      % Extent of abscissa
  xMax = max([polygon1(:,1);polygon2(:,1)]);

  midpoints = [];
  tol = 1e-6;
  for i = 1:(length(yValues)-1)                   % Cycle thru lateral midpoints
    h = yValues(i+1)-yValues(i);                    % Trapezoid height
    if (h > tol)                                    % If new trapezoid, save lateral midpoints
      y = (yValues(i)+yValues(i+1))/2;
      [doIntersect,x,y] = intrsect([xMin y xMax y],[polyEdges1;polyEdges2]);
      x = x(doIntersect)';
      y = y(doIntersect)';
      [x,j] = sort(x);
      xy = [x y(j)];                                % Midpoints
      lenX = length(x);
      ident = [all((xy(1:(lenX-1),:)==xy(2:lenX,:))'),0];
      xy = xy(~ident,:);                            % Delete repeated points
      midpoints = [midpoints; xy h*ones(size(xy,1),1)]; % Keep midpoints & corresponding height
    end;
  end;

  % Keep only the horizontal intersections that are common to both 
  % polygons.  These are the midpoints on the subpolygons.

  midpoints = midpoints((Isinpoly(midpoints(:,1:2),polygon1) & Isinpoly(midpoints(:,1:2),polygon2)),:);

  absArea = 0;                           % Absolute overlap
  for i = 1:2:size(midpoints,1)
    w = midpoints(i+1,1)-midpoints(i,1);
    absArea = absArea + w*midpoints(i,3);
  end;

  if (calcRelArea)                            % Relative overlap
    relArea = 2*absArea/(polyarea(polygon1)+polyarea(polygon2));
  end;

  return;

