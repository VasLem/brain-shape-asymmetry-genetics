% Corrcomp: Compare the correlation coefficients for two groups to determine 
%           whether they are significantly different, for any number of variables.  
%           The two groups must have data for the same set of variables, but can differ 
%           in sample size.  Uses Hotelling's (1953) small-sample modification of Fisher's 
%           z-transform.  Ignores missing data.
%
%     Usage: [pr,signif,df,corrMat1,corrMat2] = Corrcomp(data1,data2,{multCompare},{alpha})
%
%         data1 =       [n x p] data matrix for group 1.
%         data2 =       [m x p] data matrix for group 2.
%         multCompare =	optional boolean value indicating, if true, that judgments 
%                         about statistical significance are to be based on the 
%                         sequential Bonferroni test [default = false].
%         alpha =       optional alpha level for significance tests 
%                         [default = 0.05].
%         ----------------------------------------------------------------------
%         pr =          [p x p] matrix of probabilities of identity of correlation 
%                         coefficients.
%         signif =      corresponding boolean matrix of significance decisions.
%         df =          degrees of freedom for all tests.
%         corrMat1 =    correlation matrix for group 1.
%         corrMat2 =    correlation matrix for group 2.
%

% RE Strauss, 6/19/01
%   6/20/01 - ignore missing data by deleting observations.
%   2/20/07 - standardize variable names;
%             return degrees of freedom.

function [pr,signif,df,corrMat1,corrMat2] = Corrcomp(data1,data2,multCompare,alpha)
  if (~nargin), help Corrcomp; return; end;
  
  if (nargin < 3), multCompare = []; end;
  if (nargin < 4), alpha = []; end;

  if (isempty(multCompare)), multCompare = false; end;
  if (isempty(alpha)),       alpha = 0.05; end;

  i = isfinite(rowsum(data1));
  data1 = data1(i,:);
  i = isfinite(rowsum(data2));
  data2 = data2(i,:);

  [n1,p] = size(data1);
  [n2,q] = size(data2);
  if (p~=q)
    error('  CORRCOMP: data matrices must have same number of variables.');
  end;

  corrMat1 = corrcoef(data1);
  corrMat2 = corrcoef(data2);

  [Z1,stdErr1] = corrz(corrMat1,n1,1);
  [Z2,stdErr2] = corrz(corrMat2,n2,1);
  v1 = stdErr1*stdErr1*n1;
  v2 = stdErr2*stdErr2*n2;
  pr = zeros(size(Z1));
  df = n1+n2-2;

  for i = 1:p-1
    for j = i+1:p
      m1 = Z1(i,j);
      m2 = Z2(i,j);
      t = abs(m2-m1)./sqrt((((n1-1).*v1+(n2-1).*v2)./(n1+n2-2)).*((n1+n2)./(n1.*n2)));
      pr(i,j) = 1-tcdf(t,df);
    end;
  end;

  pr = pr + pr';
  p = trilow(pr);

  if (multCompare && p>2)
    signif = trisqmat(seqbonf(p,alpha));
    signif = signif + signif';
  else
    signif = (pr <= alpha);
    signif = putdiag(signif,0);
  end;

  return;
