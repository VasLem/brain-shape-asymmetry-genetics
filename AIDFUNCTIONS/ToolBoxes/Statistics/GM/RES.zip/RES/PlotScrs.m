plot( scores(:,1),scores(:,2),'*k' )
return;
