% NeighborJoin: Finds an additive tree networks from a distance matrix using the Saitou & 
%         Nei (1987) neighbor-joining method, simplified as in Studier & Kepler (1988).  
%         Uses the Kuhner & Felsenstein (1994) method to adjust negative branch lengths.  
%         The network is rooted at a specified outgroup to form an additive tree.  
%         If no outgroup is specified, Farris' (1972: 658) minimum rate-heterogeneity 
%         criterion is used to estimate the root.  Returns an ancestor function and 
%         vector of corresponding branch lengths.  
%
%     Usage: [ancFn,branchLns,support,patrist] = NeighborJoin(dist,{outgroup},{labels},{noPlot},{fontSize})
%
%         dist =      [n x n] symmetric distance matrix for n taxa.
%         outgroup =  optional index of outgroup taxon, used only to root the tree.    
%                       If omitted or null, Farris' (1972: 658) minimum 
%                       rate-heterogeneity criterion is used to estimate the root.
%         labels =    optional matrix of labels (rows of string matrix) for terminal 
%                       taxa [default = sequence number in data matrix].
%         noPlot =    optional boolean flag indicating that tree is not to be 
%                       drawn [default = false].
%         fontSize =  optional font size for printed labels on tree [default = 10].
%         --------------------------------------------------------------------------
%         ancFn =       [1 x 2n-1] vector specifying ancestor function, with ancestor 
%                       of root specified as 0.
%         branchLns =     optional corresponding vector of branch lengths.
%         support =   [(n-2) x (n-1)] matrix, with one row for all but the base 
%                       node, specifying group membership (support) at each node.
%         patrist =   [n x n] symmetric patristic distance matrix.
%

% If a branch length is negative, it is set to zero and the difference transferred to 
% the adjacent branch.  Moves the position of the node, but doesn't affect the total distance 
% between an adjacent pair of nodes.  But if the branch length of the adjacent branch then 
% becomes negative, it is set to zero, lengthing the distance between adjacent pair of nodes 
% and thus the total tree length.

% Farris, JS. 1972. Estimating phylogenetic trees from distance matrices.  Am. Nat.
%   106:645-668.
% Kuhner, MK & J Felsenstein. 1994. A simulation comparison of phylogeny algorithms 
%   under equal and unequal evolutionary rates.  Mol. Biol. Evol. 11:459-468.
% Saitou, N & M Nei. 1987. The neighbor-joining method: a new method for reconstructing 
%   phylogenetic trees.  Mol. Biol. Evol. 4:406-425.
% Studier, JA and KJ Kepler. 1988. A note on the neighbor-joining algorithm of Saitou 
%   and Nei.  Mol. Biol. Evol. 5:729-731.
% Swofford, DL, GJ Olsen, PJ Waddell, & DM Hillis. 1996. Phylogenetic inference.  
%   Pp 407-514 (ch 11), in DM Hillis, C Moritz & BK Mable, Molecular Systematics, 2nd ed.
%   Sinauer.

% RE Strauss, 8/17/98
%   8/29/03 - corrected a subscripting problem;
%             called issqsym() to check whether input matrix is square-symmetric.

function [ancFn,branchLns,support,patrist] = NeighborJoin(dist,outgroup,labels,noPlot,fontSize)
  if (~nargin), help NeighborJoin; return; end;

  nRows = size(dist,1);                      % Check distance matrix

  if (nargin < 2), outgroup = []; end;
  if (nargin < 3), labels = [];   end;
  if (nargin < 4), noPlot = []; end;
  if (nargin < 5), fontSize = []; end;

  if (~issqsym(dist) || sum(diag(dist))>0)
    error('  NeighborJoin: distance matrix must be square symmetric, zeros on diagonal');
  else
    nTaxa = nRows;
  end;

  getSupport = false;
  getPatrist = false;
  if (nargout > 2), getSupport = true; end;
  if (nargout > 3), getPatrist = true; end;

  if (isempty(outgroup)), outgroup = 0; end;
  if (isempty(labels)),   labels = tostr(1:nTaxa); end;
  if (isempty(noPlot)),   noPlot = false; end;
  if (isempty(fontSize)), fontSize = 10; end;

  taxon = 1:nTaxa;                            % Initial terminal-taxon labels
  
  ancFn = zeros(1,2*nTaxa-1);                   % Ancestor function
  branchLns = ancFn;                                % Branch lengths

  for step = 1:(nTaxa-1)                      % Find tree
    nextNode = nTaxa+step;
    n = nTaxa-step+1;
    r = sum(dist);                             % Net adj divergences from all other taxa

    if (step == nTaxa-1)
      i = 1;
      j = 2;
    else
      M = zeros(n,n);                         % Find min rate-corrected distance
      for i = 1:(n-1)
        for j = (i+1):n
          M(j,i) = dist(i,j) - (r(i)+r(j))/(n-2);
        end;
      end;

      [c,j,i] = trilow(M);      
      M = min(c);                           % Find taxon pair having min rate-corr dist
      k = find(c-M < eps);

      if (length(k)>1)                        % >1 min
        d = trilow(dist);                          % Find min original dist
        [dmin,di] = min(d(k));
        i = i(k(di));
        j = j(k(di));
      else                                    % Unique min value
        i = i(k);
        j = j(k);
      end;
    end;

    ancFn(taxon(i)) = nextNode;                   % Attach taxa to common node
    ancFn(taxon(j)) = nextNode;

    d = dist(i,j);                           % Branch lengths of taxa to node
    if (step == nTaxa-1)
      branchLns(taxon(i)) = d/2;
      branchLns(taxon(j)) = d/2;
    else
      branchLns(taxon(i)) = d/2 + (r(i)-r(j))/(2*n-4);
      branchLns(taxon(j)) = d - branchLns(taxon(i));

      if (branchLns(taxon(i))<0)                % If negative branch length,
        branchLns(taxon(j)) = branchLns(taxon(j))+branchLns(taxon(i));    % Transfer to adjacent branch
        if (branchLns(taxon(j))<0)                % If adjacent branch negative,
          branchLns(taxon(j)) = 0;                %   set equal to zero (lengthing the tree)
        end;
        branchLns(taxon(i)) = 0;                   % Set original negative branchLns equal to zero
      elseif (branchLns(taxon(j))<0)
        branchLns(taxon(i)) = branchLns(taxon(i))+branchLns(taxon(j));   
        if (branchLns(taxon(i))<0)                
          branchLns(taxon(i)) = 0;                
        end;
        branchLns(taxon(j)) = 0;                  
      end;

      dnew = zeros(n-2,1);
      kk = 0;
      for k = 1:n                           % Dists from node to other taxa
        if (k~=i && k~=j)
          kk = kk+1;
          dnew(kk) = 0.5*(dist(i,k)+dist(j,k)-d);
        end;
      end;

      dist([i,j],:) = [];                      % Remove taxa from distance matrix
      dist(:,[i,j]) = [];
      dist = [dist, dnew; dnew', 0];

      taxon([i,j]) = [];
      taxon = [taxon, nextNode]; %#ok<AGROW>
    end;
  end;

  if (outgroup)                                 % If outgroup taxon is specified,
    [ancFn,branchLns] = reroot(ancFn,branchLns,outgroup);   %   root there,
  else
    [ancFn,branchLns] = treeroot(ancFn,branchLns);          %   else root by min var(patristic dists)
  end;

  if (getSupport)
    support = zeros(nTaxa-2,nTaxa-1);
    r = 0;
    for node = (nTaxa+1):(2*nTaxa-1)
      if (ancFn(node))
        tips = treetips(ancFn,node)';
        r = r+1;
        support(r,1:length(tips)) = tips;
      end;
    end;
  end;
  
  if (getPatrist)
    patrist = zeros(nTaxa,nTaxa);
    
    anc = zeros(nTaxa,2*nTaxa-1);
    for t = 1:nTaxa                                       % List ancestors for each taxon
      anc(t,1) = t;
      a = ancFn(t);
      pos = 1;
      while (a>0)
        pos = pos+1;
        anc(t,pos) = a;
        a = ancFn(a);
      end;
    end;
    for t1 = 1:(nTaxa-1)                                  % For all pairs of taxa,
      for t2 = (t1+1):nTaxa
        m = ismember(anc(t1,:),anc(t2,:));                  % Find common node
        commonNode = anc(t1,min(find(m))); %#ok<MXFND>
        p1 = 1:find(anc(t1,:)==commonNode);
        p2 = 1:find(anc(t2,:)==commonNode);
        d1 = sum(branchLns(anc(t1,p1)));                    % Sum branch lengths back to common node
        d2 = sum(branchLns(anc(t2,p2)));
        patrist(t1,t2) = d1+d2;                             % Stash in distance matrix
      end;
    end;
    patrist = patrist + patrist';                           % Fill in other half of distance matrix
  end;

  if (~noPlot)
    TreePlot(ancFn,branchLns,labels,0,fontSize);
  end;

  return;

