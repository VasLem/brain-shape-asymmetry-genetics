% FourierElliptRecon: Inverse elliptical Fourier transform from the coefficients
%         produced by FourierEllipt.m.  Reconstructs an approximation to the original
%         outline based on the specified number of harmonics, producing the specified
%         number of points on the outline.  Optionally plots the reconstructed outline
%         both without and with points.
%
%     Usage: outline = FourierElliptRecon(coeffs,{nHarm},{crds},{nPts},{noPlot})
%
%         coeffs -	[4 x nHarm] matrix of elliptical Fourier coefficients.
%         nHarm -   optional number of harmonics (>1) to be used in reconstruction
%                     [default = all].
%         crds -    optional input coordinates originally used to calculate harmonics,
%                     for orientation of reconstructed form.
%         nPts -    optional number of outpoint points describing boundary [default = 100].
%         noPlot -  optional boolean value indicating that plots of outline are not to be
%                     produced [default = false].
%         ---------------------------------------------------------------------------------
%         outline - [nPts x 2] matrix of point coordinates of closed boundary.
%

% RE Strauss, 5/17/08

% Kuhl, FP and CR Giardina. 1982. Elliptic Fourier features of a closed contour.
%     Computer Graphics and Image Processing 18:236-258.
% Based on David Thomas' function rEfourier.m (Matlab Central).

function outline = FourierElliptRecon(coeffs,nHarm,crds,nPts,noPlot)
  if (~nargin), help FourierElliptRecon; return; end;
  
  [r,c] = size(coeffs);
  
  if (nargin<2), nHarm = []; end;
  if (nargin<3), crds = []; end;
  if (nargin<4), nPts = []; end;
  if (nargin<5), noPlot = []; end;
  
  if (isempty(nHarm)),  nHarm = c; end;
  if (isempty(nPts)),   nPts = 100; end;
  if (isempty(noPlot)), noPlot = false; end;
  
  if (nHarm > c)
    disp(sprintf('  FourierElliptRecon warning: max of %d harmonics used for reconstruction.',c));
    nHarm = c;
  end;

  outline = zeros(nPts,2);                        % Allocate outline
  startHarm = 2;                                  % Harmonic 1 is nn offset, added later
  
  for t = 1:nPts                                  % Reconstruct x projection
    cumHarm = 0.0;
    for ih = startHarm:nHarm                        % Sum harmonics
     	cumHarm = cumHarm + (coeffs(1,ih) * cos(2*(ih-1)*pi*t / nPts) + ...
                  coeffs(2,ih) * sin(2*(ih-1)*pi*t / nPts));
    end;
   	outline(t,1) = coeffs(1,1) + cumHarm;           % Add harmonic 1 (=A0)
  end % for t = 1 : nPts

  for t = 1:nPts                                  % Reconstruct y projection
    cumHarm = 0.0;
    for ih = startHarm:nHarm                        % Sum harmonics
   	  cumHarm = cumHarm + (coeffs(3,ih) * cos(2*(ih-1)*pi*t / nPts) + ...
            	    coeffs(4,ih) * sin(2*(ih-1)*pi*t / nPts));
    end;
   	outline(t,2) = coeffs(3,1) + cumHarm;           % Add harmonic 1 (=C0)
  end % for t = 1 : nPts

  outline = [outline; outline(1,:)];              % Close outline
  
  if (~isempty(crds))                             % Optionally align with original crds
    outline = AlignOutlines(crds,outline);
  end;

  if (~noPlot)                                    % Plot outline
    figure;
    plot(outline(:,1),outline(:,2),'k');
    putbnds(outline(:,1),outline(:,2));
    axis equal;
    axis off;
    
%     figure;
%     plot(outline(:,1),outline(:,2),'k',outline(:,1),outline(:,2),'k.');
%     putbnds(outline(:,1),outline(:,2));
%     axis equal;
  end;
  
  return;
