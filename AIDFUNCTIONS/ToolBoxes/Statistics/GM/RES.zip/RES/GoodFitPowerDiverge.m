% GoodFitPowerDiverge:  Power divergence goodness-of-fit test (Cressie & Read 1984), 
%           indexed by the parameter lambda.  Pearson's chi-squared test 
%           (lambda=1), the likelihood-ratio G test (lambda=0), and the 
%           Freeman-Tukey test (lambda=-0.5) are all members of the power 
%           divergence family of test statistics.  Cressie & Read (1984) 
%           recommend lambda=2/3 for best approximation to a chi-squared 
%           sampling distribution.
%
%     Usage: [x2,df,pr,x2Cell] = GoodFitPowerDiverge(obs,exp,{df},{lambda})
%
%           obs =     matrix of observed counts.
%           exp =     matrix of correpsonding expected counts.
%           df =      optional degrees of freedom [default = nbins-1].
%           lambda =  optional power-divergence parameter [default = 2/3].
%           --------------------------------------------------------------
%           x2 =      total test statistic value.
%           df =      degrees of freedom.
%           pr =      right-tailed chi-square probability.
%           x2Cell =  test-statistic values for individual cells.
%

% Cressie, N & TRC Read. 1984. Multinomial goodness-of-fit tests.  
%   J Roy Stat Soc 46:440-464.
% Read, TRC. 1984. Small-sample comparisons for the power divergence goodness-of-fit 
%   statistics.  J Am Stat Assoc 79:929-935.

% RE Strauss, 7/1/99
%   10/24/08 - renamed from goodfit();
%              use G2 test explicitly for lambda=0;
%              miscellaneous improvements.

function [x2,df,pr,x2Cell] = GoodFitPowerDiverge(obs,exp,df,lambda)
  if (nargin < 3), df = []; end;
  if (nargin < 4), lambda = []; end;

  if (isempty(lambda)), lambda = 2/3; end;

  if (any(size(obs)~=size(exp)))
    error('GoodFitPowerDiverge: matrices of observed & expected counts not compatible');
  end;

  [nRows,nCols] = size(obs);                  
  if (isempty(df))                            % Determine df
    if (min([nRows,nCols])==1)                
      df = max([nRows,nCols])-1;
    else
      df = (nRows-1)*(nCols-1);
    end;
  end;
  
  if (any(exp<5))                             % Check for small expected cells
  	disp('GoodFitPowerDiverge warning: small expected cell counts in matrix');  
  end;

  if (lambda > eps)
    x2Cell = (2/(lambda*(lambda+1))) * obs.*(((obs./exp).^lambda)-1); % Power-divergence statistic
  else
    x2Cell = 2.*obs.*log(obs./exp);           % Likelihood-ratio statistic
  end;
  x2 = sum(sum(x2Cell));
  pr = 1-chi2cdf(x2,df);

  return;
