% CirclePlot: plots a 2D circle.
%
%     Usage: crds = CirclePlot({radius},{center},{nPts})
%
%     radius = optional radius of circle [default = 1].
%     center = optional 2-element vector of (h,k) coordinates of center
%                 [default = origin].
%     nPts =   optional number of plotted points [default = 100].
%     -----------------------------------------------------------------
%     crds =   [nPts x 2] matrix of plotted point coordinates.
%

% RE Strauss, 3/25/98
%   9/24/02 - modified and renamed from circdraw().
%   2/11/07 - allow for specificiation of center;
%             use hold on, hold off;
%             remove 'axis square'.
%   2/15/07 - provide point coordinates as output;
%             renamed from PlotCircle().

function crds = CirclePlot(radius,center,nPts)
  if (~nargin), help CirclePlot; return; end;
  
  if (nargin < 1), radius = []; end;
  if (nargin < 2), center = []; end;
  if (nargin < 3), nPts = []; end;
  
  if (isempty(radius)), radius = 1; end;
  if (isempty(center)), center = [0,0]; end;
  if (isempty(nPts)),   nPts = 100; end;

  theta = linspace(0,2*pi,nPts);
  
  x = radius .* cos(theta);
  y = radius .* sin(theta);
  
  hold on;
  plot(x+center(1),y+center(2),'k');
  hold off;
  
  crds = [x+center(1),y+center(2)];
  
  return;
  