% HullIsopleths: Given a set of 2D point coordinates, iteratively determines a sequence of
%         nested density contours by finding the smallest convex sets containing an alpha
%         proportion of them (Sager 1979).  Smallest convex sets are determined by deleting 
%         the hull point producing the smallest residual area.
%
%     Usage:  [ptIndex,alphaProp,area] = HullIsopleths(crds,{doPlots})
%
%         crds =      [nPts x 2] set of point coordinates.
%         doPlots =    optional boolean variable indicating that plots are to be produced 
%                       of diminishing hulls and of area as a function of proportion of
%                       points [default = false].
%         -----------------------------------------------------------------------------------
%         ptIndex =   vector of point indices, in order of removal from set.  The convex hull  
%                       of the set of points 1:nPts captures 100% of the area; the set 2:nPts  
%                       captures the next largest area; etc.
%         alphaProp = corresponding vector of proportions of points remaining.
%         area =      corresponding vector of areas captured by convex hulls.
%

% Sager, TW. 1979. An iterative method for estimating a multivariate mode and isopleth.
%   J.Am.Stat.Assoc. 74:329-339.
% Worton, B.J. 1995. A convex hull-based estimator of home-range size. Biometrics 51:1206-1215.

% RE Strauss, 2/18/08

function [ptIndex,alphaProp,area] = HullIsopleths(crds,doPlots)
  if (~nargin), help HullIsopleths; return; end;
  
  if (nargin<2), doPlots = []; end;
  
  if (isempty(doPlots)), doPlots = false; end;
  
  [nPts,nDims] = size(crds);
  
  if (nDims~=2)
    error('  HullIsopleths: 2D coordinates only.');
  end;
  if (nPts<2)
    error(' HullIsopleths: too few points.');
  end;
  
  ptIndex = zeros(nPts,1);
  area = zeros(nPts,1);
  alphaProp = linspace(1,1/nPts,nPts)';
  
  
  ptsLeft = 1:nPts;
  nPtsCur = 0;
  
  while (length(ptsLeft)>2)
    nPtsCur = nPtsCur+1;
    x = crds(ptsLeft,1);                        % Original crds for remaining points
    y = crds(ptsLeft,2);
    [hullPts,hullArea] = convhull(x,y);         % Convex hull of remaining points
    hullPts = hullPts(1:(end-1));               % Ignore last hull pt
    nHullPts = length(hullPts);
    hArea = zeros(nHullPts,1);                    % Prepare to jackknife area for hull points            
    for h = 1:nHullPts                            % For each point on hull
      xyh = [x,y];                                % Find area remaining when delete point
      xyh(hullPts(h),:) = [];
      hArea(h) = PolygonArea(xyh);
    end;
    [minArea,iMinArea] = min(hArea);
    area(nPtsCur) = hullArea;
    ptIndex(nPtsCur) = ptsLeft(hullPts(iMinArea));
    ptsLeft(hullPts(iMinArea)) = [];
  end;
  nPtsCur = nPtsCur+1;
  area(nPtsCur:(nPtsCur+1)) = 0;
  ptIndex(nPtsCur:(nPtsCur+1)) = ptsLeft';
  
  if (doPlots)
    figure;
    plotnum(crds);
    axis equal;
    hold on;
    for pt = 1:nPts-1
      h = hull(crds(ptIndex(pt:end),:));
      plot(h(:,1),h(:,2),'k');
    end;
    hold off;
    
    scatter(alphaProp,area);
    hold on;
    plot(alphaProp,area,'k');
    hold off;
    putxlab('Proportion of total points');
    putylab('Convex hull area');
    
    sqrtArea = sqrt(area);
    scatter(alphaProp,sqrtArea);
    hold on;
    plot(alphaProp,sqrtArea,'k');
    hold off;
    putxlab('Proportion of total points');
    putylab('Square root of convex hull area');
  end;
  
  return;
  
