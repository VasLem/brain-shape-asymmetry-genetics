x = 1:5;
i = 1;

while (i <= length(x))
  x(i) = x(i) + 1;
  i = i+1;
end;

x




x = 1:5;
i = 0;

while (i < length(x))
  i = i+1;
  x(i) = x(i)+1;
end;

x