% CombNext: Given a vector of R indices indicating a particular combination of N objects
%     sampled R at a time, generates the lexicographically next combination.  If the input 
%     vector is the scalar R, returns the first combination {1,2,...,R}.  If the input   
%     vector equals the final combination {N-R+1...,N-2,N-1,N}, returns an empty vector.
%
%     Usage: nextCombination = CombNext(N,{curCombination})
%
%         N = number of objects being sampled.
%         curCombination = vector (length R) containing the indices for the current 
%                           combination [default = return 1:R].
%         -------------------------------------------------------------------------
%         nextCombination = vector (length R) containing the next combination.
%

% RE Strauss, 6/3/07

function nextCombination = CombNext(N,curCombination)
  if (~nargin), help CombNext; return; end;
  
  if (nargin < 2), curCombination = []; end;
  
  if (isempty(curCombination)), curCombination = 1:R; end;

  return;
  
