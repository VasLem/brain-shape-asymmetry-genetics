% Values2Rows: Converts a vector of numeric values, previously created by function 
%           Row2Value(), back to a character matrix (by row).
%
%           See Rows2Values().
%
%     Usage: charMatrix = Value2Row(numValues,rowLength)
%
%           numValues = vector of numeric values.
%           rowLength = length of corresponding character labels.
%           --------------------------------------------------
%           charMatrix = corresponding character-string labels.
%

% RE Strauss, 6/10/98
%   1/24/07 - change variable names and rename function.

function charMatrix = Values2Rows(numValues,rowLength)
  numValues = exp(numValues);                     % Back-transform natural logarithms
  nRows = length(numValues);
  z = abs(' ')-1;                                 % Effective zero
  base = abs('z')-z+1;                            % Base for numeric conversion

  charMatrix = zeros(nRows,rowLength);            % Allocate output string matrix

  uniqueValues = unique(numValues);             	% Unique numeric values
  nUniqueValues = length(uniqueValues);
  asciiValues = zeros(1,rowLength);                 % Numeric ascii values for current unique row

  for row = 1:nUniqueValues                       % Cycle thru unique values
    uValue = uniqueValues(row);                     % Current numeric value
    for col = 1:rowLength-1                         % Expand to series of ascii values
      v = 0;
      while (uValue > base^(rowLength-col))
        uValue = uValue - base^(rowLength-col);
        v = v+1;
      end;
      asciiValues(col) = v + z;
    end;
    asciiValues(rowLength) = uValue + z;

    pos = find(numValues == uniqueValues(row));
    charMatrix(pos,:) = ones(length(pos),1)*asciiValues;
  end;

  charMatrix = char(charMatrix);

  return;

