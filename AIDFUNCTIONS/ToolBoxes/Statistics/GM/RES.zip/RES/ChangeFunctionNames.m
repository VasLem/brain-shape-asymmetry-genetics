% ChangeFunctionNames: Given the old and new names of one or more target Matlab functions, 
%   and corresponding old and new directories, changes the filename of the function (if
%   contained within the directory) and the function name within any other functions in the 
%   old directory.  Writes any altered references to files to the new directory.
%   All names are treated as case-sensitive.
%
%     Usage: ChangeFunctionNames(oldFuncnames,newFuncnames,oldDir,newDir)
%
%         oldFuncnames = [n x p] character matrix of old function names to be changed,
%                          including '.m' suffix.
%         newFuncnames = [n x q] character matrix of corresponding new function names,
%                          including '.m' suffix.
%         oldDir = character string containing name of directory with files to be converted.
%         newDir = character string containing name of new directory to contain converted
%                     files.  The directory is created if it does not exist.
%

% RE Strauss, 2/16/06

function ChangeFunctionNames(oldFuncnames,newFuncnames,oldDir,newDir)
  if (~nargin), help changeFunctionNames; return; end;
  
  if (~ischar(oldFuncnames) || ~ischar(newFuncnames) || ~ischar(oldDir) || ~ischar(newDir))
    error('  ChangeFunctionNames: input arguments must be character matrices.');    
  end;
    
  if (~isvector(oldDir) || ~isvector(newDir))
    error('  ChangeFunctionNames: directories must be character vectors.');
  end;
  
  [nRowsOld,nColsOld] = size(oldFuncnames);
  [nRowsNew,nColsNew] = size(newFuncnames);
  if (nRowsOld ~= nRowsNew)
    error('  ChangeFunctionNames: numbers of old and new function names must agree.');
  end;
  
  if (nColsOld < nColsNew)                               % Make function-name matrices to have equal numbers of columns
    nBlanks = nColsNew - nColsOld;
    oldFuncnames = [oldFuncnames, char(' '*ones(nRowsOld,nBlanks))];
  elseif (nColsOld > nColsNew)
    nBlanks = nColsOld - nColsNew;
    newFuncnames = [newFuncnames, char(' '*ones(nRowsNew,nBlanks))];
  end;
  
  oldFuncnames = lower(oldFuncnames);                     % Convert old function names to lower case
  
  if (oldDir(end) == '\')                                 % Remove any terminal backslashes from directory names
    oldDir = oldDir(1:end-1);
  end;
  if (newDir(end) == '\')                                 
    newDir = newDir(1:end-1);
  end;
  
  CheckNames(oldDir,newDir);                              % Check directory names
                                                          % Creat new directory if doesn't exist
  caseInsensitiveSort = true;
  inputFilenames = GetFilenames(oldDir,caseInsensitiveSort);  % Get list of m-files in old directory
  nInputFiles = size(inputFilenames,1);
  
  for iFile = 1:nInputFiles                               % Cycle thru m-files, revising and writing to new directory
    curOldFilename = deblank(inputFilenames(iFile,:));      % Get current filename, removing trailing blanks
    if (isequal(lower(curOldFilename(end-1:end)),'.m'))     % If file is a Matlab function,
      oldFuncText = GetCurFile(curOldFilename,oldDir);        % Get text of function in current file
      [newFuncText,newFilename] = ModifyCurFile(oldFuncText,curOldFilename,oldFuncnames,newFuncnames); % Revise function contents
      disp(sprintf('oldFilename = %s, newFilename = %s',curOldFilename,newFilename)); 
      PutModCurFile(newFuncText,newFilename,newDir);          % Revise and write m-file to new directory
    else                                                  
      filename = [oldDir,'\',curOldFilename];               % Otherwise copy non-function file to new directory
      flag = copyfile(filename,newDir);
      if (~flag)
        error('  ChangeFunctionNames: invalid file copy |%s|',filename);
      end;
    end;
  end;

  return;
  
% -----------------------------------------------------------------------------------------  
% CheckNames: Verify that the directory names are valid.  Create the new directory if 
%     it doesn't already exist.

function directoryStructure = CheckNames(oldDir,newDir)
  directoryStructure = dir(oldDir);
  mkdir(newDir);

  return;

% -----------------------------------------------------------------------------------------  
% GetCurFile: Given the directory and file names, read the contents of the function
%     into a character matrix.
%

function contents = GetCurFile(filename,directory)
  filename = [directory,'\',filename];
  contents = char(importdata(filename,'\n'));
  
  return;
  
% --------------------------------------------------------------------------------------------
% ModifyCurFile: replace function names in current file based on lists of old and new function 
%      names.  Recognition of old function names is case-insensitive, but replacement of new 
%      function names is case-sensitive.

function [newFuncText,newFilename] = ModifyCurFile(oldFuncText,curOldFilename,oldFuncnames,newFuncnames)
  nFuncLines = size(oldFuncText,1);                             % Number of lines in function text
  oldFuncnames = lower(oldFuncnames);
  nFuncnameCols = size(oldFuncnames,2);                     % Number of cols in old function-name matrix
  
  newFilename = curOldFilename;                             % Rename file if necessary
  nBlanks = nFuncnameCols-length(curOldFilename);
  [foundIt,loc] = ismember([lower(curOldFilename),blanks(nBlanks)],oldFuncnames,'rows');
  if (foundIt)
    newFilename = deblank(newFuncnames(loc,:));
  end;
  
  delimiters = [' %()[].^*\/+-=~<>;:,',char(9),char(13),char(39)];  % Token delimiters
  newFuncText = oldFuncText;
  
  for iLine = 1:nFuncLines                                  % Cycle thru lines of function text
    curLine = oldFuncText(iLine,:);                             % Isolate current line of text
    curLineNew = newFuncText(iLine,:);
    remainder = ' ';
    while (~isempty(remainder))
      [token,remainder] = strtok(curLine,delimiters);           % Find next token on line
      token = lower(token);                                     % Convert to lower-case for comparison
      lenToken = length(token);
      if (lenToken <= nFuncnameCols)                            % If token is not too long,
        nBlanks = nFuncnameCols-lenToken-2;                       % Pad with blanks if necessary
        [foundIt,loc] = ismember([token,'.m',blanks(nBlanks)],oldFuncnames,'rows'); % Determine whether token is an old function name
        if (foundIt)                                              % If so,
          i = strfind(lower(curLineNew),token);
          b = i-1;
          e = i+lenToken;
          lenNewToken = length(deblank(newFuncnames(loc,:)))-2;
          curLineNew = [curLineNew(1:b),deblank(newFuncnames(loc,1:lenNewToken)),curLineNew(e:end)];        
        end;
      end;
      curLine = remainder;
    end;
    curLine = oldFuncText(iLine,:);
    if (~strcmp(curLineNew,curLine))
      newFuncText = ReplaceLine(newFuncText,curLineNew,iLine);
    end;
  end;
    
	return;
  
% -----------------------------------------------------------------------------------------  
% ReplaceLine: replace row in character matrix, padding longer rows with blanks if necessary.

function charMatrix = ReplaceLine(charMatrix,newLine,row)
  [nRows,nCols] = size(charMatrix);
  lenLine = length(newLine);
  if (lenLine > nCols)
    nBlanks = lenLine-nCols;
    charMatrix = [charMatrix, char(' '*ones(nRows,nBlanks))];
  elseif (lenLine < nCols)
    nBlanks = nCols-lenLine;
    newLine = [newLine,blanks(nBlanks)];
  end;
  
  charMatrix(row,:) = newLine;

  return;

% -----------------------------------------------------------------------------------------  
% PutModCurFile: write modified function to output directory.

function PutModCurFile(newFuncText,filename,directory)
  filename = [directory,'\',filename];
  fid = fopen(filename,'w');
  if (fid < 0)
    error('  PutModCurFile (ChangeFunctionNames): invalid file name |%s|',filename);
  end;
  
  nLines = size(newFuncText,1);
  
  for i = 1:nLines
    fprintf(fid,'%s',newFuncText(i,:));
    fprintf(fid,'\n');
  end;
  
  fclose(fid);

  return;


  
