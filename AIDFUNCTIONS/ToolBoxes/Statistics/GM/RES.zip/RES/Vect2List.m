% Vect2List: Converts the numeric values within a vector to a comma-delimited string.
%
%     Syntax: s = Vect2List(v,{use_bl},{dp})
%
%         v =      row or column vector.  If a matrix is returned, columns are concatenated
%                    to form a column vector.
%         use_bl = optional boolean flag indicating that spaces are to be inserted
%                    after each comma [default = 0 = no spaces].
%         dp =     optional number of decimal positions for real values.
%         ---------------------------------------------------------------------------------
%         s =      resulting character string.
%

% RE Strauss, 7/28/05

function s = Vect2List(v,use_bl,dp)
  if (nargin < 2) use_bl = []; end;
  if (nargin < 3) dp = []; end;
  
  if (isempty(use_bl)) use_bl = 0; end;
  if (isempty(dp)) dp = 0; end;
  
  v = v(:)';          % Convert to row vector
  vlen = length(v);
  
  s = [];
  for i = 1:vlen
    f = max([floor(log10(v(i))+eps)+1,1]);  % Number of digits before decimal point
    editstr = ['%',int2str(f+dp),'.',int2str(dp),'f'];
    s = [s,sprintf(editstr,v(i))];
    if (i<vlen)
      s = [s,','];
      if (use_bl)
        s = [s,' '];
      end;
    end;
  end;
  
  return;
  