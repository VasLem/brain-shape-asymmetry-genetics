% PcaCovar: Returns the full set of sorted eigenvectors and eigenvalues, and a subset of PCA scores, 
%           from the covariance matrix of a data matrix.  Optionally bootstraps the loadings and 
%           eigenvalues.  If the covariance matrix is singular, finds the best subset of variables 
%           (based on matrix condition) providing full rank, performs PCA on the subset, and 
%           secondarily estimates loadings for the remainder of variables.
%
%     Syntax: [loadings,percVar,scores,fScores,ciLoadings,ciPercVar,eigenvectors,eigenvalues]
%              = PcaCovar(dataMatrix,{nPCs},{loadingsType},{dataFloated},{nIters},{ciLevel},{noWarnings})
%
%         dataMatrix =    [N x P] data matrix.
%         nPCs =          optional number of leading principal components to be returned [default = all].
%         loadingsType =  optional boolean flag indicating the scaling for the loadings: 
%                           0: vector correlations [default];
%                           1: regression coefficients;
%                           2: squared loadings sum to unity.
%         dataFloated =   optional [M x P] matrix of observations to be "floated" onto the principal components.
%         nIters =        optional number of bootstrap nItersations for confidence intervals [default=0].
%         ciLevel =       optional width of confidence intervals [default=95].
%         noWarnings =    optional boolean flag indicating, if true, that warning messages
%                           are to be suppressed [default=false].
%         ------------------------------------------------------------------------------------------------------
%         loadings =      [P x nPCs] matrix of principal components (columns).
%         percVar =       [P x 1] vector of percentages of variance accounted for by
%                           principal components.
%         scores =        [N x nPCs] matrix of unscaled PCA scores (columns).
%         fScores -       [M x nPCs] matrix of PCA scores for "floated" obs.
%         ciLoadings =    [P x 2*nPCs] matrix of CI% asymmetric confidence limits
%                           of loadings, two columns per component (low,high).
%         ciPercVar =     [P x 2] matrix of CI% asymmetric confidence limits
%                           of percents variance-explained.
%         eigenvectors =  [P x nPCs] matrix of eigenvectors;
%         eigenvalues=    [P x 1] vector of eigenvalues.
%

% RE Strauss, 11/21/95
%   9/14/99 -  misc changes for Matlab v5.
%   11/21/99 - updated documentation; 
%                added capability of floating obs on PCs;
%                implemented BOOTSTRP for bootstrapping.
%   1/15/00 -  allow for fewer observations than variables by estimating 
%                loadings as regression coefficients.
%   5/2/00 -   isolated scores & loadings in LOADSCRS.
%   6/12/00 -  added error message for missing data.
%   12/11/01 - added flag to supress warning messages.
%   5/4/06 -   standardized variable names.
%   5/18/06 -  major rewrite: remove all basic logic to PcaCovObj.
%   10/10/06 - renamed from 'PcaCov' to avoid Matlab toolbox conflict.

function [loadings,percVar,scores,fScores,ciLoadings,ciPercVar,eigenvectors,eigenvalues] ...
            = PcaCovar(dataMatrix,nPCs,loadingsType,dataFloated,nIters,ciLevel,noWarnings)
  if (~nargin), help PcaCovar; return; end;

  if (nargin < 2), nPCs = []; end;
  if (nargin < 3), loadingsType = []; end;
  if (nargin < 4), dataFloated = []; end;
  if (nargin < 5), nIters = []; end;
  if (nargin < 6), ciLevel = []; end;
  if (nargin < 7), noWarnings = []; end;

  if (isempty(loadingsType)), loadingsType = 0; end;
  if (isempty(nIters)),       nIters = 0; end;
  if (isempty(ciLevel)),      ciLevel = 95; end;
  if (isempty(noWarnings)),   noWarnings = 0; end;

  if (ciLevel > 1), ciLevel = ciLevel/100; end;
  alpha = 1-ciLevel;
  
  getScores = false;
  if (nargout > 2), getScores = true; end;

  if (misscheck(dataMatrix,dataFloated))
    error('  PcaCovar: input matrix contains missing values');
  end;

  [nObs,nVars] = size(dataMatrix);
  covMatrix = cov(dataMatrix);                            % Covariance matrix
  rankCovMatrix = rank(covMatrix);                        % Matrix rank
  
  isSingular = false;
  if (rankCovMatrix < nVars)
    isSingular = true; 
  end;

  if (nObs < 3)
    error('  PcaCovar: too few observations.');
  end;
  if (nVars < 1)
    error('  PcaCovar: too few variables.');
  end;
  if (isSingular && ~noWarnings)
    disp(sprintf('  PcaCovar warning: covariance matrix is singular; rank = %d',rankCovMatrix));
  end;
  
  if (~isempty(dataFloated))
    [nObsFloated,nVarsFloated] = size(dataFloated);
    if (nVarsFloated ~= nVars)
      error('  PcaCovar: data matrix to be floated must have same variables as data matrix.');
    end;
  end;

  varsUsed = 1:nVars;
  if (isSingular)                                       % Get subset of vars if matrix singular
    varsUsed = sort(StepRank(covMatrix));
  end;

  if (isempty(nPCs))
    nPCs = rankCovMatrix;
  end;
  nPCs = min([nPCs,rankCovMatrix]);
  
  % PCA

  [retstr,eigenvectors,eigenvalues] = PcaCovObj(dataMatrix,[],[],[],nPCs,loadingsType);
  
  nn = nVars*nPCs;                                        % Reshape into loadings and percVar matrices
%   loadings = reshape(retstr(1:nn),nVars,nPCs);
  percVar = retstr((nn+1):end)';

  if (getScores)
    [loadings,scores] = loadscrs(dataMatrix,eigenvectors,nPCs,loadingsType);

    if (~isempty(dataFloated))                          % Float additional obs onto PCs
      fScores = ScoreCalc(dataFloated,eigenvectors,nPCs);
    else
      fScores = [];
    end;
  else
    loadings = eigenvectors(:,1:nPCs);
  end;

  % Bootstrap PCA

  ciLoadings = [];
  ciPercVar = [];

  if (nIters)
    ci = bootstrp('pcacovb',1,nIters,alpha,dataMatrix,[],0,nPCs,loadingsType,loadings);

    nn = nVars*nPCs;                                        % Reshape into CI matrices
    ciLoadings = [reshape(ci(1,1:nn)',nVars,nPCs) ...
                   reshape(ci(2,1:nn)',nVars,nPCs)];
    c = [];
    for i = 1:nPCs
      c = [c i:nPCs:2*nPCs]; %#ok<AGROW>
    end;
    ciLoadings = ciLoadings(:,c);
    ciPercVar =  [reshape(ci(1,nn+1:nn+nPCs),nPCs,1) ...
                   reshape(ci(2,nn+1:nn+nPCs),nPCs,1)];
  end;

  return;

