% ContMapE: Least-squares mapping of continuous characters onto a completely
%           dichotomous tree, using the exact analytic solution of 
%           McArdle & Rodrigo (1994) for a completely bifurcated tree.
%           If branch lengths are provided for weights, the weights are 
%           specified as 1/(b^2).  The mapping thus corresponds to a Brownian-walk 
%           model if the squared length of each branch is equal to the expected 
%           increase in variance of the character along that branch.
%           Called by function ContMap(), but can be used stand-alone.
%
%     Usage: xNodes = ContMapE(ancFn,data,{isRooted},{branchLens})
%
%           ancFn =    ancestor function describing tree topology; the root must have 
%                        ancestor 0.
%           data =     [n x p] data matrix for n taxa and p characters.
%           isRooted = boolean flag indicating whether tree root is (=true) or
%                        is not (=false) to be optimized; if not, the tree is
%                        treated as an arbitrarily rooted network [default=true].
%           branchLens =   optional branch lengths for weighted least-squares mapping, 
%                        in same sequence as ancFn [default = 1 for all 
%                        branches except ancestor].
%           -------------------------------------------------------------------------
%           xNodes =   [m x p] data matrix containing predicted character values
%                        for m nodes and p characters.
%

% RE Strauss, 6/23/98
%   5/22/01 - major rewrite; incorporated weighting by 1/branchLens^2;
%               set negative branch lengths to zero.
%   5/23/01 - added call to ancmove().
%   2/11/09 - updated terminology and notation.

function xNodes = ContMapE(ancFn,data,isRooted,branchLens)
  if (nargin < 3), isRooted = []; end;
  if (nargin < 4), branchLens = []; end;

  defBrLen = 0;
  if (isempty(branchLens))
    branchLens = ones(size(ancFn));
    defBrLen = true;
  end;
  if (isempty(isRooted))
    isRooted = true;
  end;

  if (length(branchLens)~=length(ancFn))
    error('  ContMapE: branch-length and ancestor-fn vectors incompatible.');
  end;
  if (any(branchLens < 0))
    disp('  ContMapE warning: negative branch lengths set to zero');
    i = find(branchLens < 0);
    branchLens(i) = zeros(length(i),1);
  end;

  if (isvect(data))
    data = data(:);
  end;

  [nTaxa,nChars] = size(data);                  % Numbers of taxa and chars
  nNodes = nTaxa-1;                             % Number of nodes
  nAnc = length(ancFn);
  nVertices = nTaxa+nNodes;                     % Number of vertices (nodes + taxa)
  if (nAnc ~= nVertices)
    disp( '  ContMapE: Data matrix and ancestor function not compatible.');
    error('            Root must have ancestor 0.');
  end;

  if (~isRooted)                                % If tree not rooted, remove root
    root = find(ancFn==0);                        % Find arbitrary root node
    desc = find(ancFn==root);                     % Find its descendants
    d1 = desc(1);
    d2 = desc(2);
    ancFn(d1) = d2;                               % Form trichotomy
    if (~defBrLen)
      branchLens(d1) = branchLens(d1)+branchLens(d2);         % Sum the branch lengths
    end;
    indx = find(ancFn);
    ancFn = ancFn(indx);                          % Remove root node
    nAnc = length(ancFn);
    branchLens = branchLens(indx);
    nNodes = nNodes-1;
    nVertices = nVertices-1;
  end;

  [ancFn,branchLens] = ancmove(ancFn,branchLens);

  M = zeros(nVertices,nVertices);               % Allocate connectance matrix
  C = zeros(nNodes,nNodes);                     % Allocate coefficient matrix
  Y = zeros(nNodes,nChars);                     % Allocate solution matrix

  w = 1./(branchLens.^2);                       % Weights
  for i = 1:nAnc                                % Generate connectance matrix with recip branch lengths
    j = ancFn(i);
    if (j>0)
      M(i,j) = w(i);
      M(j,i) = w(i);
    end;
  end;
  Ma = M(nTaxa+1:nVertices,1:nVertices);      	% Connectance submatrix
  Mai = Ma(:,nTaxa+1:nVertices);                % Internal connectance submatrix
  Mt = Ma(:,1:nTaxa);

  [i,j] = find(Mai>0);
  for k = 1:length(i)
    C(i(k),j(k)) = -Mai(i(k),j(k));
  end;
  C = C + diag(rowsum(Ma));

  for i = 1:nNodes
    j = find(Mt(i,:)>0);
    if (~isempty(j))
      for k = 1:length(j)
        Y(i,:) = Y(i,:) + data(j(k),:);
      end;
    end;
  end;

  xNodes = C\Y;                                 % Estimate HTU character values

  return;

