% AppendRows: Concatenates the rows of a matrix B onto a matrix A, padding the shorter of the two matrices
%       (in terms of number of columns) with NaN's, blanks, or other value.  A and B must be of the same type 
%       (numeric or character), except that one or both may be null.
%
%     Usage: aConcat = AppendCoRows(A,B,{fillValue})
%
%         A,B =     input matrices. One or both may be null.
%         fillVal = optional value with which shorter matrix is to be filled [default = NaN for numeric matrices
%                     or blank for character matrices].
%         ------------------------------------------------------------------------------------------------------
%         aConcat = resultant concatenated matrix A.
%

% RE Strauss, 4/30/06

function aConcat = AppendRows(a,b,fillValue)
  if (nargin < 1) help AppendRows; return; end;
  
  if (nargin < 2) b = []; end;
  if (nargin < 3) fillValue = []; end;
  
  if (isempty(a))
    aConcat = b;
    return;
  elseif (isempty(b))
    aConcat = a;
    return
  end;
  
  matsAreChar = false;
  if (ischar(a))
    if (ischar(b))
      matsAreChar = true;
    else
      error('  AppendCols: input matrices must be of same type.');
    end;
  end;
  
  if (isempty(fillValue))
    if (matsAreChar)
      fillValue = ' ';
    else
      fillValue = NaN;
    end;
  else
    if ((ischar(fillValue) & ~matsAreChar) | (isnumeric(fillValue) & matsAreChar))
      error('  AppendCols: fill value must be of same type as input matrices');
    end;
  end;
  
  nACols = size(a,2);
  nBCols = size(b,2);
  nDiffCols = abs(nACols - nBCols);
  
  if (nACols < nBCols)
    if (matsAreChar)
      a = [a, char(fillValue*ones(size(a,1),nDiffCols))];
    else
      a = [a fillValue*ones(size(a,1),nDiffCols)];
    end;
  elseif (nACols > nBCols)
    if (matsAreChar)
      b = [b, char(fillValue*ones(size(b,1),nDiffCols))];
    else
      b = [b fillValue*ones(size(b,1),nDiffCols)];
    end;
  end;

  aConcat = [a;b];

  return;
  