% MissRandMeas: Assesses the distribution of number of missing values per row or 
%               column of a data matrix against an expected uniform marginal 
%               distribution.  Returns the relative difference between observed 
%               and expected values for rows, columns, and total (relative to their
%               maximum possible values when all missing values are concentrated
%               within a single row or column).  Because the total relative difference
%               assumes independence of rows and columns, a contingency MAD statistic
%               (comparable to a 2-way contingency chi-squared statistic) is also
%               returned.  All of these statistics, which are measures of nonuniformity, 
%               must be compared against null distributions determined by randomization 
%               to determine significance levels.  If the matrix contains fewer than 
%               2 missing values, NaN's are returned for all measures of nonuniformity.
%               
%   Usage:  [nonuni,stats] = MissRandMeas(x)
%
%       x =       [n x p] data matrix containing missing values.
%       -------------------------------------------------------------------------
%       nonuni =  [1 x 4] vector of mean-squared differences between observed and 
%                   expected marginal totals.
%                     1) relative difference for matrix;
%                     2) relative difference for rows;
%                     3) relative difference for columns;
%                     4) contingency MAD statistic;
%       stats =   [1 x 4] vector of associated statistics for randomization:
%                     1) number of rows;
%                     2) number of columns;
%                     3) total number of missing values (N);
%                     4) proportion of missing values in matrix.
%                   
%

% RE Strauss, 8/24/01
%   7/6/07 - appended MissRandMeasF.m to this file.

function [nonuni,stats] = MissRandMeas(X)
  
  X = ~isfinite(X);                         % Convert to binary matrix
  if (sum(sum(X))>1)                        % If any missing data,
    [nonuni,stats] = MissRandMeasF(X);      %   get stats
  else
    [r,c] = size(X);
    colobs = sum(X);                        % Marginal totals
%     rowobs = sum(X');
    N = sum(colobs);
    p = N/(r*c);
    stats = [r,c,N,p];                      % Missing-data counts
    nonuni = [NaN NaN NaN NaN];
  end;
  
  return;
  
% -----------------------------------------------------------------------------------

% MissRandMeasF:  Calculates measures of nonrandomness for missing data within a 
%                 data matrix.  Relative difference is the sum of absolute deviations
%                 of row or column totals from an expected uniform distribution,
%                 relative to the maximum possible when all missing values are
%                 concentrated within a single row or column.
%
%     Usage: [nonuni,stats] = MissRandMeasF(X)
%
%       X =       [n x p] data matrix containing missing values.
%       -----------------------------------------------------------------------
%       nonuni =  [1 x 4] vector of relative differences between observed and 
%                 expected marginal totals.
%                   1) relative difference for matrix;
%                   2) relative difference for rows;
%                   3) relative difference for columns;
%                   4) contingency MAD statistic;
%       stats =   [1 x 4] vector of associated statistics for randomization:
%                   1) number of rows;
%                   2) number of columns;
%                   3) total number of missing values (N);
%                   4) proportion of missing values in matrix;
%

% RE Strauss, 8/24/01
%   10/30/02 - allow for all missing values to be in same row or column.

function [nonuni,stats] = MissRandMeasF(x)
  [r,c] = size(x);

  colobs = -sort(-sum(x));                  % Marginal totals
  rowobs = -sort(-sum(x,2)');
  N = sum(colobs);

  p = N/(r*c);
  stats = [r,c,N,p];                        % Missing-data counts
  
  rowexp = (1/r)*ones(1,r);                 % Expected uniform row values
  rowexp = -sort(-prbcount(rowexp,N,[],1,1));
  rowdev = sum(abs(rowobs-rowexp));
  maxrowexp = [N zeros(1,r-1)];
  maxrowdev = sum(abs(rowobs-maxrowexp));
  if (maxrowdev==0)
    maxrowdev = 2*sum(maxrowexp);
  end;
  rowstat = rowdev/maxrowdev;
  
  colexp = (1/c)*ones(1,c);                 % Expected uniform col values
  colexp = -sort(-prbcount(colexp,N,[],1,1));
  coldev = sum(abs(colobs-colexp));
  maxcolexp = [N zeros(1,c-1)];
  maxcoldev = sum(abs(colobs-maxcolexp));
  if (maxcoldev==0)
    maxcoldev = 2*sum(maxcolexp);
  end;
  colstat = coldev/maxcoldev;
  
  totstat = (rowdev+coldev)/(maxrowdev+maxcoldev);
  
  cellexp = rowexp'*colexp/N;
  contstat = sum(sum(abs(x-cellexp)))/(r*c);
  
  nonuni = [rowstat colstat totstat contstat];
  
  return;
  
  
  
  
