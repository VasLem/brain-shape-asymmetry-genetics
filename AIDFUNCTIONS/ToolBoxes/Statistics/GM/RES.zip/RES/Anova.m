% Anova: Single-classification unbalanced fixed-effects analysis of variance.
%        Optionally randomizes the observations among groups to determine
%        the significance level of F (Manly, 1991, 64-90).  Deletes missing data.
%
%   Syntax: [F,pr,df,ss,ms,varComps,varProps] = Anova(x,grps,{nIters},{ciLevel})
%
%         x =         [n x 1] observations for a single variable.
%         grps =      [n x 1] classification variable.
%         nIters =    optional number of randomization nItersations [default = 0].
%         ciLevel =   optional percentage confidence level for bootstrapped variance
%                       components [default = 95].
%         ------------------------------------------------------------------------------
%         F =         observed F-statistic value.
%         pr =        significance level of the test, either asymptotic (if nIters=0)
%                       or randomized (if nIters>0).
%         df =        [3 x 1] vector of degrees of freedom (among-group,
%                       within-group, total).
%         ss =        [3 x 1] vector of sums-of-squares (among-group, within-group,
%                       total).
%         ms =        [2 x 1] vector of mean-squares (among-group, within-group).
%         varComps =  [2 x 1 vector of variance-component estimates (among-group,
%                       within-group), or [2 x 3] matrix if bootstrapped
%                       (row 1 = estimates, row 2 = lower confidence limits,
%                       (row 3 = upper confidence limits).
%         varProps =  [2 x 1] vector of variance components as proportions of
%                       total (among-group, within-group), or [2 x 3] matrix if
%                       bootstrapped (as with varComps).
%

% RE Strauss, 9/26/96
%   5/13/99 - miscellaneous improvements.
%   3/24/00 - check ranges of variance proportions.
%   8/1/01  - delete missing data.
%   1/23/08 - standardize variable names.

function [F,pr,df,ss,ms,varComps,varProps] = Anova(x,grps,nIters,ciLevel)
  if (nargin < 3), nIters = []; end;
  if (nargin < 4), ciLevel = []; end;

  getResultVectors = false;
  getVarComps = false;
  if (nargout > 2), getResultVectors = true; end;
  if (nargout > 5), getVarComps = true; end;

  if (isempty(nIters)),   nIters = 0; end;
  if (isempty(ciLevel)),  ciLevel = 0.95; end;

  if (ciLevel > 1)
    ciLevel = ciLevel/100;
  end;
  alpha = 1 - ciLevel;

  x = x(:);
  grps = grps(:);
  
  [nObs,p] = size(x);
  if (p>1)
    error('  ANOVA: Dependent variable must be a vector.');
  end;
  
  pos = find(isfinite(x));
  x = x(pos);
  grps = grps(pos);
  nObs = length(x);

  % Statistics independent of group composition

  G = Design(grps);                           % Design matrix
  nGrps = size(G,2);                          % Number of groups

  if (nGrps<2)
    error('  ANOVA: Must have more than one group.');
  end;

  grandMeanMatching = mean(x)*ones(nObs,1);   % Matching vector of grand means
  y = x - grandMeanMatching;                	% Deviations from grand mean
  sst = y'*y;                                 % Total sum-of-squares

  dft = nObs-1;                               % Total df
  dfa  = nGrps-1;                             % Among-group df
  dfe  = dft - dfa;                           % Within-group df

  % Statistics dependent on group composition

  gbar = inv(G'*G)*G'*x;                      % Group means
  xbar = G*gbar;                              % Matching vector of group means
  e = x - xbar;                               % Deviations from group means

  sse = e'*e;                                 % Within-group sum-of-squares
  ssa = sst - sse;                            % Among-group sum-of-squares

  msa = ssa / dfa;                            % Among-group mean-squares
  mse = sse / dfe;                            % Within-group mean-squares
  F = msa / mse;                              % Observed F-statistic

  % Estimates of variance components

  if (getVarComps)
    gn = diag(G'*G);                          % Group sample sizes
    n0 = (1/(nGrps-1)) * (sum(gn)-(gn'*gn/sum(gn)));
    s2e = mse;
    s2a = (msa-mse)/n0;
    s2t = s2a + s2e;
    varComps = [s2a; s2e];
    varProps = [s2a/s2t; s2e/s2t];
  end;

  % Output matrices

  if (getResultVectors)
    df = [dfa dfe dft]';
    ss = [ssa sse sst]';
    ms = [msa mse]';
  end;

  % Significance level of observed F-statistic

  if (nIters>0)                        % Randomized significance level
    [ci,pr] = bootstrp('anovaf',[0,1,0],nIters,alpha,x,grps,0,1,0);
  else                                % Asymptotic significance level
    pr = 1 - fcdf(F,dfa,dfe);
  end;

  % Bootstrap variance components

  if (getVarComps && nIters>0)
    ci = bootstrp('anovaf',[1,0,0],nIters,alpha,x,grps,0,0,1);

    vc = ci(:,1:2);                   % Extract confidence intervals for
    vp = ci(:,3:4);                   %   components and proportions

    vc(:,1) = (max([vc(:,1)'; eps eps]))';
    vp(:,1) = (max([vp(:,1)'; eps eps]))';
    vp(:,2) = (min([vp(:,2)'; 1-eps 1-eps]))';

    varComps = [varComps'; vc]';
    varProps = [varProps'; vp]';
  end;

  return;
