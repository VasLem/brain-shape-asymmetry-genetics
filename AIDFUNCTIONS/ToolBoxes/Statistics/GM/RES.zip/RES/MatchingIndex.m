% MatchingIndex: simple matching coefficient Smc, a pairwise measure of similarity between 
%     observations for binary variables (Sokal & Michener 1958):
%         Smc = (m11+m00)/(m11+m01+m10+m00) = (m11+m00)/n
%     where m = number of matches or mismatches, and n is the total number of observations.
%     0s and 1s are treated equivalently, so that joint presence and joint absence are 
%     given equal biological importance.  A corresponding measure of distance is Dmc = 1-Smc.
%
%     index = MatchingIndex(X,{useDistance})
%
%         X =     [n x p] binary data matrix for n observations and p variables.
%         ----------------------------------------------------------------------------
%         index = [n x n] similarity matrix.
%         useDistance = optional boolean flag indicating that the distance measure is 
%                 to be returned rather than the similarity measure [default = false].
%

% RE Strauss, 10/19/07

function index = MatchingIndex(X,useDistance)
  if (~nargin), help MatchingIndex; return; end;
  
  if (nargin < 2), useDistance = []; end;
  
  if (isempty(useDistance)), useDistance = false; end;

  nObs = size(X,1);
  index = ones(nObs,nObs);
  
  uVals = UniqueValues(X,1);
  if (length(uVals)~=2)
    error('  MatchingIndex: input matrix must be binary.');
  end;
  
  for i1 = 1:(nObs-1)
    v1 = X(i1,:);
    for i2 = (i1+1):nObs
      v2 = X(i2,:);
      a = sum(v1==uVals(2) & v1==v2);
      bc = sum(v1~=v2);
      d = sum(v1==uVals(1) & v1==v2);
      index(i1,i2) = (a+d)/(a+bc+d);
      index(i2,i1) = index(i1,i2);
    end;
  end;
  
  if (useDistance)
    index = 1-index;
  end;

  return;
  
