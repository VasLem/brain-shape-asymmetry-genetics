% Plotnum: Modification of plot() command to plot observation numbers 
%          rather than symbols.  If one input matrix is passed rather than
%          two vectors, the first two columns of the matrix are plotted.
%
%     Syntax:  Plotnum(x,y,{fontSize},{otherValues})
%                 OR
%              Plotnum([x,y],{fontSize},{otherValues})
%
%         x,y = matching vectors of point coordinates (length n).
%         fontSize = optional size of font for numeric values [default = 10].
%         otherValues = optional vector (length n) of numeric values to be
%                         plotted for observations [default = obs numbers].
%

% RE Strauss, 9/6/96
%   1/2/99 -  make second argument optional.
%   9/7/99 -  changed plot colors for Matlab v5.
%   3/21/00 - simplify plot and buffer logic.
%   10/3/00 - produce initial plot with white points so that plot can 
%               subsequentaly be rescaled with axis().
%   6/1/01 -  plot points as black dots on figure 1.
%   9/6/07 -  allow plotting of other numeric values;
%               standardize variable names and syntax.
%   9/2/08 -  change backgrounds of plots from gray to white.

function Plotnum(x,y,fontSize,otherValues)
  if (~nargin), help Plotnum; return; end;

  if (nargin < 2), y = []; end;
  if (nargin < 3), fontSize = []; end;
  if (nargin < 4), otherValues = []; end;

  if (isempty(y) || isscalar(y))
    otherValues = fontSize;
    fontSize = y;
    if (~isvect(x))
      y = x(:,2);
      x = x(:,1);
    else
      error('  Plotnum: invalid coordinate vectors');
    end;
  end;
  
  nPts = length(x);
  
  if (length(y)~=nPts)
    error('  Plotnum: coordinate vectors must be of same length');
  end;
  if (~isempty(otherValues))
    if (length(otherValues)~=nPts)
      error('  Plotnum: vector of other plotting values not same length as coordinates.');
    end;
  end;

  if (isempty(fontSize)), fontSize = 10; end;
  if (isempty(otherValues))
    plotValues = int2str((1:nPts)');
  else
    if (isnumeric(otherValues))
      plotValues = int2str(otherValues(:));
    else
      plotValues = otherValues;
    end;
  end;

  deltax = 0.011 * range(x);

  plot(x,y,'k.');
  hold on;
  for i = 1:nPts
    h = text(x(i)+deltax,y(i),plotValues(i,:));
    set(h,'fontSize',fontSize);
  end;
  hold off;
  putbnd([x,y],0.06);
  
  PutWhite;

  return;
