% LandmarkAsymmetryCrds:  Given a set of landmark coordinates in P dimensions for a single 
%     form, and corresponding info on whether they are bilateral or midsagittal, estimates 
%     the overall bilateral asymmetry of the form and the asymmetry for each bilateral 
%     landmark pair.
%
%     [asymOverall,asymByLandmark] = LandmarkAsymmetryCrds(crds,landmarkPairs,{replicates})
%
%         crds =          [N x P] matrix of N landmark coordinates for a single form in P dimensions.
%         landmarkPairs = [M x 2] matrix containing a list (by rows) of corresponding
%                           bilateral landmarks.  Any landmarks not in the list are considered
%                           to be midsaggital.
%         replicates =    optional grouping vector (length N) indicating the sets of landmarks 
%                           associated with replicate measurements of coordinates.
%         -------------------------------------------------------------------------------------------
%         asymOverall =   scalar measure of overall asymmetry
