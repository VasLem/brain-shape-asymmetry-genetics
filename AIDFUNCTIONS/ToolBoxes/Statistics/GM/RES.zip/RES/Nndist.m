% NNDist: Finds nearest-neighbor distance for each point.
%
%     Usage: [dists,nnPts] = NNDist(crds,{plotCdf},{getAllEqDists},{tol})
%
%         crds =          [n x p] matrix of point coordinates in P dimensions.
%         plotCdf =       optional boolean flag indicating, if true, that the cumulative
%                           distribution function of nearest-neighbor distances is to be
%                           plotted, either including identical distances (if getAllEqDists
%                           = true) or not (if getAlEqDists = false) [default = false].
%         getAllEqDists =	optional boolean flag indicating, if true, that all points 
%                           having identical nn distances to a given point are to be 
%                           returned; if false, only the first in the sequence 1:n 
%                           is returned [default = false].
%         tol =           optional tolerance for judging identical distances 
%                           [default = 1e-6 x min range of points].
%         ---------------------------------------------------------------------------------
%         dists =         [n x 1] vector of nearest-neighbor distances.
%         nnPts =         corresponding [n x 1] vector of indices of nearest neighbors, 
%                           or [n x m] matrix of indices where m is the maximum number 
%                           identical nn distances encountered for any point 
%                           (=1 if all distances are unique).
%

% RE Strauss, 6/6/00
%   9/27/00 - allow for identical nn distances per point.
%   4/14/08 - update variable names.

function [dists,nnPts] = NNDist(crds,plotCdf,getAllEqDists,tol)
  if (~nargin), help NNdist; return; end;

  if (nargin < 2), plotCdf = []; end;
  if (nargin < 3), getAllEqDists = []; end;
  if (nargin < 4), tol = []; end;

  if (isempty(plotCdf)), plotCdf = false; end;
  if (isempty(getAllEqDists)), getAllEqDists = false; end;
  if (isempty(tol) && getAllEqDists)
    tol = 1e-6 * min(range(crds));
  end;

  nObs = size(crds,1);

  dist = eucl(crds);                    % Matrix of pairwise distances
  maxDist = max(max(dist));
  dist = putdiag(dist,2*maxDist);       % Replace zeros on diagonal with highvals

  [dists,nnPts] = min(dist);                 % Find min interpoint distances
  dists = dists';                           % Transform to col vectors
  nnPts = nnPts';   

  if (getAllEqDists)
    for i = 1:nObs                           % Check for non-unique dists
      d = abs(dist(i,:) - dists(i));
      pos = find(d <= tol);
      lenPos = length(pos);
      if (lenPos > 1)
        di = dist(i,pos);
        dists(i) = mean(di);
        [nnPts,pos] = padcols(nnPts,pos);
        nnPts(i,:) = pos;
      end;      
    end;
  end;
  
  if (plotCdf)
    figure;
    DistCdf(dists);
  end;

  return;
