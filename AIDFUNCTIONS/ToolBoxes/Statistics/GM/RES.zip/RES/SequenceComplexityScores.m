% SequenceComplexityScores: Estimates sequence complexity scores for a set of sequences.  
%         Optionally estimates a null multinomial distribution of scores by randomly permuting  
%         the observed sequences, and a Markovian sampling distribution by generating random
%         Markov chains from the transition probabilities estimated from the observed sequences.
%
%     Usage: [scores,criticalVals] = ...
%                 SequenceComplexityScores(sequences,{maxSubwordLen},{nIters},{doPlots},{alpha})
%
%         sequences =     [nObs x lenSeqs] matrix of state sequences, with rows optionally 
%                           padded with NaNs.
%         maxSubwordLen = optional maximum subword length [default = length(sequence)-1].
%         nIters =        optional number of null and Markovian scores to be estimated by 
%                           random permutation [default = 1000].
%         doPlots =       optional boolean flag indicating that histograms of observed and null
%                           scores are to be produced, with common axes [default = false].
%         alpha =         optional alpha-level for critical values [default = 0.05].
%         -------------------------------------------------------------------------------------
%         scores =        structure containing observed and randomized scores:
%           scores.observed =    scores for observed sequences.
%           scores.multinomial = scores for randomized multinomial sequences (when nIters>0).
%           scores.markov =      scores for randomized Markovian sequences (when nIters>0).
%         criticalVals =  structure containing lower and upper 1-(alpha/2) critical values:
%           criticalVals.multinomial = vector of 2 critical values from the randomized 
%                                multinomial distribution (when nIters>0).
%           criticalVals.markov = vector of 2 critical values from the randomized Markovian
%                                distribution (when nIters>0).
%                           

% RE Strauss, 11/14/07

function [scores,criticalVals] = SequenceComplexityScores(sequences,maxSubwordLen,nIters,doPlots,alpha)
  if (~nargin), help SequenceComplexityScores; return; end;
  
  if (nargin < 3), nIters = []; end;
  if (nargin < 4), doPlots = []; end;
  if (nargin < 5), alpha = []; end;
  
  if (isempty(nIters)),  nIters = 1000; end;
  if (isempty(doPlots)), doPlots = false; end;
  if (isempty(alpha)),   alpha = 0.05; end;
  
  if (alpha<0.5), alpha = 100*alpha; end;           % Convert probability to percentile 
  
  sequences = SequenceToNum(sequences);             % Convert char matrix to numeric
  [nObs,lenSeqs] = size(sequences);

  [transitionProbs,stderrsProbs,freqs,states] = SequenceToTransition(sequences); % Transition matrix
  
  obsScores = zeros(nObs,1);
  for obs = 1:nObs                                  % Cycle thru observations
    seq = sequences(obs,:);                           % Isolate sequence
    seq = seq(isfinite(seq));                         % Remove NaNs
    obsScores(obs) = SequenceComplexity(seq,maxSubwordLen);           
  end;

  multinomScores = [];                              % Optional output arguments
  markovScores = [];
  multinomCrit = [];
  markovCrit = [];
  
  if (nIters)                                       % Find null and Markov distributions
    multinomScores =   zeros(nIters,1);
    markovScores = zeros(nIters,1);
    
    for iter = 1:nIters                               % Null distribution
      seq = sequences(ceil(nObs*rand),:);               % Pick random sequence
      seq = seq(isfinite(seq));                           % Remove NaNs
      lenSeq = length(seq);
      seq = seq(randperm(lenSeq));                        % Randomly permute sequence
      multinomScores(iter) = SequenceComplexity(seq,maxSubwordLen);
    end;
    multinomCrit = prctiles(multinomScores,[alpha/2,100-(alpha/2)]);
    
    markovSequences = RandMarkovSeqs(transitionProbs,nIters,lenSeqs,states);
    for iter = 1:nIters
      seq = markovSequences(iter,:);
      markovScores(iter) = SequenceComplexity(seq,maxSubwordLen);
    end;
    markovCrit = prctiles(markovScores,[alpha/2,100-(alpha/2)]);
  end;
  
  if (nIters && doPlots)
    [n,binMidpoints] = histbins([obsScores; multinomScores; markovScores]);
    
    figure;
    histgram(obsScores,[],[],binMidpoints);
    putxlab('Observed scores');

    if (nIters)
      axisBounds = axis;
      figure;
      histgram(multinomScores,[],[],binMidpoints);
      putxlab('Randomized multinomial scores');
      v = axis;
      v(1:2) = axisBounds(1:2);
      axis(v);
      
      figure;
      histgram(markovScores,[],[],binMidpoints);
      putxlab('Randomized Markovian scores');
      v = axis;
      v(1:2) = axisBounds(1:2);
      axis(v);
    end;
  end;
  
  scores.observed =          obsScores;                 % Output structures
  scores.multinomial =       multinomScores;
  scores.markov =            markovScores;
  criticalVals.multinomial = multinomCrit;
  criticalVals.markov =      markovCrit;
  
  return;
  
