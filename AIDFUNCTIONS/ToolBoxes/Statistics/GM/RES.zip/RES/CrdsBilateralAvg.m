% CrdsBilateralAvg: Given a 2D configuration of coordinates representing median and paired bilateral
%         landmarks, bilaterally flips the form and maps it onto itself by Procrustes superimposition,
%         and returns the consensus configuration of landmarks.
%
%     Usage: [consensus,asymMSE] = CrdsBilateralAvg(crds,medianLandmarks,pairedLandmarks,{specimens})
%
%         crds =            [nPts x nSpecs,2] matrix of landmark coordinates.
%         medianLandmarks = vector of indices of median landmarks.
%         pairedLandmraks = [nPairedPts,2] matrix of indices of corresponding landmarks.
%         specimens =       optional vector of specimen identifiers for multiple specimens 
%                             [default = single specimen].
%         ----------------------------------------------------------------------------------
%         consensus =       consensus landmark coordinates.
%         asymMSE =         [nSpecs x 1] vector of means of squared deviations (mse) between 
%                             corresponding landmarks, as a measure of total asymmetry.
%

% RE Strauss, 4/29/08

function [consensus,asymMSE] = CrdsBilateralAvg(crds,medianLandmarks,pairedLandmarks,specimens)
  if (~nargin), help CrdsBilateralAvg; return; end;
  
  if (nargin < 4), specimens = []; end;
  
  [nPts,p] = size(crds);
  if (p~=2)
    error('  CrdsBilateralAvg: coordinates must be 2D.');
  end;
  
  [nPairedPts,p] = size(pairedLandmarks);
  if (p~=2)
    error('  CrdsBilateralAvg: paired landmarks must be 2D.');
  end;
  
  medianLandmarks = medianLandmarks(:);
  nMedianPts = length(medianLandmarks);
  
  if (isempty(specimens)), specimens = ones(nPts,1); end;
  [uSpecs,fSpecs] = UniqueValues(specimens);
  nSpecs = length(uSpecs);
  
  if (nSpecs>1)
    if (sum(fSpecs-fSpecs(1))>0)
      error('  CrdsBilateralAvg: not all specimens have same number of coordinates.');
    end;
  end;
  nPts = nPts/nSpecs;
  
  if ((nMedianPts+2*nPairedPts)~=nPts)
    error('  CrdsBilateralAvg: numbers of specified landmarks not equal to number of point coordinates.');
  end;
  
  consensus = zeros(size(crds));              % Allocate output matrices
  asymMSE = zeros(nSpecs,1);
  
  e = 0;
  for iSpec = 1:nSpecs                        % Cycle thru specimens
    b = e+1;
    e = b+nPts-1;
    [consensus(b:e,:),asymMSE(iSpec)] = GetConsensus(crds(b:e,:),medianLandmarks,pairedLandmarks,nPts,nPairedPts);
  end;
  
  return;
  
% ----------------------------------------------------------------------------------------------------------  
  
function  [consensus,asymMSE] = GetConsensus(crds,medianLandmarks,pairedLandmarks,nPts,nPairedPts)
  
  pairedCentroids = zeros(nPairedPts,2);          % Find centroids of paired landmarks
  for ip = 1:nPairedPts
    i = pairedLandmarks(ip,1);
    j = pairedLandmarks(ip,2);
    pairedCentroids(ip,:) = mean([crds(i,:);crds(j,:)]);
  end;
  
  centerPts = [crds(medianLandmarks,:); pairedCentroids]; % Pts representing midsagittal axis
  dist = eucl(centerPts);
  maxDist = max(max(dist));                       % Find midsaggital pts furthest apart
  [r,c] = find(dist==maxDist);
  midsagittalLine = centerPts([c(1),r(1)],:);     % Use as ends of line segment
  rCrds = ReflectPts(crds,midsagittalLine);       % Reflect points about midsagittal line
  
  r = rCrds;
  for i = 1:nPairedPts                            % Exchange paired coordinates
    pt1 = pairedLandmarks(i,1);
    pt2 = pairedLandmarks(i,2);
    rCrds(pt1,:) = r(pt2,:);
    rCrds(pt2,:) = r(pt1,:);
  end;

  crdsCentroid = centroid(crds);
  noScale = true;
  [crds,rCrds] = lstra(crds,rCrds,[],noScale,[],true);    % Map reflected points onto original points
  
  crds =  crds +  ones(nPts,1)*crdsCentroid;      % Uncenter original and reflected points
  rCrds = rCrds + ones(nPts,1)*crdsCentroid;
  
  consensus = zeros(nPts,2);                      % Consensus is mean of original and reflected points
  asymMSE = 0;
  for i = 1:nPts
    consensus(i,:) = mean([crds(i,:);rCrds(i,:)]);
    asymMSE = asymMSE + eucl([crds(i,:);rCrds(i,:)])^2;
  end;
  asymMSE = asymMSE/nPts;
  
  return;
  
