% BinomPropTest: Tests an observed proportion (p) against a null proportion (pi) using the 
%     Score test (Garcia-Perez 2005; Krishnamoorthy & Peng 2007).  Provides a confidence
%     interval on the null proportion and a power curve.  Sampling variance is based on 
%     the null proportion, so 0>pi>1.
%
%     Usage: [testStats,ciInterval,power] = ...
%                                 BinomPropTest(pObs,nObs,{pNull},{tail},{alpha},{noPlots})
%
%         pObs -   observed proportion value.
%         nObs -   total number of observations.
%         pNull -  optional theoretical null value [default = 1/2].
%         tail -   optional value indicating the directionality of the test:
%                    -1 = left-tailed.
%                     0 = two-tailed [default].
%                    +1 = right-tailed.
%         alpha -  optional desired Type I probability level for test [default = 0.05].
%         noPlots - optional boolean flag indicating that plots are not to be produced
%                    [default = false].
%         ------------------------------------------------------------------------------------
%         testStats -  structure containing test results:
%                         z - test-statistic value.
%                         pr - resulting probability level under H0.
%         ciInterval - 2-element vectors containing lower and upper bounds of 1-alpha
%                       confidence intervals:
%                         null - CI about null value (Score CI).
%                         obs -  CI about observed value (Wald CI).
%         power -      structure containing power curve:
%                         testPower - post-hoc power for observed proportion.
%                         pPossible - vector of values: linspace(linspace((1e-3),1-(1e-3),500).
%                         powerFn - corresponding values of the power function.
%

% Garcia-Perez, MA. 2005. On the confidence interval for the binomial parameter.
%   Quality & Quantity 39:467-481.
% Krishnamoorthy, K. & J. Peng. 2007. Some properties of the exact and score methods for
%   binomial proportion and sample size calculation.  Commun. Statist. -- Simul. Comput.
%   36:1171-1186.

% RE Strauss, 6/25/08
%   11/21/08 - changed confidence intervals to be consistent with Eqns 2 & 4 of Garcia-Perez (2005).
%              correct critical proportion values for 1-tailed power estimates.

function [testStats,ciInterval,power] = BinomPropTest(pObs,nObs,pNull,tail,alpha,noPlots)
  if (~nargin), help BinomPropTest; return; end;
  
  if (nargin < 3), pNull = []; end;
  if (nargin < 4), tail = []; end;
  if (nargin < 5), alpha = []; end;
  if (nargin < 6), noPlots = []; end;
  
  if (isempty(pNull)),  pNull = 0.5; end;
  if (isempty(tail)),   tail = 0; end;
  if (isempty(alpha)),  alpha = 0.05; end;
  if (isempty(noPlots)), noPlots = false; end;
  
  if (pObs<0 || pObs>1 || pNull<=0 || pNull>=1)
    error('  BinomPropTest: observed or null proportion out of bounds.');
  end;
  
  if (tail < -eps)                                  % Change tail to character variable
    tail = 'L';
  elseif (tail > eps)
    tail = 'R';
  else
    tail = 'T';
  end;
  
  ciObs =  WaldCI(pObs,nObs,alpha);                 % Wald CI on observed value (Eqn 2, Garcia-Perez 2005)
  ciNull = ScoreCI(pNull,nObs,alpha);               % Score CI on null value (Eqn 4, Garcia-Perez 2005)
  
  [pr,z] = GetSignif(pObs,pNull,nObs,tail);         % Significance level of Score test
  testPower = GetPower(pObs,pNull,nObs,alpha,tail); % Power for observed proportion
  
  tol = 1e-3;
  pPossible = linspace(tol,1-tol,500);    
  powerFn = zeros(size(pPossible));                 % Power curve
  signifFn = zeros(size(pPossible));
  for ip = 1:length(pPossible)
    signifFn(ip) = GetSignif(pPossible(ip),pNull,nObs,tail);
    powerFn(ip) = GetPower(pPossible(ip),pNull,nObs,alpha,tail);
  end;
    
  if (~noPlots)                                     % Plot of power function and confidence interval
    deltaX = 0.015;
    deltaY = 0.02;
    displace = 0.05;
      
    figure;
    plot(pPossible,powerFn,'k',pObs,testPower,'ko',[pNull,pNull],[0,1],'k:');
    axis([0,1,-0.03,1.03]);
    if (tail == 'R');
      puttext(0.05,0.92,sprintf('N = %d',nObs));
      puttext(0.05,0.85,sprintf('pr = %4.3f',pr));
    elseif (tail == 'L');
      puttext(0.75,0.92,sprintf('N = %d',nObs));
      puttext(0.75,0.85,sprintf('pr = %4.3f',pr));
    else
      puttext(0.05,0.16,sprintf('N = %d',nObs));
      puttext(0.05,0.09,sprintf('pr = %4.3f',pr));
    end;
    hold on;
    plot(ciObs,[testPower,testPower],'k');
    plot([ciObs(1),ciObs(1)],[testPower-0.015,testPower+deltaX],'k');
    plot([ciObs(2),ciObs(2)],[testPower-0.015,testPower+deltaX],'k');
    if (pObs>0.5)
      text(ciObs(2)+deltaX,testPower-deltaY,'p_{obs}');
    else
      text(ciObs(2)-deltaX-0.165,testPower-deltaY,'p_{obs}');
    end;
    overlap = ((ciObs(1)>ciNull(1) && ciObs(1)<ciNull(2)) || ...
               (ciObs(2)>ciNull(1) && ciObs(2)<ciNull(2)));
    if (~overlap)
      plot(ciNull,[testPower,testPower],'k');
      plot([ciNull(1),ciNull(1)],[testPower-deltaX,testPower+deltaX],'k');
      plot([ciNull(2),ciNull(2)],[testPower-deltaX,testPower+deltaX],'k');
    else
      if (testPower>0.5)
        plot(ciNull,[testPower-displace,testPower-displace],'k');
        plot([ciNull(1),ciNull(1)],[testPower-deltaX-displace,testPower+deltaX-displace],'k');
        plot([ciNull(2),ciNull(2)],[testPower-deltaX-displace,testPower+deltaX-displace],'k');
      else
        plot(ciNull,[testPower+displace,testPower+displace],'k');
        plot([ciNull(1),ciNull(1)],[testPower-deltaX+displace,testPower+deltaX+displace],'k');
        plot([ciNull(2),ciNull(2)],[testPower-deltaX+displace,testPower+deltaX+displace],'k');
      end;
    end;
    putwhite;
    hold off;
    putxlab('Binomial proportion');
    putylab('Estimated power');
    putwhite;
    
    figure;
    plot(pPossible,signifFn,'k',pObs,pr,'ko',[0,1],[alpha,alpha],'k:');
    axis([0,1,-0.03,1.03]);
    if (tail == 'R')
      puttext(0.75,0.92,sprintf('N = %d',nObs));
      puttext(0.75,0.85,sprintf('pr = %4.3f',pr));
    else
      puttext(0.05,0.92,sprintf('N = %d',nObs));
      puttext(0.05,0.85,sprintf('pr = %4.3f',pr));
    end;
    putwhite;
    putxlab('Binomial proportion');
    putylab('Estimated significance level');
  end;

  testStats.z = z;                                  % Stash results in structures
  testStats.pr = pr;
  
  ciInterval.ciNull = ciNull;
  ciInterval.ciObs = ciObs;

  power.testPower = testPower;
  power.pPossible = pPossible;
  power.powerFn = powerFn;

  return;
  
% ----------------------------------------------------------------------------------------
% Wald CI on observed value (Eqn 2, Garcia-Perez 2005)

function ciObs = WaldCI(pObs,nObs,alpha)
  zq = normcdf(1-alpha/2);                  
  t1 = pObs;
  t2 = sqrt(pObs*(1-pObs)/nObs);
  lBound = t1-zq*t2;
  uBound = t1+zq*t2;
  ciObs = [lBound,uBound];
  
  return;
  
% ----------------------------------------------------------------------------------------
% Score CI on null value (Eqn 4, Garcia-Perez 2005)

function ciNull = ScoreCI(pNull,nObs,alpha)
  zq = normcdf(1-alpha/2);                  
  t1 = 2*nObs*pNull;                         
  t2 = zq*zq;
  t3 = zq*sqrt(2*t1*(1-pNull)+t2);
  t4 = 2*(nObs+t2);
  lBound = (t1+t2-t3)/t4;
  uBound = (t1+t2+t3)/t4;
  ciNull = [lBound,uBound];
  
  return;

% ----------------------------------------------------------------------------------------
% Statistical significance of Score test, with se evaluated at null p0.

function [pr,z] = GetSignif(pObs,pNull,nObs,tail)
  z = (pObs-pNull)/sqrt(pNull*(1-pNull)/nObs);
    
  switch (tail)
    case 'R',
      pr = 1-normcdf(z);                  % Right-tailed probability
    case 'L',
      pr = normcdf(z);                    % Left-tailed
    case 'T',
      pr = 1 + normcdf(-abs(z)) - normcdf(abs(z));  % Two-tailed
  end;
  
  return;
  
% ----------------------------------------------------------------------------------------
% Power of Score test

function power = GetPower(pObs,pNull,nObs,alpha,tail)
  nullMean = pNull;
  nullStderr = sqrt(pNull*pNull/nObs);
  
  altMean = pObs;
  altStderr = sqrt(pNull*(1-pNull)/nObs);
  
  switch (tail)
    case 'R',
      pc = norminv(1-alpha,nullMean,nullStderr);
      power = 1-normcdf(pc,altMean,altStderr);                % Right-tailed power
    case 'L',
      pc = norminv(alpha,nullMean,nullStderr);
      power = normcdf(pc,altMean,altStderr);                  % Left-tailed power
    case 'T',
      pc = norminv([alpha/2,1-alpha/2],nullMean,nullStderr);  % Two-tailed power
      power = 1 + normcdf(pc(1),altMean,altStderr) - normcdf(pc(2),altMean,altStderr);
  end;
  
  return;
  
  
