% LogLogResidAdj: Given the results from a bivariate linear regression of log-transformed
%         variables, estimates the bias-corrected residuals in the original scale.
%         See Smith (1993).
%
%   Usage:  [predAdj,residAdj,adjFactors] = LogLogResidCorrection(x,y,{b},{residsLog},{adjType})
%
%         x,y =       vectors (length N) of predictor and response variables, assumed to be 
%                       log-transformed (natural logarithms).
%         b =         optional vector of regression coefficients: [b0,b1].  If omitted, a 
%                       predictive regression of y on x is used to estimate the coefficients.
%         residsLog =	optional vector (length N) of ordinary or jackknifed residuals on the  
%                       log scale. [Default: residuals are 'ordinary', estimated from the 
%                       log-transformed data (using natural logarithms) and regression coefficients.]
%         adjType =   optional character string indicating type of adjustment to apply:
%                         'qmle' = quasi-maximum likelihood estimate.
%                         'mle' =  maximum likelihood estimate.
%                         'se' =   smearing estimate.
%                         're' =   ratio estimate.
%                         'mvue' = minimum-variance unbiased estimate.
%                         'rcp' =  Smith's "complete parametric correction factor".
%                         'med' =  median of estimates 1-5 [default].
%         ------------------------------------------------------------------------------------------
%         predAdj =     column vector of adjusted predicted values, in original scale.
%         residAdj =    column vector of adjusted residuals, in original scale.
%         adjFactors =  structure containing the estimated correction factors (see 'adjType', above).
%

% Smith, RJ. 1993. Logarithmic transformation bias in allometry.  
%   Am.J.Phys.Antropol. 90:215-228.

% RE Strauss, 7/2/07

function  [predAdj,residAdj,adjFactors] = LogLogResidAdj(x,y,b,residsLog,adjType)
  if (~nargin), help LogLogResidCorrection; return; end;
  
  if (nargin < 3), b = []; end;
  if (nargin < 4), resid = []; end;
  if (nargin < 5), adjType = []; end;
  
  getRegrCoeffs = false;                              % Default input arguments
  getResids = false; 
  if (isempty(b)),       getRegrCoeffs = true; end;
  if (isempty(resid)),   getResids = true; end;
  if (isempty(adjType)), adjType = 'med'; end;
  
  x = x(:);
  y = y(:);
  if (~getResids)
    residsLog = residsLog(:);
  end;
  
  nObs = length(x);
  if (length(y)~=nObs)
    error('  LogLogResidAdj: data vectors not compatible.');
  end;
  if (length(b)~=2)
    error('  LogLogResidAdj: invalid regression coefficients.');
  end;
  
  if (getRegrCoeffs)
    b = linregr(log(x),log(y));
  end;
  predLog = b(1)+b(2)*x;
  
  if (getResids)
    residsLog = y - (b(1)+b(2)*x);
  end;
  
  if (length(residsLog)~=nObs)
    error('  LogLogResidAdj: vector of residuals not compatible with data vectors.');
  end;
  
  residsOrig = exp(residsLog);
  meanLog = mean(residsLog);
  meanOrig = mean(residsOrig);
  s2 = var(residsLog);
  
  % Estimate correction factors

  qmle = exp(0.5*s2);
  mle = exp(0.5*s2*(nObs-3)/nObs);
  se = mean(residsOrig);
  re = mean(residsLog)/mean(residsOrig);
  
  g = 1 - (s2*(s2+2)/(4*nObs)) + ((s2*s2*(e*s2*s2+44*s2+84))/(96*nObs*nObs));
  mvue = exp(0.5*s2*g);
  
%   k = ((residsLog-log(residsOrig)).^2)/();

  return;
  

