% KsTest1SampleContin: Randomized 1-sample Kolmogorov-Smirnov test of the goodness of fit
%           of a data distribution to a continuous probability distribution.
%           The probability distribution is given as a set of x,y coordinates
%           tracing the pdf, specified as [x=(min:incr:max),f(x)], which is
%           integrated by cubic spline interpolation.  The range of
%           the abscissa of the test is given by the range of the data; thus
%           the pdf must include at least the sample range.
%           Calculates either the KS statistic (max difference between distributions) or 
%           an MSE (mean squared difference) goodness-of-fit statistic.
%
%     NOTE: Must randomize null distribution by drawing samples randomly from reference distribution.
%
%     Usage: [stathat,pr,power] = KsTest1SampleContin(X,tdist,{stat},{noPlots},{iter})
%
%         X =       [n x 1] vector of data scores, from which cumulative data
%                     distribution is created.
%         tdist =   [m x 2] matrix of pdf coordinates of probability distribution, from 
%                     which cumulative reference distribution is created.
%         stat  =   optional flag indicating the statistic to be calculated:
%                     0 = KS statistic [default];
%                     1 = MSE statistic.
%         noPlots = optional boolean flag indicating that plots of the observed and
%                     theoretical cumulative functions are to be suppressed
%                     [default = false].
%         iter  =   optional number of iterations; if iter=0 [default], then only the
%                   observed statistic value is returned.
%         ----------------------------------------------------------------------
%         stathat = observed statistic value.
%         pr =      estimated pricance level.
%

% RE Strauss, 9/25/96
%   9/15/98 - permit return of chi-square goodness-of-fit statistic.
%   8/20/99 - changed plot colors for Matlab v5.
%   12/12/06 - renamed from Kstest1c(); removed power estimation and bootstrap.

function [stathat,pr] = KsTest1SampleContin(X,tdist,stat,noPlots,iter)
  if (nargin < 3) stat = []; end;
  if (nargin < 4) noPlots = []; end;
  if (nargin < 5) iter = []; end;

  if (size(X,2)>1)                        % Convert row vectors to col vectors
    X = X';
  end;
  if (size(tdist,2)>2)
    tdist = tdist';
  end;

  [rt,ct] = size(tdist);
  if (ct~=2 | rt<2)
    error('  Invalid theoretical distribution');
  end;

  if (isempty(stat))                      % Default input-argument values
    stat = 0;
  end;
  if (isempty(noPlots))                  
    noPlots = 1;
  end;
  if (isempty(iter))
    iter = 0;
  end;

  if (stat < 0 | stat > 2)
    error('  KSTEST1C: invalid statistic flag');
  end;

  get_pr = 0;
  if (nargout>1 & iter>0)
    get_pr = 1;
  end;

  X = sort(X);                            % Sort data values and get range
  rnge = [X(1) X(length(X))];

  % Convert the reference pdf to cubic-spine piecewise polynomials (pp-form),
  % and from there to the pp-form of the integral (row vector).
  % Hanselman & Littlefield, "Mastering Matlab", pp. 142-148.

  pp = spline(tdist(:,1),tdist(:,2));

  stathat = ks1cf(X,0,pp,stat,rnge); % Get observed statistic value

  if (~noPlots)
    y = [0:1/(length(X)-1):1]';               % Cumulative increments

    Xt = linspace(rnge(1),rnge(2));
    t = spintgrl(pp,Xt);                      % Evaluate integral at data points
    t = t - t(1);                             % Anchor to 0 at left
    t = t / t(length(t));                     % Anchor to 1 at right

    leny = length(y);
    leny2 = 2*leny-1;
    Xy = zeros(leny2,1);
    Xx = Xy;

    Xx([1:2:leny2]) = X([1:leny]);            % Expand to staircase form
    Xx([2:2:(leny2-1)]) = X([2:leny]);
    Xy([1:2:leny2]) = y([1:leny]);
    Xy([2:2:(leny2-1)]) = y([1:(leny-1)]);

    figure;                                   % Plot cum functions
    plot(Xt,t,':k',Xx,Xy,'-k');
    putbnd([Xt Xx'],[t Xy']);
    legend('Null','Empirical');
    putxlab('X');
    putylab('Cumulative relative frequency');
  end;

  return;

  % ----------------------------------------------------------------------------------------  
  
% KS1CF: Objective function for KsTest1SampleContin.
%
%     Syntax: solution = ks1cf(X,nullflag,pp,stat,rnge)
%
%         X =         [n x 1] vector of data scores.
%         nu1,nu2 =   variables passed by BOOTSTRP but unused.
%         nullflag =  flag indicating that null distribution is being generated.
%         pp    =     row vector representing the piecewise-polynomial form of
%                       the integral of the continuous reference probability distribution.
%         stat =      flag indicating the statistic to be calculated:
%                       0 = MSE statistic
%                       1 = KS statistic
%         rnge =      2-element vector specifying min & max of original data.
%         ----------------------------------------------------------------------
%         solution =  test-statistic value.
%

% RE Strauss, 9/25/96

function solution = ks1cf(X,nu1,nu2,nullflag,pp,stat,rnge)
  MSE = 0; KS = 1; X2 = 2;              % Statistic indicators

  y = [0:1/(length(X)-1):1]';           % Cumulative increments

  if (~nullflag)                        % Compare bootstrapped sample & reference distrib
    X = sort(X);                          % X = sorted bootstrapped sample
    t = spintgrl(pp,[rnge(1);X;rnge(2)]); % Evaluate integral at data points
    t = t - t(1);                         % Anchor to 0 at left
    t = t / t(length(t));                 % Anchor to 1 at right
    t(1) = [];                            % Delete original min & max
    t(length(t)) = [];
  end;

  if (nullflag)                         % Compare data & random sample from reference distrib
    r = rand(length(X),1);                % Random sample of same size as data
    r = sort(r*(rnge(2)-rnge(1)) - rnge(1)); % Scale to same possible range as data

    t = spintgrl(pp,[rnge(1);r;rnge(2)]); % Evaluate integral at random points
    t = t - t(1);                         % Anchor to 0 at left
    t = t / t(length(t));                 % Anchor to 1 at right
    t(1) = [];                            % Delete original min & max
    t(length(t)) = [];
  end;

  diff = y - t;                         % Difference between distribs
  if (stat==KS)                           % Calc KS statistic
    solution = max(abs(diff));
  elseif (stat==MSE)                      % Calc MSE statistic
    solution = mean(diff.*diff);
  end;

  return;


  
