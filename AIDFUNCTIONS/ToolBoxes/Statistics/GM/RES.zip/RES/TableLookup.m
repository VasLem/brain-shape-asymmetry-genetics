% TableLookup: Given a table, in the form of a character or numeric matrix, and a table element in the form of a
%              character or numeric vector, returns the index or indices for the row(s) of the table equal to the
%              element.  Returns a zero (or other specified numeric value) if the element is not in the table.
%
%     Usage: index = TableLookup(table,element,{returnAll},{notFoundIndicator})
%
%         table =             [r x c] character or numeric matrix with r rows and c columns.
%         element =           [1 x c] vector to be compared against table rows.
%         returnAll =         optional boolean variable indicating, if true, that indices of all matching rows are 
%                               to be returned, rather than just the first [default = false].
%         notFoundIndicator = optional numeric value to be returned if the table element is not found in the table.
%         ---------------------------------------------------------------------------------------------------------
%         index =             scalar or column vector of row subscripts.
%

% RE Strauss, 5/5/06

function index = TableLookup(table,element,returnAll,notFoundIndicator)
  if (nargin < 1) help TableLookup; return; end;
  
  if (nargin < 3) returnAll = []; end;
  if (nargin < 4) notFoundIndicator = []; end;
  
  if (isempty(returnAll))         returnAll = false; end;
  if (isempty(notFoundIndicator)) notFoundIndicator = 0; end;
  
  [nRows,nCols] = size(table);
  elementLength = size(element,2);
  if (elementLength ~= nCols)
    error('  TableLookup: length of element must be equal to number of table columns.');
  end;
  
  index = [];
  for iRow = 1:nRows
    if (all(element==table(iRow,:)))
      index = [index, iRow];
      if (~returnAll)
        break;
      end;
    end;
  end;
  
  if (isempty(index))
    index = notFoundIndicator;
  end;

  return;