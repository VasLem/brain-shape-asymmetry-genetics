% BinomOverdispersionFit: Fits a beta-binomial distribution, a model of binomial overdispersion,
%         to a set of binomial counts, where each count represents a binomial experiment.
%         Returns the parameters p (probability of 'success') and theta (a measure of variation
%         in the binomial p among observations).
%           The test for overdispersion is based on 2 times the difference in log-likelihoods
%         for the binomial (constrained) and beta-binomial (unconstrained) models, which is
%         asymptotically distributed as chi-square with 1 df.
%           Standard errors by default are jackknifed estimates (Gladen 1979), or optionally
%         may be bootstrapped.
%
%     Usage: [obsStats,binomStats,betaBinomStats,testStats] = ...
%                                       BinomOverdispersionFit(counts,n,(nIters),{noPlots})
%
%         counts -  vector of binomial counts (number of successes [X] of N trials) or
%                     proportions (X/N).
%         n -       corresponding vector of number of trials per observation; if n is a scalar,
%                     it is used for all observations.
%         nIters -  optional number of bootstrap iterations for estimation of standard errors.
%         noPlots - optional boolean value indicating that plots of distributions are not to
%                     be produced [default = false].
%         -------------------------------------------------------------------------------------
%         obsStats -       structure containing statistics on observed data.
%         binomStats -     structure containing statistics for fit of binomial model.
%         betaBinomStats - structure containing statistics for fit of beta-binomial model.
%         testStats -      structure containing statistics for likelihood-ration test of 
%                            beta-binomial against binomial model.
%

% Skellam, JG. 1948. A probability distribution derived from the binomial distribution by
%   regarding the probability of success as a variable between the sets of trials.
%   Journal of the Royal Statistical Society B10:257-261.
% Kleinman, JC. 1973. Proportions with extraneous variance: single and independent samples.
%   JASA 68:46-54.
% Williams, DA. 1975. The analysis of binary responses from toxicological experiments
%   involving reproduction and teratogenicity.  Biometrics 31:949-952.
% Gladen, B. 1979. the use of the jackknife to estimate proportions from toxicological data
%   in the presence of litter effects. Journal of the American Statistical Association 74:278-283.
% Smith, DM. 1983. Maximum likelihood estimation of the parameters of the beta binomial
%   distribution. Algorithm AS 189.  Applied Statistics 32:196-204.
% Hughes, G and LV Madden. 1993. Using the beta-binomial distribution to describe aggregated
%   patterns of disease incidence.  Phytopathology 83:759-763.

% RE Strauss, 10/15/08

function [obsStats,binomStats,betaBinomStats,testStats] = BinomOverdispersionFit(counts,n,nIters,noPlots)
  if (~nargin), help BinomOverdispersionFit; return; end;
  
  if (nargin<3), nIters = []; end;
  if (nargin<4), noPlots = []; end;
  
  if (isempty(nIters)),  nIters = 0; end;
  if (isempty(noPlots)), noPlots = false; end;
  
  counts = counts(:);
  if (all(counts<=1))                             % Convert proportions to integer counts
    counts = round(counts.*n);
  end;
  
  nCounts = length(counts);
  if (nCounts<2)
    error('  BinomOverdispersionFit: >1 counts required.');
  end;
  nIsScalar = false;
  if (isScalar(n))                                  % Convert scalar n to vector
    n = n*ones(size(counts));
    nIsScalar = true;
  end;
  nMax = max(n);
  
  if (length(n)~=nCounts)
    error('  BinomOverdispersionFit: lengths of count and n vectors not equal.');
  end;
  
  [x,f] = UniqueValues(counts,true);         % Observed relative frequencies
  freqsObs = zeros(nMax+1,1);
  freqsObs(x+1) = f;
  probsObs = freqsObs/sum(freqsObs);
  
  pBinom = sum(counts)/sum(n);                      % Estimate binomial parameter
  probsBinom = binopdf((0:nMax)',nMax,pBinom);      % Binomial probability distribution
  logLBinom = BinomLogLikelihood(pBinom,counts,n);  % Binomial likeliood
  
  [params,logL,alpha,beta,pStd,bbFits] = BetaBinomEst(counts,n);   % Fit beta-binomial model
  mu = params(1);
  theta = params(2);
  logLBetaBinom = logL;
  
  if (bbFits)
    probsBetaBinom = BetaBinomProbs(mu,theta,nMax); 	% Beta-binomial pdf
  else
    disp('  BinomOverdispersionFit warning: beta-binomial distribution fit failed due to negative theta.');    
    probsBetaBinom = NaN*ones(1,nMax);
  end;
  
  if (bbFits && nIters>0)                            % Estimate bootstrapped standard errors
    distrib = zeros(nIters,4);
    nFit = 0;
    for it = 1:nIters
      obs = ceil(nCounts*rand(nCounts,1));
      countsBoot = counts(obs);
      nBoot = n(obs);
      pBoot = sum(countsBoot)/sum(nBoot);
      [paramsBoot,logLBoot,alphaBoot,betaBoot,pStdBoot,bbFitsBoot] = BetaBinomEst(countsBoot,nBoot);
      muBoot = paramsBoot(1);
      thetaBoot = paramsBoot(2);
      if (bbFitsBoot)
        nFit = nFit+1;
        distrib(nFit,:) = [pBoot,muBoot,thetaBoot,pStdBoot];
      end; 
    end;
    distrib = distrib(1:nFit,:);
    stdDistrib = std(distrib);
    pSE = stdDistrib(1);
    muSE = stdDistrib(2);
    thetaSE = stdDistrib(3);
    pStdSE = stdDistrib(4);
    
  else                                                % Else use jackknifed standard errors of p
    pSE = JackknifeP(pBinom,counts,n);
    muSE = JackknifeP(mu,counts,n);
    thetaSE = NaN;
    pStdSE = NaN;
  end;
  
  
  obsStats.mean = mean(counts);                   	% Stash results in structures
  obsStats.var = var(counts);
  obsStats.freqs = freqsObs;
  
  binomStats.p = pBinom;     
  binomStats.pSE = pSE;
  binomStats.N = nMax;
  binomStats.logL = logLBinom;
  binomStats.pdf = probsBinom;
  binomStats.mean = pBinom*nMax;
  binomStats.var = nMax*pBinom*(1-pBinom);
  binomStats.pred = probsBinom*nCounts;
  
  if (bbFits)
    betaBinomStats.p = mu;
    betaBinomStats.pSE = muSE;
    betaBinomStats.pStd = pStd;
    betaBinomStats.pStdSE = pStdSE;
    betaBinomStats.theta = theta;
    betaBinomStats.thetaSE = thetaSE;
    betaBinomStats.alpha = alpha;
    betaBinomStats.beta = beta;
    betaBinomStats.N = nMax;
    betaBinomStats.logL = logLBetaBinom;
    betaBinomStats.pdf = probsBetaBinom;
    betaBinomStats.mean = nMax*mu;
    betaBinomStats.var = nMax*mu*(1-mu)+theta*mu*(1-mu)*nMax*(nMax-1);
    betaBinomStats.pred = probsBetaBinom*nCounts;
  
    testStats.logLBetaBinom = logLBetaBinom;
    testStats.logLBinom = logLBinom;
    testStats.X2 = 2*(logLBetaBinom - logLBinom);
    testStats.df = 1;
    testStats.pValue = 1-chi2cdf(testStats.X2,1);
  else
    betaBinomStats.p = NaN;
    betaBinomStats.pSE = NaN;
    betaBinomStats.pStd = NaN;
    betaBinomStats.pStdSE = NaN;
    betaBinomStats.theta = NaN;
    betaBinomStats.thetaSE = NaN;
    betaBinomStats.alpha = NaN;
    betaBinomStats.beta = NaN;
    betaBinomStats.N = NaN;
    betaBinomStats.logL = NaN;
    betaBinomStats.pdf = NaN;
    betaBinomStats.mean = NaN;
    betaBinomStats.var = NaN;
    betaBinomStats.pred = NaN;
  
    testStats.logLBetaBinom = NaN;
    testStats.logLBinom = NaN;
    testStats.X2 = NaN;
    testStats.df = NaN;
    testStats.pValue = NaN;
  end;

  if (~noPlots)                                           % Distribution plots
    if (bbFits)
      probMax = max([probsObs; probsBetaBinom; probsBinom]);
    else
      probMax = max([probsObs; probsBinom]);
    end;
    v = [-1,nMax+1,0,1.05*probMax];
    width = 0.9;
    maxTick = 20;
    if (nMax <= maxTick)
      tickEvery = (0:nMax);
    else
      d = ceil(nMax/maxTick);
      tickEvery = (0:d:nMax);
      if (tickEvery(end)~=nMax)
        if ((nMax-tickEvery(end))>d/2)
          tickEvery(end+1) = nMax;
        else
          tickEvery(end) = nMax;
        end;
      end;
    end;
    
    if (nIsScalar)                                        % Constant N across observations
      figure;
      bar((0:nMax)',probsObs,width,'k');
      axis(v);
      puttick(tickEvery);
      putxlab('X of N');
      putylab('Frequency');
    else                                                  % Varying N across observations
      scatter(n,counts);
      hold on;
      minAxis = min(min(n),min(counts))-1;
      maxAxis = max(max(n),max(counts))+1;
      plot([minAxis,maxAxis],[minAxis,maxAxis],'k');
      hold off;
      putxlab('N');
      putylab('X');
    end;
    puttitle('Observed relative frequencies');
  
    figure;
    bar((0:nMax)',probsBinom,width,'k');
    axis(v);
    puttick(tickEvery);
    putxlab('X of N');
    putylab('Frequency');
    puttitle('Binomial probabilities');
    
    if (bbFits)
      figure;
      bar((0:nMax)',probsBetaBinom,width,'k');    
      axis(v);
      puttick(tickEvery);
      putxlab('X of N');
      putylab('Frequency');
      puttitle('Beta-binomial probabilities');
    
      figure;
      b = linspace(0,1,200);
      bDensity = (gamma(alpha+beta)/(gamma(alpha)*gamma(beta))).*(b.^alpha).*(1-b).^beta;
      plot(b,bDensity,'k');
      putxlab('Binomial p');
      putylab('Frequency');
      puttitle('Beta distribution of binomial p');
    end;
  end;
  
  return;
  
% ----------------------------------------------------------------------------------------  
% Estimate beta-binomial parameters by maximum-likelihood.

function [params,logL,alpha,beta,pStd,bbFits] = BetaBinomEst(counts,n)
  p = sum(counts)/sum(n);
  params = [p,0.1];                           	% Initial estimates
  [params,logL] = fminsearch(@BetaBinomLogLikelihood,params,[],counts,n);  % Estimate mu,theta
  mu = params(1);
  theta = params(2);
  
  bbFits = false;
  if (theta>eps && theta<1 && mu>=0 && mu<=1)
    bbFits = true;
  end;

  if (bbFits)
    alpha = mu/theta;                           % Reexpress beta-binomial parameters
    beta = (1-mu)/theta;
    pVar = mu*(1-mu)/(alpha+beta+1);            % Expected variance in p for beta binomial
    pStd = sqrt(pVar);
    logL = -logL;
  else
    params = [NaN,NaN];
    alpha = NaN;
    beta = NaN;
    pStd = NaN;
    logL = NaN;
  end;

  return;
  
% ----------------------------------------------------------------------------------------  
% Calculation of log-likelihood for the data, given p.

function logL = BinomLogLikelihood(p,x,n)
  nObs = length(x);
  
  logL = 0;
  for j = 1:nObs
    logL = logL + x(j)*log(p) + (n(j)-x(j))*log(1-p);
  end;

  return;
  
% ----------------------------------------------------------------------------------------  
% Jackknifed estimate of standard error of p (Gladen 1979).

function se = JackknifeP(pHat,x,n)
  M = length(x);
  N = sum(n);
  yi = (x-n*pHat)./(N-n);
  yMean = sum(yi)/M;
  sigma2Hat = sum((yi-yMean).^2)*(M-1)/M;
  se = sqrt(sigma2Hat);
  
  return;
  
