% FourierEllipt: Given a set of 2D point coordinates describing an outline, returns a set 
%         of 4 elliptical Fourier coefficients for each harmonic, from 0-(nHarmonics-1).
%         The 0th harmonic (first column of 'coeffs') is an offset, and can be ignored for
%         further analysis.  Coefficients by default are normalized to be invariant to 
%         rotation, and starting position of the boundary.  Coefficients can also be 
%         normalized with respect to size (length of semimajor axis of first ellipse).
%
%     Usage: [coeffs,ellipseSize,power] = FourierEllipt(crds,nHarm,{normSize},{noNorm})
%
%         crds -        [nPts x 2] matrix of point coordinates describing a closed outline.
%         nHarm -       number of harmonics to return.
%         normSize -    optional boolean value indicating that coefficients are to be
%                         normalized by size [default = false].
%         noNorm -      optional boolean value indicating that coefficients are not to be 
%                         normalized in any way [default = false].
%         ---------------------------------------------------------------------------------
%         coeffs -      [4 x nHarm] matrix of elliptical Fourier coefficients.
%         ellipseSize - length of semimajor axis of first ellipse.
%         power -       [1 x nHarm] vector of harmonic powers.
%

% RE Strauss, 5/16/08
%   5/19/08 - changed normalization options.
%   6/10/08 - added harmonic power.

% Kuhl, FP and CR Giardina. 1982. Elliptic Fourier features of a closed contour.
%     Computer Graphics and Image Processing 18:236-258.
% Based on David Thomas' function fEfourier.m (Matlab Central).

function [coeffs,ellipseSize,power] = FourierEllipt(crds,nHarm,normSize,noNorm)
  if (~nargin), help FourierEllipt; return; end;
  
  if (nargin<3), normSize = []; end;
  if (nargin<4), noNorm = []; end;
  
  getSize = false;
  if (nargout>1), getSize = true; end;
  
  if (isempty(normSize)), normSize = false; end;
  if (isempty(noNorm)),   noNorm = false; end;

  nPi2 = 2*pi*(1:1:nHarm);                            % Predefine vectors
  nPi2Sq = 2*pi*pi*(1:1:nHarm).*(1:1:nHarm);
	
  nPts =   size(crds,1)-1; 
  
  xDelta = zeros(nPts+1,1);                           % Allocate matrices
  yDelta = zeros(nPts+1,1);
  tDelta = zeros(nPts+1,1);
  coeffs = zeros(4,nHarm);

  for ic = 2:(nPts+1)                                 % Calc point displacements
    xDelta(ic-1) = crds(ic,1) - crds(ic-1,1);
   	yDelta(ic-1) = crds(ic,2) - crds(ic-1,2);
  end;
  for ic = 1:nPts
    tDelta(ic) = sqrt((xDelta(ic)^2) + (yDelta(ic)^2));
  end;
  
  pos = (abs(tDelta)>eps);                            % Remove zeros
  tDelta = tDelta(pos);
  xDelta = xDelta(pos);
  yDelta = yDelta(pos);
  nPts = size(tDelta,1)-1;
  
  time = [0; cumsum(tDelta(1:end-1))]';               % 'Time' at each point
  period = time(nPts+1); 

  sum1 = 0;                                           % Estimate A0 coefficient: x mean
  for ip = 2:(nPts+1)
    sum2 = 0;
    sum3 = 0;
    innerDiff = 0;
    if (ip > 1)                                         % Partial sums
      for ij = 2:(ip-1)
        sum2 = sum2 + xDelta(ij-1);
    		sum3 = sum3 + tDelta(ij-1);
      end;
      innerDiff = sum2-((xDelta(ip-1)/tDelta(ip-1))*sum3);
    end;
   	incr1 = ((xDelta(ip-1)/(2*tDelta(ip-1)))*(time(ip)^2-time(ip-1)^2)+innerDiff*(time(ip)-time(ip-1)));
    sum1 = sum1 + incr1;
  end;
  coeffs(1,1) = (sum1/period)+crds(1,1);

  for ih = 2:nHarm                                    % Estimate Ai coefficients
    sum1 = 0;
    for ip = 1:nPts
      incr1 = (xDelta(ip)/tDelta(ip))*((cos(nPi2(ih-1)*time(ip+1)/period)-cos(nPi2(ih-1)*time(ip)/period)));
      sum1 = sum1 + incr1;
    end;
  	coeffs(1,ih) = (period/nPi2Sq(ih-1))*sum1;
  end;
   
  coeffs(2,1) = 0;                                    % No B0 coefficient
   
  for ih = 2:nHarm                                    % Estimate Bi coefficients
    sum1 = 0;
    for ip = 1:nPts
      incr1 = (xDelta(ip)/tDelta(ip))*((sin(nPi2(ih-1)*time(ip+1)/period)-sin(nPi2(ih-1)*time(ip)/period)));
      sum1 = sum1 + incr1;
    end;
    coeffs(2,ih) = (period / nPi2Sq(ih-1)) * sum1;
  end;
   
  sum1 = 0;                                           % Estimate C0 coefficient: y mean
  for ip = 2:(nPts+1)
    sum2 = 0;
    sum3 = 0;
    innerDiff = 0;
    if (ip > 1)                                         % Partial sums
      for ij = 2:(ip-1)
        sum2 = sum2 + yDelta(ij-1);
        sum3 = sum3 + tDelta(ij-1);
      end;
      innerDiff = sum2 - ((yDelta(ip-1)/tDelta(ip-1))*sum3);
    end;
    incr1 = ((yDelta(ip-1)/(2*tDelta(ip-1)))*(time(ip)^2-time(ip-1)^2)+innerDiff*(time(ip)-time(ip-1)));
    sum1 = sum1 + incr1;
  end ; 
  coeffs(3,1) = (sum1/period) + crds(1,2); 
   
  for ih = 2:nHarm                                    % Estimate Ci coefficients
    sum1 = 0;
    for ip = 1:nPts
      incr1 = (yDelta(ip)/tDelta(ip))*((cos(nPi2(ih-1)*time(ip+1)/period)-cos(nPi2(ih-1)*time(ip)/period)));
      sum1 = sum1 + incr1;
    end;
    coeffs(3,ih) = (period/nPi2Sq(ih-1))*sum1;
  end;
   
  coeffs(4,1) = 0;                                    % No D0 coefficient
   
  for ih = 2:nHarm                                    % Estimate Di coefficients
    sum1 = 0;
    for ip = 1:nPts
      incr1 = (yDelta(ip) / tDelta(ip))*((sin(nPi2(ih-1)*time(ip+1)/period) - sin(nPi2(ih-1)*time(ip)/period)));
      sum1 = sum1 + incr1;
    end;
    coeffs(4,ih) = (period/nPi2Sq(ih-1))*sum1;
  end;
   
  if (getSize || ~noNorm)                             % Normalize coefficients
    theta1 = 0.5*atan(2*(coeffs(1,2)*coeffs(2,2) + coeffs(3,2)*coeffs(4,2))/ ...
      (coeffs(1,2)^2 + coeffs(3,2)^2 - coeffs(2,2)^2 - coeffs(4,2)^2));
    theta2 = 0.5*(pi+atan(2*(coeffs(1,2)*coeffs(2,2) + coeffs(3,2)*coeffs(4,2))/ ...
      (coeffs(1,2)^2 + coeffs(3,2)^2 - coeffs(2,2)^2 - coeffs(4,2)^2)));
    x11 = coeffs(1,2)*cos(theta1) + coeffs(2,2)*sin(theta1);
    y11 = coeffs(3,2)*cos(theta1) + coeffs(4,2)*sin(theta1);
    axisLen1 = x11^2 + y11^2;
    x22 = coeffs(1,2)*cos(theta2) + coeffs(2,2)*sin(theta2);
    y22 = coeffs(3,2)*cos(theta2) + coeffs(4,2)*sin(theta2);
    axisLen2 = x22^2 + y22^2;
    if (axisLen2 > axisLen1)                            % Angle of rotation to align with major axis
      theta1 = theta2;                                  %   of first harmonic ellipse
    end;
    
    normCoeffs = zeros(4,nHarm);
    for ih = 1:nHarm                                    % Coeffs normalized for starting pt
      normCoeffs(1,ih) =  cos((ih-1)*theta1)*coeffs(1,ih) + sin((ih-1)*theta1)*coeffs(2,ih);
      normCoeffs(2,ih) = -sin((ih-1)*theta1)*coeffs(1,ih) + cos((ih-1)*theta1)*coeffs(2,ih);
	    normCoeffs(3,ih) =  cos((ih-1)*theta1)*coeffs(3,ih) + sin((ih-1)*theta1)*coeffs(4,ih);
 	    normCoeffs(4,ih) = -sin((ih-1)*theta1)*coeffs(3,ih) + cos((ih-1)*theta1)*coeffs(4,ih);
    end;

    semiMajorAxis = sqrt(normCoeffs(1,2)^2+normCoeffs(3,2)^2); 
    ellipseSize = semiMajorAxis;                               % Length of semimajor axis of first ellipse
    if (~normSize)                                       
      semiMajorAxis = 1;
    end;

    if (~noNorm)
      if (abs(normCoeffs(3,2))>eps)
        if (normCoeffs(1,2)>=0)
          psi = atan(normCoeffs(3,2)/normCoeffs(1,2));
        else
          psi = atan(normCoeffs(3,2)/normCoeffs(1,2))+pi;
        end;
      else
        if (normCoeffs(1,2)>eps)
          psi = atan(normCoeffs(3,2)/normCoeffs(1,2));
        else
          psi = atan(normCoeffs(3,2)/normCoeffs(1,2))+pi;
        end;
      end;
      psi = psi+pi;    
      
      for ih = 1:nHarm                                    % Normalize orientation
        coeffs(1,ih) =  (cos(psi)*normCoeffs(1,ih) + sin(psi)*normCoeffs(3,ih))/semiMajorAxis;
        coeffs(2,ih) =  (cos(psi)*normCoeffs(2,ih) + sin(psi)*normCoeffs(4,ih))/semiMajorAxis;
  	    coeffs(3,ih) = (-sin(psi)*normCoeffs(1,ih) + cos(psi)*normCoeffs(3,ih))/semiMajorAxis;
        coeffs(4,ih) = (-sin(psi)*normCoeffs(2,ih) + cos(psi)*normCoeffs(4,ih))/semiMajorAxis;
      end;
    end;
  end;  % End normalization step
  
  power = 0.5*sum(coeffs.^2);                             % Harmonic amplitude
  
  return;
  
