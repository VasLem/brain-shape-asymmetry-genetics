% EthogramPlot:  Given a matrix of Markov transition probabilities among N behavioral states, and 
%         an optional vector of state magnitudes, plots an ethogram in which circles indicating 
%         states are sized in proportion to state magnitudes and arrows connecting circles are
%         drawn with thicknesses proportional to transition probabilities.  States are sequenced
%         clockwise from left.  Practical for up to about 7 behavioral states.
%
%     Usage:  EthogramPlot(transitionProbs,{magnitudes},{stateLabels},{thresholdProb},...
%                           {stateFontSize},{probFontSize})
%
%         transitionProbs = [nStates x nStates] matrix of transition probabilities, with 
%                             rows summing to unity.
%         magnitudes =      optional vector (length N) of state magnitudes
%                             [default = all unity].
%         stateLabels =     optional numeric or character matrix of state labels (rows)
%                             [default = numeric labels].
%         thresholdProb =   optional minimum probability level necessary for plotting arrow 
%                             [default = 0.01].
%         stateFontSize =   optional font size used for printing state labels [default = 12].
%         probFontSize =    optional font size used for printing transition probabilities [default = 10].
%

% RE Strauss, 2/11/07
%   11/11/07 - allow for numeric state labels.
%   12/1/07 -  added self-probabilities.
%    2/19/09 - changed plot background to white.

function EthogramPlot(transitionProbs,magnitudes,stateLabels,thresholdProb,stateFontSize,probFontSize)
  if (~nargin), help EthogramPlot; return; end;
  
  if (nargin < 2), magnitudes = []; end;
  if (nargin < 3), stateLabels = []; end;
  if (nargin < 4), thresholdProb = []; end;
  if (nargin < 5), stateFontSize = []; end;
  if (nargin < 6), probFontSize = []; end;
  
  sizeT = size(transitionProbs);
  if (sizeT(1)~=sizeT(2))
    error('  EthogramPlot: invalid transition-probability matrix.');
  end;
  nStates = sizeT(1);
  
  if (isempty(magnitudes)),    magnitudes = ones(1,nStates); end;
  if (isempty(thresholdProb)), thresholdProb = 0.01; end;
  if (isempty(stateFontSize)), stateFontSize = 10; end;
  if (isempty(probFontSize)),  probFontSize = 10; end;
  if (isempty(stateLabels)),   stateLabels = tostr(1:nStates); end;
  
  if (~ischar(stateLabels)),   stateLabels = tostr(stateLabels); end;
  if (isvect(stateLabels)),    stateLabels = stateLabels(:); end;
  
  errorState = false;
  tol = 1e-6;
  for iState = 1:nStates
    if (abs(1-rowsum(transitionProbs(iState,:)))>tol)
      errorState = true;
      transitionProbs(iState,:) = transitionProbs(iState,:)/sum(transitionProbs(iState,:));
    end;
  end;
  if (errorState)
    disp('  EthogramPlot: one or more rows of transition matrix adjusted to sum to unity.');
  end;
  
  radius = 1;
  stateCenters = Circcrds(radius,[],nStates+1);             % Get crds of centers for state circles
  stateCenters(end,:) = [];
  stateCenters(:,1) = -stateCenters(:,1);                   % Put first state on left of diagram
  stateCenterSeparation = eucl(stateCenters(1,:),stateCenters(2,:));
  maxStateRadius = 0.23*stateCenterSeparation;
  minStateRadius = 0.05;
  
  stateRadii = magnitudes/max(magnitudes)*(maxStateRadius-minStateRadius) + minStateRadius;
  
  for iState = 1:nStates
    CirclePlot(stateRadii(iState),stateCenters(iState,:));
    text(stateCenters(iState,1),stateCenters(iState,2),stateLabels(iState,:),...
      'Fontsize',stateFontSize,'HorizontalAlignment','center');
  end;
  axis equal;
  isSquarePlot = false;
  
  minLineWidth = 1;
  maxLineWidth = 5; 
  shiftDistance = 0.015*(max(stateCenters(:,1))-min(stateCenters(:,1)));
  endPts = zeros(2,2);
  maxProb = max(max(transitionProbs));
  
  for iState1 = 1:nStates                                   % Cycle thru pairs of states
    for iState2 = 1:nStates
      prob = transitionProbs(iState1,iState2);                % Get probability

      if (iState1==iState2)                                   % Temporarily ignore self-transitions
        if (prob >= thresholdProb)
          textPos = LineSegExtend([0,0],stateCenters(iState1,:),stateRadii(iState1)+0.10);
          text(textPos(1),textPos(2),sprintf('%3.2f',prob),'FontSize',probFontSize,...
          	'HorizontalAlignment','center');
        end;

      elseif (prob >= thresholdProb)                    
        tailCrds = stateCenters(iState1,:);                   % Get direction and length of arrow
        headCrds = stateCenters(iState2,:);
        
        tailCrds = LineSegExtend(headCrds,tailCrds,-stateRadii(iState1));
        headCrds = LineSegExtend(tailCrds,headCrds,-stateRadii(iState2));
        [tailCrds,headCrds] = LineSegShift(tailCrds,headCrds,shiftDistance);
        
        lineWidth = (prob/(2*maxProb))*(maxLineWidth-minLineWidth) + minLineWidth;  % Make line thickness proportional
        PutArrow(tailCrds,headCrds,isSquarePlot,[],[],lineWidth);     %   to probability
        
        theta = atan((headCrds(2)-tailCrds(2))/(headCrds(1)-tailCrds(1)))*(180/pi); % Arrow angle from horizontal
        textShiftDistance = shiftDistance + 0.02*prob;
        if (headCrds(1)>=tailCrds(1))        % If arrow points to right,
          vertAlign = 'bottom';             	% Print above arrow
          textShiftDistance = textShiftDistance + 0.02*prob + 0.0001*abs(theta);
          [endPts(1,:),endPts(2,:)] = LineSegShift(stateCenters(iState1,:),stateCenters(iState2,:),textShiftDistance);
        elseif (headCrds(1)<tailCrds(1))    % If arrow points to left,
        	vertAlign = 'top';                  % Print below arrow            
          [endPts(1,:),endPts(2,:)] = LineSegShift(stateCenters(iState1,:),stateCenters(iState2,:),textShiftDistance);
        end;
        textPos = [mean(endPts(:,1)),mean(endPts(:,2))];     % Find midpoint for printing prob value
        
        if (isEven(nStates) && nStates>2)     % If nStates is even, shift some printed prob values
          if (abs(iState1-iState2)==nStates/2)
            textPos = LineSegExtend(stateCenters(iState1,:),textPos,0.22*stateCenterSeparation);
          elseif (isEven(abs(iState1-iState2)))
            textPos = LineSegExtend(stateCenters(iState1,:),textPos,0.11*stateCenterSeparation);
          end;
        end;
       
        text(textPos(1),textPos(2),sprintf('%3.2f',prob),'FontSize',probFontSize,...
        	'HorizontalAlignment','center','VerticalAlignment',vertAlign,'Rotation',theta);
      end;
    end;
  end;
  
  axis off;
  PutWhite;

  return;
  
