% Design: Creates an anova-type design matrix from a vector of group identifiers.
%
%     Usage: G = Design(groupingVector)
%
%         groupingVector = row or column vector (length nObs) of group identifiers.
%         -------------------------------------------------------------------------
%         G =              [nObs x nGrps] design matrix.
%

% RE Strauss, 6/16/93
%   11/23/99 - addition of isvect() call.
%    1/23/08 - standardized variable names.

function G = Design(groupingVector)
  if (~isvect(groupingVector))
    error('  DESIGN: group identifiers must be vector.');
  end;
  
  groupingVector = groupingVector(:);

  nObs = length(groupingVector);                % Number of observatons
  grpIds = UniqueValues(groupingVector);
  nGrps = length(grpIds);                       % Number of groups
  G = zeros(nObs,nGrps);                        % Initialize G to zeros
  for iObs = 1:nObs                             % Set appropriate cells to one
    for iGrp = 1:nGrps
      if (groupingVector(iObs)==grpIds(iGrp))
        G(iObs,iGrp) = 1;                       
        break;
      end;
    end;
  end;

  return;
