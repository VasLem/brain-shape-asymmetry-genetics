% Cophenetic: Given two distance matrices, find cophenetic correlation and related 
%         of measures association.  None of the measures can be tested for significance
%         unless dist1 and dist1 are derived from different data for the same objects.
%
%     Usage: index = Cophenetic(dist1,dist2,{noPlot})
%
%         dist1, dist2 - comparable square symmetric distance matrices of identical size.
%         -------------------------------------------------------------------------------
%         index - structure containing measures of association:
%           coCorr -     cophenetic correlation coefficient (0-1).
%           rankCoCorr - rank correlation (0-1).
%           gower -      Gowers sum-of-squared-difference coefficient (0-Inf).
%           mse -        mean squared difference (0-Inf).
%

% Rohlf, FJ (1974) Methods for comparing classifications. Ann Rev Ecol Syst 5:101-113.
% Gower, JC (1983) Comparing classifications. In: J Felsenstein (ed), Numerical Taxonomy,
%   p 137-155. NATO ASI Series, Vol G-1. Springer-Verlag, Berlin.

% RE Strauss, 5/25/08
%   5/27/08 - added Gower's and mse measures; pass output as structure.

function index = Cophenetic(dist1,dist2,noPlot)
  if (~nargin), help Cophenetic; return; end;
  
  if (nargin<3), noPlot = []; end;
  
  if (isempty(noPlot)), noPlot = false; end;

  d1 = trilow(dist1);
  d2 = trilow(dist2);
  
  coCorr = corr(d1,d2);
  rankCoCorr = rankcorr(d1,d2);
  gower = sum((d1-d2).^2);  
  mse = gower/length(d1);
  
  if (~noPlot)
    scatter(d1,d2);
    hold on;
    m = max([d1;d2]);
    plot([0,m],[0,m],'k:');
    hold off;
    putxlab('Distance 1');
    putylab('Distance 2');
  end;
  
  index.coCorr = coCorr;
  index.rankCoCorr = rankCoCorr;
  index.gower = gower;
  index.mse = mse;

  return;
  
