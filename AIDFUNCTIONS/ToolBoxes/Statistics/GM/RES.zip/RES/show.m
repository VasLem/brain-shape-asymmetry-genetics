% SHOW: synonymous with whos
%

whos
