% GrpCenter: Zero-center the columns of a data matrix by group
%
%     Usage: Z = GrpCenter(X,grps)
%
%         X =    [n x p] data matrix.
%         grps = group-identification vector of length n.
%         -----------------------------------------------
%         Z =    [n x p] group-centered data matrix.
%

% RE Strauss, 6/19/93
%   11/29/99 - changed calling sequence.
%   6/3/08 -   allow for null input matrices.

function Z = GrpCenter(X,grps)
  if (~nargin), help GrpCenter; return; end;

  if (nargin<1), X = []; end;
  if (nargin<2), grps = []; end;
  
  if (isempty(X))
    Z = [];
    return;
  end;
  
  if (isempty(grps))
    grps = ones(size(X,1),1);
  end;
  
  G = design(grps);                     % ANOVA-type design matrix
  mean_W = (G'*G)\G'*X;                 % Within-group means
  Z = X - G*mean_W;                     % Group-center all variables

  return;


