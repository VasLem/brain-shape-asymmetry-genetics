% Isvect: Returns true if the input matrix is a vector, false if not.  Optionally 
%           returns the vector's length (=total number of cells, if not a 
%           vector), and a boolean flag indicating whether the vector is a 
%           colummn.
%
%     Usage: [isv,ncells,iscol] = Isvect(X,{kind})
%
%           X =       [r x c] matrix.
%           kind =    optional scalar indicating the kind of vector to be tested for:
%                       1 = row vector, 2 = column vector [default = either].
%           -------------------------------------------------------------------------
%           isv =     boolean flag indicating whether (=1) or not (=0) the input 
%                       matrix is a vector.
%           ncells =  number of cells.
%           iscol =   boolean flag indicating whether (=1) or not (=0) the 
%                       vector is a column vector.
%

% RE Strauss, 11/20/99
%   5/4/00 -   corrected wrong decision for scalar input.
%   10/28/03 - added optional test for kind of vector.
%   4/5/05 -   changed name from isvector() to isvect() to avoid Matlab 7 conflict.

function [isv,ncells,iscol] = Isvect(X,kind)
  if (nargin < 2), kind = []; end;
  if (nargin < 1)
    isv = false;
    ncells = 0;
    iscol = false;
    return;
  end;

  [r,c] = size(X);
  isv = false;
  iscol = false;

  if (isequal([r c],[1 1]))             % Is a scalar
    ncells = 1;
  elseif (min([r,c])==1)                % Is a vector
    ncells = max([r,c]);
    if (isempty(kind))                    % Is either kind of vector
      isv = true;
      if (r>1)
        iscol = true;
      end;
    else 
      switch (kind)
        case 1,                           % Is a row vector
          if (c>1)
            isv = true;
          else
            iscol = true;
          end;
        case 2,                           % Is a column vector
          if (r>1)
            isv = true;
            iscol = true;
          end;
        otherwise
          error('  Isvect: invalid ''kind'' flag.');
      end;
    end;
  else                                  % Is not a vector
    ncells = r.*c;
  end;

  return;
  