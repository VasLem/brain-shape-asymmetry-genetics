% DISTANCE: Converts a set of point coordinates to a set of interpoint Euclidean 
%           distances or square roots of areas, given the conversion specifications.
%
%       Usage: dist = distance(specifs,crds,...
%                              {indiv},{scalebar},{scaleunits},{missrefpt},{areas})
%
%         specifs =    matrix (with d rows) containing conversion specifications for
%                        d distances or areas, one row per variable.  Each row minimally 
%                        contains indices for 2 points.  If a sequence of >2 points is 
%                        specified, the path length from first point to last will be 
%                        reported.  If two corresponding sequences are specified, 
%                        Nseparated by a 0 or aN, the mean of the two path lengths will be 
%                        reported.  Unused positions within the specification matrix may 
%                        be filled with zeros or NaNs.
%         crds =       [n x p] set of point coordinates.
%         indiv =      optional vector [length n] specifying k individuals, each 
%                        represented by the same number (np) of point coordinates 
%                        (so that np x k = n).  [Default: all coordinates for a  
%                        single individual].
%         scalebar =   optional vector of two point indices specifying 
%                        digitized scale bar.
%         scaleunits = optional units for scale bar [default = 1].
%         missrefpt =  optional index specifying the point below which 
%                        'missing-data' points have been digitized.
%         areas =      optional boolean vector (length d) indicating which variables
%                        are instead to be sqrt(areas) of the polygons specified by
%                        corresponding points in 'specifs'.
%         --------------------------------------------------------------------------------
%         dist =       [k x nd] row vector of distance variables.
%
%
%       Sample 'specifs' and 'areas' matrices:
%         specifs = [ 1 3 0 0  0  0  0
%                     4 5 6 0  0  0  0
%                     7 8 9 0 10 11 12
%                     3 4 5 8  6  0  0 ];
%         areas =   [ 0 0 0 1 ];
%
%       These sample matrices specify 4 output variables:
%         1: the distance between points 1 and 3.
%         2: the distance between points 4 and 6, via point 5.
%         3: the mean of the bilateral distances between points 7-8-9 and 10-11-12.
%         4: the sqrt(area) of the polygon enclosed by points 3, 4, 5, 8, and 6.
%

% RE Strauss, 4/5/97
%   9/19/99 -  updated handling of default input arguments.
%   12/1/99 -  allow for missing-data reference point and scale bar.
%   12/11/01 - fixed problem with missing points when have no scale bar.
%   9/20/05 -  rewritten to simplify specifications and allow for bilateral averaging.

function dist = distance(specifs,crds,indiv,scalebar,scaleunits,missrefpt,areas)
  if (nargin < 3) indiv = []; end;
  if (nargin < 4) scalebar = []; end;
  if (nargin < 5) scaleunits = []; end;
  if (nargin < 6) missrefpt = []; end;
  if (nargin < 7) areas = []; end;

  [ndist,ncols] = size(specifs);
  [n,ndim] = size(crds);

  if (isempty(indiv))                       % Default: crds for single indivual
    indiv = ones(n,1);
  else
    if (length(indiv) ~= n)
      error('  DISTANCE: "crds" and "indiv" matrices not compatible');
    end;
  end;
  
  if (isempty(areas))                       % Default: all linear distances
    areas = zeros(ndist,1);
  end;

  rescale = 0;
  check_missing = 0;
  if (~isempty(scalebar))
    rescale = 1;
    if (max(scalebar) > n)
      error('  DISTANCE: scale bar point specification out of range');
    end;
    if (length(scalebar) ~= 2)
      error('  DISTANCE: scale bar must be vector of two point indices');
    end;
  end;
  if (~isempty(missrefpt))
    check_missing = 1;
    if (max(missrefpt) > n)
      error('  DISTANCE: scale bar point specification out of range');
    end;
  end;

  if (~isempty(scalebar) & isempty(scaleunits))
    scaleunits = 1;
  end;
  
  [uindiv,findiv] = uniquef(indiv);
  if (var(findiv)>0)
    error('  DISTANCE: all individuals must have same number of point coordinates');
  end;
  ncrds = findiv(1);

  if (max(specifs(:))>ncrds)                % Check point-spec range
    error('  DISTANCE: point specification out of range');
  end;

  if (max(areas)>1 | min(areas)<0)
    error('  DISTANCE: invalid "areas" specification');
  end;
  
  [i,j] = find(~isfinite(specifs));         % Replace NaNs in specification matrix
  if (~isempty(i))                          %   with zeros
    for k = 1:length(i)
      specifs(i(k),j(k)) = 0;
    end;
  end;

  indlist = uniquef(indiv);                 % List of individual identifiers
  nind = length(indlist);                   % Number of individuals

  dist = NaN*ones(nind,ndist);              % Allocate output distance matrix

  for id = 1:nind                           % Cycle thru indivuals
    ind = indlist(id);
    crdind = crds(indiv==ind,:);              % Extract points for current indivual

    if (check_missing)                        % Check for missing-data points
      mdi = find(crdind(:,2) < crdind(missrefpt,2));
      if (~isempty(mdi))                        % Replace specifs below missing-data 
        if (rescale)                            %   reference pt with NaN's
          j = find(mdi==scalebar(1) | mdi==scalebar(2));  % But not the scale bar specifs
          if (~isempty(j))
            mdi(j) = [];
          end;
        end;
        crdind(mdi,:) = NaN*ones(length(mdi),ndim);  
      end;
    end;

    for v = 1:ndist                           % Cycle thru variables
      spec = specifs(v,:);                      % Isolate current specifications
      p = spec(1);
      i = 2;
      while (spec(i)>0)                         % Isolate first point sequence
        p = [p, spec(i)];
        i = i+1;
      end;
      c = crdind(p,:);                          % Isolate first subset of crds
      if (areas(v))                             % Convert to sqrt(area)
        value = sqrt(polyarea(c));
      else                                      %   or path length
        value = pathlen(c);
      end;
      
      if (i<ncols)                              % Check for second point sequence
        i = i+1;
        ip = find(spec(i:end)>0);
        if (~isempty(ip))
          p = spec(ip);
          c = crdind(p,:);
          if (areas(v))                             % Convert to sqrt(area)
            value = 0.5*(value + sqrt(polyarea(c)));
          else                                      %   or path length
            value = 0.5*(value + pathlen(c));
          end;
        end;
      end;
      dist(id,v) = value;
    end;

    if (rescale)                      % Rescale with respect to scale bar
      scale_factor = eucl(crdind(scalebar,:)) ./ scaleunits;
      dist(id,:) = dist(id,:)./scale_factor;
    end;
  end;
  
  return;
