% LoadingsScores: Calculate loadings and scores from eigenvectors.
%
%     Usage: [loadings,scores,meanScores,wVarScores] = ...
%                 LoadingsScores(X,evects,{nVects},{loadingsType},{standardizeScores})
%
%         X =            [n x p] data matrix.
%         evects =       [p x nVects] matrix of eigenvectors.
%         nVects =       optional number of leading eigenvectors to be returned [default = all].
%         loadingsType = optional flag indicating the scaling for the loadings: 
%                           0: vector correlations [default];
%                           1: regression coefficients;
%                           2: squared loadings sum to unity.
%         standardizeScores = optional boolean flag indicating, if true, that scores 
%                           are to be standardized to zero mean and unit variance 
%                           [default = false].  
%                         If loadingsType = 1, standardization is done before regression 
%                           coefficients are estimated.
%                         If standardizeScores is a numeric group-membership vector rather than 
%                           a scalar, scores are standardized to zero mean and within-group 
%                           variance.
%         ---------------------------------------------------------------------
%         loadings =   [p x nVects] matrix of loadings.
%         scores =     [n x nVects] matrix of scores.
%         meanScores = vector of mean scores before scaling (if standardizeScores~=false).
%         wVarScores = vector of within-group variances in scores before scaling 
%                       (if standardizeScores~=false).
%

% RE Strauss, 5/2/00
%   5/3/00 -   added error for invalid 'loadingsType' flag.
%   5/4/00 -   added option to standardize scores; return meanScores and wVarScores.
%   12/10/04 - allow 'nVects' to be optional.
%   3/6/08 -   renamed from 'loadscrs'; standardize variable names.

function [loadings,scores,meanScores,wVarScores] = ...
                          LoadingsScores(X,evects,nVects,loadingsType,standardizeScores)
  if (~nargin), help LoadingsScores; return; end;
  
  if (nargin < 3), nVects = []; end;
  if (nargin < 4), loadingsType = []; end;
  if (nargin < 5), standardizeScores = []; end;

  [n,p] = size(X);

  if (isempty(nVects)),            nVects = p; end;
  if (isempty(loadingsType)),      loadingsType = 0; end;
  if (isempty(standardizeScores)), standardizeScores = 0; end;
  
  loadings = [];
  meanScores = [];
  wVarScores = [];
  
  if (isvect(standardizeScores))
    grps = standardizeScores;
    standardizeScores = 2;
  end;

  scores = ScoreCalc(X,evects,nVects);              % Scores for subset of eigenvectors
  if (any(~isfinite(scores)))
    disp('  Loadscrs warning: not all scores are finite.');
    return;
  end;

  switch(standardizeScores)                     % Standardize scores
    case 0
    case 1,
      scores = standardizeScorescore(scores);

    case 2,
      u = uniquef(grps);
      if (length(u)>1)
        cp = covpool(scores,grps,1);
      else
        cp = cov(scores);
      end;
      meanScores = mean(scores);                    % Mean scores before scaling
      wVarScores = diag(cp)';                       % Pooled within-group variances
      scores = (scores-ones(n,1)*meanScores)./(ones(n,1)*sqrt(wVarScores));

    otherwise
      error('  LOADSCRS: invalid standardizeScores flag');
  end;

  switch(loadingsType)                          % Loadings
    case 0,                                       % Vector correlations
      loadings = corr(X,scores);            

    case 1,                                       % Regression coefficients
      loadings = zeros(p,nVects);
      for ipc = 1:nVects
        S = [ones(n,1) scores(:,ipc)];
        for ip = 1:p
          y = X(:,ip);
          b = inv(S'*S)*S'*y;
          loadings(ip,ipc) = b(2);
        end;
      end;

    case 2,
      loadings = sumsqscale(evects(:,1:nVects));  % Squared coeffs sum to unity

    otherwise
      error('  LOADSCRS: invalid loadings type');
  end;

  return;
