% ReflectPts: Reflects 2D points about a line, given two points defining a line segment.
%
%     Usage: rPts = ReflectPts(pts,line)
%
%         pts =   [nPts x 2] matrix of point coordinates.
%         line = [2 x 2] matrix or 4-element vector of two sets of point coordinates: 
%                  [p1 p2; q1 q2] or [p1 p2, q1 q2].
%         ---------------------------------------------------------------------------
%         rPts =  [nPts x 2] matrix of reflected point coordinates.
%

% Bookstein et al. 1985. Morphometrics in Evolutionary Biology, appendix A.1.11.
%   Note: couldn't get A.1.11 to work.

% RE Strauss, 4/22/03
%   5/14/03 - added error message.

function rPts = ReflectPts(pts,line)
  [nPts,p] = size(pts);
  if (p~=2)
    error('  ReflectPts: point coordinates must be 2D.');
  end;
  
  line = line';
  line = line(:);
  line = [line(1:2)';line(3:4)'];
  if (~isequal(size(line),[2,2]));
    error('  ReflectPts: invalid line-segment coordinates.');
  end;
  

  allPts = [line; pts];                                        % Combine line-seg pts and pts to be reflected
  [rotAllPts,theta] = RegisterRotate(1,2,allPts);              % Rotate line to horizontal
  rotAllPts(3:end,2) = -rotAllPts(3:end,2);                    % Reflect pts about line
  allPts = Rotate(rotAllPts,-theta,rotAllPts(1,:));            % Rotate back to position
  allPts = allPts + ones(nPts+2,1)*line(1,:);
  rPts = allPts(3:end,:);

  return;
  
