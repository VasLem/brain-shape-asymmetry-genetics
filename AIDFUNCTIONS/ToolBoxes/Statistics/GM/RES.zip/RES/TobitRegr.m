% TobitRegr: Fits the regression model for censored data, in which all values of the
%         independent variable are known but the dependent variable is truncated below a fixed
%         censor point.  Assumes that censored values are passed as NaN.
%
%     Usage: [b,mse,pred] = TobitRegr(xVars,yVar,{limit})
%
%         xVars =     [n x p] vector of independent-variable (predictor) values.
%         yVar =     corresponding vector of dependent-variable (response) values, with 
%                   censored observations passed as NaN.
%         limit = optional censoring limit value for dependent variable [default = minimum
%                   non-censored value - eps].
%         ---------------------------------------------------------------------------------
%         b =     regression coefficients [b0, b1, ..., bp].
%         mse =   mean square error (estimated residual variance).
%         pred =  predicted values, including predicted censored values.
%

% Note: add adjusted R-squred, p-value.

% RE Strauss, 10/28/02
%   12/4/02 - changed default value of 'limit' from zero to min non-censored value of y
%               minus a small value.
%   12/5/02 - added 'limit' to predicted values.
%   1/21/08 - misc syntax updates.

function [b,mse,pred] = TobitRegr(xVars,yVar,limit)
  if (nargin < 3), limit = []; end;
  
  [nObs,nVars] = size(xVars);
  m = size(yVar,1);
  if (~isvect(yVar))
    error('  TobitRegr: dependent variable must be a vector.');
  end;
  if (nObs~=m)
    error('  TobitRegr: X and y matrices must have same sample size.');
  end;
  if (limit > max(yVar))
    error('  TobitRegr: data must be censored from below.');
  end;
  if (limit > min(yVar))
    error('  TobitRegr: dependent-variable values must be > censoring limit.');
  end;
  
  if (isempty(limit))                   % Default detection limit
    limit = min(yVar(isfinite(yVar))) - eps;
  end;

  xVars = [ones(nObs,1),xVars];         % Pre-concatenate a vector of one's for intercept estimate
  yVar = yVar-limit;
  
  i = find(isfinite(yVar));             % Uncensored observations
  xVarsUnc = xVars(i,:);
  invXUnc = inv(xVarsUnc'*xVarsUnc);
  b = invXUnc*xVarsUnc'*yVar(i);         % Initial regression estimates

  pred = xVars*b;
  e = yVar(i)-pred(i);                         
  dfe = nObs-nVars-1;
  if (dfe<1)
    error('  TobitRegr: error degress of freedom are <1');
  end;
  mse =  (e'*e)/dfe;
  sigma = sqrt(mse);                % Initial estimate of sigma

  p = fminsearch('tobitllfn',[sigma,b'],[],xVars,yVar);

  sigma = p(1);
  b = p(2:end)';
  
  pred = xVars*b+limit;                 % Final estimates
  b(1) = b(1)+limit;                % Add censor limit to intercept
  mse = sigma*sigma;
  
  return;
  
