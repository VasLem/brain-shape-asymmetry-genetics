% PlotBoxplot: Box plot function, producing box or point plot for non-missing data.
%
%     Usage: PlotBoxplot(x,y,{plotType},{doConnect},{doHomoSubsets},{doSampleSizes},{boxWidth})
%
%           x =             abscissa values at which individual boxplots will be plotted.
%           y =             vector of values for which boxplot is to be plotted.
%           plotType =      optional value indicating kind of plot to be produced:
%                             0 = box plot using means, stdevs, ranges [default];
%                             1 = box plot using quartiles;
%                             2 = point plot, using doConnected means;
%                             3 = point plot, using doConnected medians.
%           doConnect =     optional boolean flag indicating that centers of continguous
%                             box or point plots are to be doConnected by lines [default = 0].
%           doHomoSubsets = optional boolean flag indicating that homogeneous subsets are to be labeled.
%           doSampleSizes = optional boolean flag indicating that sample sizes are to be printed.
%           boxWidth =      optional box plot boxWidth, in units of x [default = 55% of least
%                             difference in consecutive x's].
%

% RE Strauss, 5/6/98
%   9/7/99 -  changed plot colors for Matlab v5.
%   9/23/03 - changed to relative default for bar boxWidths.
%   3/30/04 - delete missing data.
%   4/25/06 - appended boxplotb() to this file, renamed PlotBoxplotBar; 
%             renamed variables.
%   8/31/06 - renamed from BoxPlot(); added labeling of homogeneous subsets.

function PlotBoxplot(x,y,plotType,doConnect,doHomoSubsets,doSampleSizes,boxWidth)
  if (~nargin) help boxplot; return; end;

  if (nargin < 3) plotType = []; end;
  if (nargin < 4) doConnect = []; end;
  if (nargin < 5) doHomoSubsets = []; end;
  if (nargin < 6) doSampleSizes = []; end;
  if (nargin < 7) boxWidth = []; end;

  if (isempty(plotType))      plotType = 0; end;
  if (isempty(doConnect))     doConnect = 0; end;
  if (isempty(doHomoSubsets)) doHomoSubsets = 0; end;
  if (isempty(doSampleSizes)) doSampleSizes = 0; end;

  if (~isvect(x) | ~isvect(y))
    error('  PlotBoxplot: input matrices must be matching vectors.');
  end;
  y = y(:);
  
  i = find(isfinite(x) & isfinite(y));            % Delete missing values
  x = x(i);
  y = y(i);
  data = [x y];
  
  [r,c] = size(y);

  [uniqueXValues,freqs] = UniqueValues(x,1);      % Find unique x values, in sequence
  nUniqueXValues = length(uniqueXValues);
  middleBarCrds = zeros(nUniqueXValues-1,4);

  if (doHomoSubsets & any(freqs<2))
    disp('  PlotBoxplot warning: labeling of homogeneous subsets requires >1 observations/group');
    doHomoSubsets = 0;
  end;
  
  if (plotType==0 | plotType==1)                  % Boxplot
    if (isempty(boxWidth))                             % Default box boxWidth
      deltaXMin = min(uniqueXValues(2:end)-uniqueXValues(1:end-1));
      boxWidth = 0.55*deltaXMin;
    end;

    hold on;
    for i = 1:nUniqueXValues
      [lc,rc] = DrawBoxplotBar(y(x==uniqueXValues(i)),uniqueXValues(i),boxWidth,plotType);
      middleBarCrds(i,:) = [lc rc];
    end;

    if (doConnect)
      for i = 1:nUniqueXValues-1
        plot([middleBarCrds(i,3);middleBarCrds(i+1,1)],[middleBarCrds(i,4);middleBarCrds(i+1,2)],'k');
      end;
    end;
    hold off;

    [xm,i] = min(x);
    x(i) = x(i) - boxWidth;
    [xm,i] = max(x);
    x(i) = x(i) + boxWidth;
  
  elseif (plotType==2 | plotType==3)                % Point plot
    plot(x,y,'ko');
    if (doConnect)
      if (plotType==2)
        centers = means(y,x);
      else
        centers = medians(y,x);
      end;
      
      hold on;
      for i = 1:nUniqueXValues-1
        plot(uniqueXValues(i:(i+1)),centers(i:(i+1)),'k');
      end;
      hold off;
    end;
  else
    error('  PlotBoxplot: invalid plot type.');
  end;

  putbnd(x,y);
  puttick(uniqueXValues);

  if (doSampleSizes)
    n = PrintSampleSizes(data(:,1),data(:,2),doHomoSubsets);
  end;
  if (doHomoSubsets)
    [f,pr,df] = LabelHomoSubsets(data(:,1),data(:,2),doSampleSizes);
  end;
    
  box on;

  return;
  
% ----------------------------------------------------------------------------------------  

% DrawBoxplotBar: Plots single bar for a box plot, assuming that the current plot is being 
%           held ('hold on');
%
%     Usage: [lm,rm] = DrawBoxplotBar(y,x,boxWidth,{plotType})
%
%           y =     vector containing distribution of values for a single group
%           x =     abscissa value at which boxplot is to be plotted
%           boxWidth = boxWidth of boxplot
%           plotType = optional boolean flag indicating summary statistics to be plotted:
%                     0 = mean, stdev, range [default]
%                     1 = quartiles
%           --------------------------------------------------------------------------
%           lm =    [1 x 2] vector of coordinates of left edge of mean/median bar.
%           rm =    [1 x 2] vector of coordinates of right edge of mean/median bar.
%

% RE Strauss, 5/6/98
%   9/7/99 - changed plot colors for Matlab v5.

function [lm,rm] = DrawBoxplotBar(y,x,boxWidth,plotType)
  if (nargin < 4) plotType = []; end;

  if (isempty(plotType))
    plotType = 0;
  end;

  yBoxCrds = zeros(5,1);                         % Box positions, bottom to top
  yBoxCrds(1) = min(y);
  yBoxCrds(5) = max(y);

  if (plotType)
    p = [25,50,75];
    yBoxCrds(2:4) = prctile(y,p)';
  else
    ym = mean(y);
    ys = std(y);
    yBoxCrds(2) = ym - ys;
    yBoxCrds(3) = ym;
    yBoxCrds(4) = ym + ys;
  end;

  xl = x - boxWidth/2;
  xh = xl + boxWidth;

  for i = 1:5
    plot([xl xh],[yBoxCrds(i) yBoxCrds(i)],'k');    % Crossbars
  end;
  plot([xl xl],[yBoxCrds(2) yBoxCrds(4)],'k');
  plot([xh xh],[yBoxCrds(2) yBoxCrds(4)],'k');
  plot([x x],[yBoxCrds(1) yBoxCrds(2)],'k');
  plot([x x],[yBoxCrds(4) yBoxCrds(5)],'k');

  lm = [xl yBoxCrds(3)];
  rm = [xh yBoxCrds(3)];

  return;
  
% ----------------------------------------------------------------------------------------  

% PrintSampleSizes: Prints sample sizes above bars.
%

function n = PrintSampleSizes(x,y,doHomoSubsets)
  hold on;
  v = axis;
  v(4) = v(4) + 0.07*(v(4)-v(3));
  axis(v);
%   dy = 0.04*(v(4)-v(3));
  dy = 0.07*(v(4)-v(3));
  
  
  [uniqueX,freqs] = uniquef(x,1);
  for ix = 1:length(uniqueX)
    d = uniqueX(ix);
    i = find(x==d);
    my = max(y(i));
    dx = -0.01*(log10(freqs(ix))+1)*(v(2)-v(1));
    if (doHomoSubsets)
      dx = dx - 0.008*(log10(freqs(ix))+1)*(v(2)-v(1));
      h = text(d+dx,my+dy,[int2str(freqs(ix)),',']);
    else
      h = text(d+dx,my+dy,int2str(freqs(ix)));
    end;
    set(h,'FontSize',12);
  end;
  hold off;
  
  n = freqs;

  return;
  
% ----------------------------------------------------------------------------------------  

% LabelHomoSubsets: Determines and labels homogeneous subsets using letters A,B,..
%         Returns statistics from anova.
%

function [F,pr,df] = LabelHomoSubsets(x,y,doSampleSizes)
  [F,pr,df] = anova(y,x);
  homoSubsets = homosub(y,x);
  
  hold on;
  v = axis;
  v(4) = v(4) + 0.07*(v(4)-v(3));
  dx = -0.01*(v(2)-v(1));
%   dy = 0.04*(v(4)-v(3));
  dy = 0.07*(v(4)-v(3));
  if (~doSampleSizes)
    axis(v);
  else
    dx = dx + 0.04*(v(2)-v(1));
  end;
  
  uniqueX = unique(x);
  for ix = 1:length(uniqueX)
    d = uniqueX(ix);
    i = find(x==d);
    my = max(y(i));
    h = text(d+dx,my+dy,homoSubsets(ix));
    set(h,'FontSize',12);
  end;
  hold off;

  return;

