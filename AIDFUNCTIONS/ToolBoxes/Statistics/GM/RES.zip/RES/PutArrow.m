% PutArrow: Plots an arrow from one specified point to another on the current plot.  
%        Axis boundaries and aspect ratio of plot should be set before arrow() 
%        is called.
%
%     Syntax: PutArrow(tailCrds,headCrds,{isSquarePlot},{headSize},{lineStyle},{lineWidth})
%
%           tailCrds =      vector of x,y coordinates of tail point.
%           headCrds =      vector of x,y coordinates of head point.
%           isSquarePlot =	optional boolean flag indicating that the plot has been squared 
%                             [default = 0].
%           headSize =      optional size of arrow head (proportion of arrow shaft length) 
%                             [default = 0.03].
%           lineStyle =     optional string vector indicating color/style of line 
%                             [default = black solid line].
%           lineWidth =     optional line width (in points) [default = 1].
%

% RE Strauss, 2/7/97
%   9/3/99 -   misc changes for Matlab v5.
%   11/25/99 - changed default arrow-head size.
%   2/26/00 -  changed names of input arguments.
%   1/2/02 -   changed name of function from arow() to putarrow();
%              added error-check for point coordinates.
%   6/10/03 -  change headSize to proportion of x-axis range rather than shaft-length;
%              convert 'headSize' percentage to proportion.
%   11/14/03 - change headSize default from 0.008 to 0.03;
%              remove calc of headSize as proportion of x range.
%   2/11/07 -  added line-width option; standardized variable names.
%   6/2/08 -   always print arrowhead as black solid line.

function PutArrow(tailCrds,headCrds,isSquarePlot,headSize,lineStyle,lineWidth)
  if (nargin < 3), isSquarePlot = []; end;
  if (nargin < 4), headSize = []; end;
  if (nargin < 5), lineStyle = []; end;
  if (nargin < 6), lineWidth = []; end;

  if (isempty(isSquarePlot)), isSquarePlot = false; end;
  if (isempty(headSize)),     headSize = 0.03; end;
  if (isempty(lineStyle)),    lineStyle = 'k-'; end;
  if (isempty(lineWidth)),    lineWidth = 1; end;

  if (length(tailCrds)~=2 || length(headCrds)~=2)
    error('  PUTARROW: tail and head arguments must be 2D coordinates.');
  end;

  if (headSize>1)
    headSize = headSize/100;
  end;
  if (headSize<0 || headSize>1)
    error('  PUTARROW: arrowhead size must be expressed as proportion');
  end;

  headAngle = 0.90*pi;
  
  stdTailCrds = ptscale(tailCrds);        % Scale coords to proportional distances
  stdHeadCrds = ptscale(headCrds);
  
  if (isSquarePlot)
    aspectRatio = 1;
  else
    corners = get(gca,'Position');
    aspectRatio = (corners(4)-corners(2))./(corners(3)-corners(1));
  end;

  theta = angle((stdHeadCrds(1)-stdTailCrds(1)) + (stdHeadCrds(2)-stdTailCrds(2))*sqrt(-1));  % Shaft angle
  theta1 = theta + headAngle;
  theta2 = theta - headAngle;
  
  x1 = stdHeadCrds(1) + headSize * cos(theta1) / aspectRatio;
  y1 = stdHeadCrds(2) + headSize * sin(theta1);
  p =  ptscale([x1,y1],1);
  x1 = p(1);
  y1 = p(2);

  x2 = stdHeadCrds(1) + headSize * cos(theta2) / aspectRatio;
  y2 = stdHeadCrds(2) + headSize * sin(theta2);
  p =  ptscale([x2,y2],1);
  x2 = p(1);
  y2 = p(2);

  headStyle = 'k';
  hold on;
  plot([tailCrds(1) headCrds(1)],[tailCrds(2) headCrds(2)],lineStyle,'LineWidth',lineWidth);
  plot([headCrds(1) x1],[headCrds(2) y1],headStyle,'LineWidth',lineWidth);
  plot([headCrds(1) x2],[headCrds(2) y2],headStyle,'LineWidth',lineWidth);

  return;
