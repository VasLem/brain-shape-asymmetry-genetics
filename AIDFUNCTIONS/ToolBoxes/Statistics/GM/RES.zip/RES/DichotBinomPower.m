% DichotBinomPower: For given values of pi and N, converts binomial distributions to 
%     discrete sampling and null probability distributions of the normalized asymmetry 
%     index a=(R-L)/(R+L) and the logit function f=ln(p/(1-p)).  Power is identical for 
%     the three indices because they are monotonic transforms of one another.
%       If parameters p and N are both scalars, a single value of power is calculated and
%     plots of null and sampling distributions are produced.
%       If p is a scalar and N is a vector of sample sizes (numbers of trials), power is
%     calculated for each combination and a plot of power as a function of N is produced.
%       If p is a vector and N is a scalar, power is calculated for each combination and a
%     plot of power as a function of p is produced.
%       If p and N are both vectors, power is calculated for each combination and a contour
%     plot of power as a function of p and N is produced.
%
%     power = DichotBinomPower(p,N,{doPlots},{alpha})
%
%         p -       true binomial probability, pi.
%         N -       number of trials.
%         doPlots - optional boolean argument indicating, if true, that plots of distributions
%                     are to be produced [default = false].
%         alpha -   alpha-level for implied hypothesis test [default = 0.95].
%         ------------------------------------------------------------------------------------
%         power - 2-tailed power of H0:pi=0.5.  
%

% RE Strauss, 5/22/07
%   % Renamed from BinomToAsym.m.  Allow for p, N, or both to be vectors.

% van Der Meer, J. 1992. Statistical analysis of the dichotomous preference test. 
%   Animal Behavior 44:1101-1106.

function [power,distribs] = DichotBinomPower(pBinom,nTrials,doPlots,alpha)
  if (nargin < 3), doPlots = []; end;
  if (nargin < 4), alpha = []; end;
  
  if (isempty(doPlots)), doPlots = false; end;
  if (isempty(alpha)), alpha = 0.05; end;
  
  if (alpha>1), alpha = alpha/100; end;
  
  getDistribs = false;
  distribs = [];
  if (nargout > 1), getDistribs = true; end;

  x = (0:nTrials)';                              % Binomial probabilities
  yNull = binopdf(x,nTrials,0.5);                  % Null distribution
  ySamp = binopdf(x,nTrials,pBinom);               % Sampling distribution
  
  bNull = [x, yNull];
  bSamp = [x, ySamp];
  
  right = x;                                    % Normalized asymmetry index
  left = nTrials-right;
  a = (right-left)./(right+left);
  aNull = [a, yNull];
  aSamp = [a, ySamp];
  
  p = x./nTrials;                                % Logit model
  p(1) = 0.05;
  p(end) = 0.95;
  logitValues = log(p./(1-p));
  nCounts = 10000;
  sturges = 1+ceil((10/3)*log10(nCounts));
  
  nullDistrib = makegrps(logitValues,round(yNull*nCounts));   % Expand probs to counts
  sampDistrib = makegrps(logitValues,round(ySamp*nCounts));
  [y,newLogitValues] = hist([nullDistrib; sampDistrib],sturges);
  
  yNull = hist(nullDistrib,newLogitValues);
  fNull = [newLogitValues', yNull'/1000];
  ySamp = hist(sampDistrib,newLogitValues);
  fSamp = [newLogitValues', ySamp'/1000];
  
  if (getDistribs)
    distribs.aNull = aNull;
    distribs.aSamp = aSamp;
    distribs.fNull = fNull;
    distribs.fSamp = fSamp;
    distribs.bNull = bNull;
    distribs.bSamp = bSamp;
  end;

  if (doPlots)
    PlotDistrib(bNull,bSamp,pBinom,'Binomial','Number of successes');
    PlotDistrib(aNull,aSamp,pBinom,'Normalized R-L difference','Index value');
    PlotDistrib(fNull,fSamp,pBinom,'Logit','Log-ratio');
  end;
  
  power = EstimatePower(bNull,bSamp);

  return;
  
% -----------------------------------------------------------------------------------------

function PlotDistrib(xyNull,xySamp,pBinom,plotTitle,xLabel)
  x = xyNull(:,1);
  y = xyNull(:,2);
  xMin = min(x);
  xMax = max(x);
  xRange = xMax-xMin;
  axisBounds = [xMin-0.10*xRange, xMax+0.10*xRange, 0, 1.05*max(y)];
  
  figure;
  histgramb(x,y,[],[],true);
  axis(axisBounds);
  putxlab(xLabel);
  putylab('Frequency');
  puttext(0.05,0.92,sprintf('%s = %3.2f',texlabel('pi'),0.5));
  puttitle(plotTitle);

  x = xySamp(:,1);
  y = xySamp(:,2);
  xMin = min(x);
  xMax = max(x);
  xRange = xMax-xMin;
  axisBounds = [xMin-0.10*xRange, xMax+0.10*xRange, 0, 1.05*max(y)];
  
  figure;
  histgramb(x,y,[],[],true);
  axis(axisBounds);
  putxlab(xLabel);
  putylab('Frequency');
  puttext(0.05,0.92,sprintf('%s = %3.2f',texlabel('pi'),pBinom));
  puttitle(plotTitle);

  return;
    
% -----------------------------------------------------------------------------------------

function power = EstimatePower(null,samp)
  alpha = 0.05;
  nCounts = 10000;
  
  [xNull,yNull] = ExtractCols(null);
  [xSamp,ySamp] = ExtractCols(samp);
  
  nullDistrib = makegrps(xNull,round(yNull*nCounts));
  sampDistrib = makegrps(xSamp,round(ySamp*nCounts));

  prc = prctile(nullDistrib,100*[alpha/2,1-alpha/2]);
  beta = sum(sampDistrib>prc(1) & sampDistrib<prc(2))/nCounts;
  power = 1-beta;

  return;
  
  
