% SchnuteGrowthModelFit:  Fits the 2-parameter growth model of Schnute (1981) to size-at-age data.
%
%     Usage: [params,yPred,yEvalPred] = SchnuteGrowthModelFit(x,y,{xEval},{doPlot})
%
%         x = vector (length n) of ages.
%         y = corresponding vector (length n) of sizes-at-ages.
%         xEval = optional vector of ages at which the growth curve is to be evaluated 
%                     [default = linspace(min(x),max(x)].
%         doPlot = optional boolean flag indicating, if true, that a plot of data and fitted growth curve
%                     is to be produced [default = false].
%         -------------------------------------------------------------------------------------------------
%         params = structure containing estimated parameters (=NaN if don't exist):
%                     a,b = Schnute parameters.
%                     yAsymptotic = asymptotic size.
%                     xInflection = age at inflection.
%                     yInflection = size at inflection.
%         yPred = predicted sizes at input ages.
%         yEvalPred = predicted sizes at specified xEval.
%

% Schute, J. 1981. A versatile growth model with statistically stable parameters.  
%   Canadian Journal of Fisheries and Aquatic Sciences 38:1128-1140.

% RE Strauss, 4/21/06

function [paramsVector,paramsStruct,yPred,yEvalPred] = SchnuteGrowthModelFit(x,y,xEval,doPlot)
  if (nargin < 3) xEval = []; end;
  if (nargin < 4) doPlot = []; end;
  
  if (isempty(doPlot))   doPlot = false; end;
  
  [x1,i] = min(x);                            % Min and max observed ages, and corresponding sizes
  y1 = y(i(1));
  [x2,i] = max(x);
  y2 = y(i(1));
  
  if (y1<eps)
    y1 = 0.01*y2;
  end;
  
  if ((x2-x1)<eps | (y2-y1)<eps | y<eps)      % Check for wrong model
    paramsVector = NaN*ones(1,5);
    paramsStruct.a = NaN;
    paramsStruct.b = NaN;
    paramsStruct.yAsymptote = NaN;
    paramsStruct.xInflection = NaN;
    paramsStruct.yInflection = NaN;
    yPred = [];
    yEvalPred = [];
    return;
  end;
  
  a = 0;                                      % Initial estimates of parameters a and b
  b = 0;
  
  minmaxX = [x1,x2];
  estimates = [a,b,y1,y2];

  [estimates,sse,exitflag,output] = ...       % Nonlinear regression
    fminsearch('SchnuteGrowthModelFitFn',estimates,optimset('MaxFunEvals',6000,'Display','off'),minmaxX,x,y); 
  if (exitflag<0)
    disp('  SchnuteGrowthModelFit warning: nonlinear regression failed to converge.');
  end;
  if (estimates(3)<eps)
    estimates(3) = 0.01*estimates(4);
  end;


  if (isempty(xEval)) xEval = linspace(x1,x2); end;
  [sse,yPred] = SchnuteGrowthModelFitFn(estimates,minmaxX,x,y);          % Evaluate at observed ages
  [sse,yEvalPred] = SchnuteGrowthModelFitFn(estimates,minmaxX,xEval,y);  % Evaluate at interpolated ages
  
  if (doPlot)
    scatter(x,y);
    hold on;
    plot(xEval,yEvalPred,'k');
    hold off;
  end;
  
  paramsStruct.a = estimates(1);
  paramsStruct.b = estimates(2);
  paramsStruct.yAsymptote = getAsymptoteSize(estimates,minmaxX);
  [paramsStruct.xInflection,paramsStruct.yInflection] = getInflectionCrds(estimates,minmaxX);
  
  paramsVector = [paramsStruct.a,paramsStruct.b,paramsStruct.yAsymptote,paramsStruct.xInflection,paramsStruct.yInflection];
  
  return;
  
% ------------------------------------------------------------------------------------------------------------------------

function yAsymptote = getAsymptoteSize(estimates,minmaxX)
  [a,b,y1,y2] = ExtractCols(estimates);
  [x1,x2] = ExtractCols(minmaxX);  
  
  tol = eps;
  aIsZero = (abs(a)<tol);                             % Check for a or b effectively equal to zero
  bIsZero = (abs(b)<tol);

  yAsymptote = NaN;
  
  if (~aIsZero & ~bIsZero)                            % Schnute eqn 25
    yAsymptote = ((exp(a*x2)*y2^b-exp(a*x1)*y1^b)/(exp(a*x2)-exp(a*x1)))^(1/b);
  elseif (~aIsZero & bIsZero)
    yAsymptote = exp((exp(a*x2)*log(y2)-exp(a*x1)*log(y1))/(exp(a*x2)-exp(a*x1)));
  end;
  
  yAsymptote = real(yAsymptote);
  
  return;
  
% ------------------------------------------------------------------------------------------------------------------------

function [xInflection,yInflection] = getInflectionCrds(estimates,minmaxX)
  [a,b,y1,y2] = ExtractCols(estimates);
  [x1,x2] = ExtractCols(minmaxX);  
  
  tol = eps;
  aIsZero = (abs(a)<tol);                             % Check for a or b effectively equal to zero
  bIsZero = (abs(b)<tol);

  xInflection = NaN;
  yInflection = NaN;
  
  if (~aIsZero & ~bIsZero)                            % Schnute eqns 26 & 27
    xInflection = x1+x2-(1/a)*log((b*(exp(a*x2)*y2^b-exp(a*x1)*y1^b))/(y2^b-y1^b));
    yInflection = (((1-b)*(exp(a*x2)*y2^b-exp(a*x1)*y1^b))/(exp(a*x2)-exp(a*x1)))^(1/b);
  elseif (~aIsZero & bIsZero)
    xInflection = x1+x2-(1/a)*log((exp(a*x2)-exp(a*x1))/log(y2/y1));
    yInflection = exp((exp(a*x2)*log(y2)-exp(a*x1)*log(y1))/(exp(a*x2)-exp(a*x1))-1);
  end;
  
  xInflection = real(xInflection);
  yInflection = real(yInflection);
  
  return;
  