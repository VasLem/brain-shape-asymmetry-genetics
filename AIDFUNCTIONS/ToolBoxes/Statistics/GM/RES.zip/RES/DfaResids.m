% DfaResids: Given sets of predictor and response variables: centers the variables by group,
%     calculates multiple-regression residuals, restores group means, and performs a 
%     discriminant analysis on the response variables.  If no predictor variables are passed,
%     the pooled within-group PC1 scores are used for regression.
%
%     Usage: [df,score,manovaStats,mahalStats,yResids] = DfaResids(yVars,xVars,grps,...
%               {nDFs},{nVarsIncl},{nIters},{noPlots},{grpLabels},{varLabels},{grpSymbols},...
%               {plotTitle},{ciLevel})
%                                                     
%
%         yVars -     [n x p] matrix of response variables to be 'size-adjusted'.
%         xVars -     [n x q] matrix of predictor variables; if null, the pooled 
%                       within-group PC1 scores are used.
%         grps -      corresponding [nObs x 1] vector of group-membership labels for nGrps
%                       groups.
%         nDFs -      optional number of discriminant functions to be output
%                       [default = min(max(nGrps-1,2),nVars)].
%         nVarsIncl - optional number of 'best' variables to be included in calculation of
%                       discriminant functions [default = all, if possible].
%         nIters -    optional number of bootstrap iterations [default = 0].
%         noPlots -   optional boolean variable indicating that scatterplot and vectorplot
%                       are not to be produced [default = false].
%         grpLabels - optional character labels for groups, for plotting.
%         varLabels - optional character labels for input variables, for plotting.
%         grpSymbols -  optional character matrix of group symbols and colors (rows), for plotting.
%                         If symbols are standard Matlab linespec characters (see documentation for
%                         plot function), Matlab conventions are used; if not, symbols are printed
%                         as text characters.
%         plotTitle - optional title for score and loading plots [default = none].
%         ciLevel -   optional confidence level for bootstrapped confidence intervals
%                       [default = 95].
%         -------------------------------------------------------------------------------------
%         df -          structure containing information on discriminant functions (see Dfa.m).
%         score -       structure containing scores (see Dfa.m).
%         manovaStats - structure containing manova statistics (see Dfa.m).
%         mahalStats -  structure containing statistics on Mahalanobis statistics (see Dfa.m).
%         yResids -     [n x p] matrix of residual variables.
%

% RE Strauss, 4/24/08
%   5/26/08 - changed call from discrim() to Dfa().
%   9/2/08 -  added mahalStats to output.

function [df,score,manovaStats,mahalStats,yResids] = DfaResids(yVars,xVars,grps,nDFs,nVarsIncl,nIters,...
                                  noPlots,grpLabels,varLabels,grpSymbols,plotTitle,ciLevel)
  if (~nargin), help DfaResids; return; end;
  
  if (nargin< 4), nDFs = []; end;
  if (nargin< 5), nVarsIncl = []; end;
  if (nargin< 6), nIters = []; end;
  if (nargin< 7), noPlots = []; end;
  if (nargin< 8), grpLabels = []; end;
  if (nargin< 9), varLabels = []; end;
  if (nargin<10), grpSymbols = []; end;
  if (nargin<11), plotTitle = []; end;
  if (nargin<12), ciLevel = []; end;
  
  getManova = false;
  getMahal = false;
  if (nargout>2), getManova = true; end;
  if (nargout>3), getMahal = true; end;

  [nObs,nYVars] = size(yVars);
  if (~isempty(xVars) && size(xVars,1)~=nObs)
    error('  DfaResids: numbers of observations for response and predictor variables must be identical.');
  end;
  
  if (isempty(varLabels))
    varLabels = tostr(1:nYVars);
  end;
  
  [centeredXVars,centeredYVars,grpIds,meansXVars,meansYVars,grandMeanXVars] = GetMeans(xVars,yVars,grps);
  nGrps = length(grpIds);
  yResids = GetResids(nGrps,nObs,nYVars,grps,grpIds,...
                              centeredXVars,centeredYVars,meansXVars,meansYVars,grandMeanXVars);
                              
  %% Discriminant analysis of original response variables
  
  if (~isempty(plotTitle))
    pT = [plotTitle,': original data'];
  else
    pT = 'Original data';
  end;
  
  [dfOrig,scoreOrig] = Dfa(yVars,grps,nDFs,nVarsIncl,0,true,grpLabels,varLabels,grpSymbols,pT,[],ciLevel);
  nVarsUsedOrig = dfOrig.nVarsUsed;
  
  %% Discriminant analysis of residuals
  
  if (~isempty(plotTitle))
    pT = [plotTitle,': residual data'];
  else
%     pT = 'Residual data';
    pT = [];
  end;
  
  manovaStatsResid = [];
  mahalStatsResid = [];
  if (getMahal)
    [dfResid,scoreResid,manovaStatsResid,mahalStatsResid] = ...
                       Dfa(yResids,grps,nDFs,nVarsUsedOrig,nIters,noPlots,grpLabels,varLabels,grpSymbols,pT,[],ciLevel);
  elseif (getManova)
    [dfResid,scoreResid,manovaStatsResid] = ...
                       Dfa(yResids,grps,nDFs,nVarsUsedOrig,nIters,noPlots,grpLabels,varLabels,grpSymbols,pT,[],ciLevel);
  else
    [dfResid,scoreResid] = ...
                       Dfa(yResids,grps,nDFs,nVarsUsedOrig,nIters,noPlots,grpLabels,varLabels,grpSymbols,pT,[],ciLevel);
  end;
  
  for iDF = 1:nDFs                      % Make DF directions consistent with original
    if (corr(scoreResid.scores(:,iDF),scoreOrig.scores(:,iDF))<0)
      scoreResid.scores(:,iDF) = -scoreResid.scores(:,iDF);
      dfResid.loadings(:,iDF) =  -dfResid.loadings(:,iDF);
    end;
  end;
  
  if (~noPlots)
    DfaPlots(dfResid,scoreResid,grps,[],[],[],pT,grpSymbols);
  end;  
  
  df = dfResid;                         % Relabel structures for output
  score = scoreResid;
  manovaStats = manovaStatsResid;
  mahalStats = mahalStatsResid;

  return;
  
% ----------------------------------------------------------------------------------------

function [centeredXVars,centeredYVars,grpIds,meansXVars,meansYVars,grandMeanXVars] = ...
              GetMeans(xVars,yVars,grps)
  
  centeredYVars = GrpCenter(yVars,grps);          % Center response vars by group
  meansYVars = means(yVars,grps);                 % Response means
  
  if (isempty(xVars))                             % Get PC scores
  	[wl,wp,wSize] = PcaCovar(centeredYVars,1);      % Within-group size scores
    [al,ap,aSize] = PcaCovar(yVars,1);              % Among-group size scores
    centeredXVars = wSize;
    [meansXVars,s,v,grpIds] = means(aSize,grps);    % Group means
  else                                            % Else center predictor vars by group
    centeredXVars = GrpCenter(xVars,grps);
    [meansXVars,s,v,grpIds] = means(xVars,grps);    % Group means
  end;
  grandMeanXVars = mean(meansXVars);
  
  return;
  
% ----------------------------------------------------------------------------------------

function yResids = GetResids(nGrps,nObs,nYVars,grps,grpIds,...
                          centeredXVars,centeredYVars,meansXVars,meansYVars,grandMeanXVars)
  
  yResids = zeros(nObs,nYVars);                   % Allocate matrix for residuals of response vars
  
  for rv = 1:nYVars                               % Cycle thru response variables
    [b,stats,preds,resids] = linregr(centeredXVars,centeredYVars(:,rv)); % Pooled within-grp regr of centered data
    b = b(2:end);                                 % Omit intercept coefficient (=0), leaving slopes
    for g = 1:nGrps                               % For each group,
      pos = find(grps==grpIds(g));                  % Find observations for current group
      yPred = meansXVars(g,:)*b;                    % Use regr coeffs and grp mean of Xs to predict Yi with b0=0
      b0 = meansYVars(g,rv) - yPred;                % Observed grp mean of yi minus predicted = b0 for current group
      yPredAtGrandMean = b0 + grandMeanXVars*b;     % Predicted value of yi at grand mean of Xs
      resids(pos) = resids(pos) + yPredAtGrandMean; % Add residuals to predicted yi at grand mean of Xs
    end;
    yResids(:,rv) = resids;                       % Stash adjusted residuals for current response variable
  end;
  
  return;
  

