% CovPool:  Calculates pooled within-group covariance matrix.  
%           Missing values are replaced by within-group means.
%
%     Usage: [Cp,meanW,isSing] = CovPool(X,grps,{varOnly})
%
%         X =       [n x p] data matrix.
%         grps =    [n x 1] vector of group identifiers for k groups.
%         varOnly = optional boolean flag indicating, if true, that only pooled 
%                     within-group variances are to be returned on the diagonal
%                     of Cp [default = 0].
%         ---------------------------------------------------------------------
%         Cp =      [p x p] pooled within-group covariance matrix.
%         meanW =  [k x p] matrix of within-group means.
%         isSing =  boolean flag indicating, if true, that pooled covariance 
%                     matrix is singular.
%

% RE Strauss, 5/26/99
%   11/29/99 - changed calling sequence.
%   5/4/00 -   added option of variances-only.
%   12/12/00 - added check for singularity and return of within-group means.

function [Cp,meanW,isSing] = CovPool(X,grps,varOnly)
  if (~nargin), help CovPool; return; end;
  
  if (nargin < 3), varOnly = []; end;

  getIsSing = false;
  if (nargout > 2)
    getIsSing = true;
  end;

  if (isempty(varOnly))
    varOnly = false;
  end;

  index = UniqueValues(grps);
  nGrps = length(index);            % Number of groups
  [nObs,nVars] = size(X);           % Numbers of observations & variables
%   ndists = nGrps*(nGrps-1)/2;       % Pairwise combinations

  N =  zeros(nGrps,1);              % Within-group sample sizes
  Cp = zeros(nVars,nVars);          % Pooled covariance matrix

  G = design(grps);                 % Design matrix
  meanW = (G'*G)\G'*X;             % Within-group means
  for g = 1:nGrps                   % Pooled within-group covariance matrix
    index = find(G(:,g));             % Indices to nonzero elements
    n = length(index);                % Sample size of current group
    N(g) = n;                         % Stash sample size
    Y = X(index,:);                   % Get data for current group

    [i,j] = find(~isfinite(Y));         % Handle misSing data
    if (~isempty(i))
      meanW(g,:) = means(Y);
      for k = 1:length(i)
        Y(i(k),j(k)) = meanW(g,j(k));
      end;
    end;

    Ydev =  Y - ones(n,1)*mean(Y);    % Deviations
    Cp = Cp + Ydev'*Ydev;             % Augment within-group sum-of-squares
  end;
  Cp = Cp/(nObs-nGrps);             % Final pooled covariance matrix

  if (varOnly)                      % Reduce only to variances on diagonal
    Cp = diag(diag(Cp));
  end;

  if (getIsSing)                    % Check for singular matrix
%     sizeCp = size(Cp,1);
%     rankCp = rank(Cp);
    isSing = false;
    if (rank(Cp) < size(Cp,1))        % If covar matrix is singular,
      isSing = true;                  %   set flag
    end;
  end;

  return;

