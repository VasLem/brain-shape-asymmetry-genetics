% VonbertBootstrap: Estimates the sampling covariance matrix among the complete set of estimated
%     parameters for a single set of size-at-age data.
%
%     [vbCorrs,vbCovars] = VonbertBootstrap(obsAges,obsSizes,{nIters},{doPlot},{doPca})
%
%           obsAges = 	vector (length N) of ages.
%           obsSizes =  corresponding vector of size-at-age data, which may include missing data.
%           nIters =    optional number of bootstrap iterations [default = 1000].
%           doPlot =    optional boolean flag indicating whether plot is to be produced of
%                         curve and 95% confidence intervals about predicted sizes-at-age
%                         [default = false].
%           doPca =     optional boolean flag indicating whether principal-component analysis
%                         of sampling correlations is to be performed of the bootstrap results 
%                         [default = false].
%           -------------------------------------------------------------------------------------
%           vbCorrs =   estimated sampling correlations among the following parameters and 
%                         derived variables:
%                           7 parameters: c, K, t0, S0, Sj, Sk, Sa.
%                           N predicted sizes at each input age.
%                           9 percent-saturation times: t10, t20, ..., t90.
%                           N instantaneous growth rates at each age.
%           vbCovars =  corresponding matrix of covariances among parameters and derived variables.
%

% RE Strauss, 5/23/07

function [vbCorrs,vbCovars] = VonbertBootstrap(obsAges,obsSizes,nIters,doPlot,doPca)
  if (nargin < 3), nIters = []; end;
  if (nargin < 4), doPlot = []; end;
  if (nargin < 5), doPca = []; end;
  
  if (isempty(nIters)), nIters = 1000; end;
  if (isempty(doPlot)), doPlot = false; end;
  if (isempty(doPca)),  doPca = false; end;

  obsAges =  (obsAges(:))';
  obsSizes = (obsSizes(:))';
  if (length(obsAges)~=length(obsSizes))
    error('  VonbertBootstrap: age and size vectors not of same size.');
  end;
  nObs = length(obsAges);

  [paramsEst,predSizesEst,percSatTimesEst,growthRatesEst] = vonbert(obsAges,obsSizes,doPlot);
  nVars = length(paramsEst)+length(predSizesEst)+length(percSatTimesEst)+length(growthRatesEst);
  
  distribs = zeros(nIters,nVars);         % Allocate bootstrap distributions (cols)
  
  for it = 1:nIters                       % Bootstrap iterations
    r = sort(RandInt(nObs,nObs));
    bootAges = obsAges(r);
    bootSizes = obsSizes(r);
    [params,predSizes,percSatTimes,growthRates] = vonbert(bootAges,bootSizes);
    distribs(it,:) = [params,predSizes,percSatTimes,growthRates];
  end;
  
  vbCovars = cov(distribs);
  vbCorrs =  corrcoef(distribs);
  
  if (doPlot)
    posPredSizes = (length(paramsEst)+1):(length(paramsEst)+length(predSizesEst));
    ciPredSizes = 1.96*std(distribs(:,posPredSizes));
    hold on;
    for cur = 1:length(posPredSizes)
      plot(obsAges(cur),predSizesEst(cur),'kx');
      plot([obsAges(cur),obsAges(cur)],[predSizesEst(cur),predSizesEst(cur)+ciPredSizes(cur)],'k');
      plot([obsAges(cur),obsAges(cur)],[predSizesEst(cur),predSizesEst(cur)-ciPredSizes(cur)],'k');
    end;
    hold off;
  end;
  
  if (doPca)
rankVbCorrs = rank(vbCorrs)    
    vars = sort(Steprank(vbCorrs,floor(rank(vbCorrs)/2)));
    [loadings,percsVar,scores] = pcacorr(distribs(:,vars),2);
    loadings = corr(distribs,scores)    
  end;
  
  return;
  
  
