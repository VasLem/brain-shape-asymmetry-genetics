% Anova2way: Balanced or unbalanced two-factor anova, either conventional (assuming normal 
%            residuals) or based on permutation tests (Anderson & ter Braak 2003).  Factors 
%            A and B may be fixed or random, in any combination, or B may be nested within 
%            A (B assumed to be random).  Ignores missing data.
%
%     Usage: [F,Fdf,pr,ss,df,ms] = Anova2way(x,factorA,factorB,{typeA},{typeB},{nIters})
%
%         x =     [n x 1] vector of observations for a single variable.
%         factorA =     corresponding [n x 1] classification variable for factor A.
%         factorB =     corresponding [n x 1] classification variable for factor B.
%         typeA = optional boolean variable indicating state of factor A:
%                       0 = fixed [default], 1 = random.
%         typeB = optional boolean variable indicating state of factor B:
%                       0 = fixed [default], 1 = random, 2 = nested within A.
%         nIters =  optional number of randomization iterations [default = 0].
%         ------------------------------------------------------------------------------------
%         F =     [3 x 1] vector of F-statistic values for main effects and interaction: 
%                   [F_A, F_B, F_AB].
%         Fdf =   [3 x 2] matrix of degrees-of-freedom corresponding to F-statistics.
%         pr =    [3 x 1] vector of significance levels, either asymptotic (if nIters=0)
%                       or randomized (if nIters>0): P(A), P(B), P(AB).
%         ss =    [5 x 1] vector of sums-of-squares: ssA, ssB, ssAB, ss_error, ss_total.
%         df =    [5 x 1] vector of degrees-of-freedom: dfA, dfB, dfAB, df_error, df_total.
%         ms =    [4 x 1] vector of mean-squares: msA, msB, msAB, mse.
%

% Anderson, MJ & CJF ter Braak. 2003. Permutation tests for multi-factorial analysis
%   of variance.  Journal of Statistical Computation and Simulation 73:85-113.

% RE Strauss, 3/31/04

function [F,Fdf,pr,ss,df,ms] = Anova2way(x,factorA,factorB,typeA,typeB,nIters)
  if (~nargin), help Anova2way; return; end;
  
  if (nargin < 4), typeA = []; end;
  if (nargin < 5), typeB = []; end;
  if (nargin < 6), nIters = []; end;
  
  if (isempty(typeA)), typeA = 0; end;       % Default argument values
  if (isempty(typeB)), typeB = 0; end;
  if (isempty(nIters)),  nIters = 0; end;
    
  i = find(isfinite(x));                    % Delete missing data
  [x,factorA,factorB] = submatrows(i,x,factorA,factorB); 
  N = length(x);
  
  if (typeA==0 && typeB==0)                  % Model I: A fixed, B fixed
    [F,Fdf,ss,df,ms] = Anova2FF(x,factorA,factorB);       % ANOVA statistics
    if (nIters==0)                              % Asymptotic probabilities
      prA = 1-Fcdf(F(1),Fdf(1,1),Fdf(1,2));
      prB = 1-Fcdf(F(2),Fdf(2,1),Fdf(2,2));
      prAB = 1-Fcdf(F(3),Fdf(3,1),Fdf(3,2));
      pr = [prA; prB; prAB];
    else                                      % Randomized probabilities
      Frand = zeros(nIters,3);
      Frand(1,:) = F';
      [mean_tot,meanA,meanB,resids] = CalcResids(x,factorA,factorB);
% x_meantot_meanA_meanB_resids = [x mean_tot meanA meanB resids]   
% mean_x_meantot_meanA_meanB_resids = mean([x mean_tot meanA meanB resids])   

      for it = 2:nIters
%         xp = PermuteResids(mean_tot,meanA,meanB,resids);
xp = x(randperm(N));
        Fp = Anova2FF(xp,factorA,factorB);
        Frand(it,:) = Fp';
      end;
      Frand = sort(Frand);
      pr = randprob(F,Frand)';
    end;
    
  end;
  
% ------------------------------------------------------------------------------  
  
% CalcResids: Calculate residuals, by decomposing the anova model, 
%             to prepare for random permutation of residuals.
%
%     Usage: [mean_tot,meanA,meanB,resids] = CalcResids(x,factorA,factorB)
%
%         x =     [n x 1] vector of observations for a single variable.
%         factorA =     corresponding [n x 1] classification variable for factor A.
%         factorB =     corresonding [n x 1] classification variable for factor B.
%         -------------------------------------------------------------------
%         mean_tot = [n x 1] vector of overall mean.
%         meanA =    [n x 1] vector of means of levels of A.
%         meanB =    [n x 1] vector of means of levels of B.
%         resids =   [n x 1] vector of residuals.
%

% RE Strauss, 3/31/04

function [mean_tot,meanA,meanB,resids] = CalcResids(x,factorA,factorB)
  N = length(x);
  meanA = zeros(N,1);
  meanB = zeros(N,1);
  
  mean_tot = mean(x)*ones(N,1);
  
  [mA,s,v,idA] = means(x,factorA);
  for im = 1:length(mA)
    i = find(factorA==idA(im));
    meanA(i) = mA(im)*ones(length(i),1);
  end;

  [mB,s,v,idB] = means(x,factorB);
  for im = 1:length(mB)
    i = find(factorB==idB(im));
    meanB(i) = mB(im)*ones(length(i),1);
  end;
  
  resids = x + mean_tot - meanA - meanB;  
  return;
  
% ------------------------------------------------------------------------------  
  
% PermuteResids: Randomly permute residuals and reconstruct data values.
%
%     Usage: xp = PermuteResids(mean_tot,meanA,meanB,resids)
%
%         mean_tot = [n x 1] vector of overall mean.
%         meanA =    [n x 1] vector of means of levels of A.
%         meanB =    [n x 1] vector of means of levels of B.
%         resids =   [n x 1] vector of residuals.
%         -------------------------------------------------------
%         xp =       [n x 1] vector of reconstructed data values.
%

% RE Strauss, 3/31/04

function xp = PermuteResids(mean_tot,meanA,meanB,resids)
  N = length(resids);
  resids = resids(randperm(N));
  xp = resids + meanA + meanB - mean_tot;
  return;
  
% ------------------------------------------------------------------------------  
  
% Anova2FF: Model I anova, with both factors being fixed.
%
%     Usage: [F,Fdf,ss,df,ms] = Anova2FF(x,factorA,factorB)
%
%         x =     [n x 1] vector of observations for a single variable.
%         factorA =     corresponding [n x 1] classification variable for factor A.
%         factorB =     corresonding [n x 1] classification variable for factor B.
%         ------------------------------------------------------------------------------
%         F =     [3 x 1] vector of F-statistic values for main effects and interaction: 
%                   [F_A, F_B, F_AB].
%         Fdf =   [3 x 2] matrix of degrees-of-freedom corresponding to F-statistics.
%         ss =    [5 x 1] vector of sums-of-squares: ssA, ssB, ssAB, ss_error, ss_total.
%         df =    [5 x 1] vector of degrees-of-freedom: dfA, dfB, dfAB, df_error, df_total.
%         ms =    [4 x 1] vector of mean-squares: msA, msB, msAB, mse.
%         

% RE Strauss, 3/31/04

function [F,Fdf,ss,df,ms] = Anova2FF(x,factorA,factorB)
  [u_factorAlevels,n_factorAlevels] = UniqueValues(factorA);       % Factor levels
  [u_factorBlevels,n_factorBlevels] = UniqueValues(factorB);
  nlevA = length(u_factorAlevels);
  nlevB = length(u_factorBlevels);
    
  cell_id = Rows2Values([factorA factorB]);             % Cell identifiers
  [u_cell_id,n_cell] = UniqueValues(cell_id);    % Cell sizes
  [uA,nA] = UniqueValues(factorA);                     % Factor sizes
  [uB,nB] = UniqueValues(factorB);
  N = length(x);                            % Total sample size

  tot_cell = sums(x,cell_id);               % Cell totals
  totA = sums(x,factorA);                         % Factor A level totals
  totB = sums(x,factorB);                         % Factor B level totals
  tot_grand = sum(x);                       % Grand totals
  tot_grand2 = sum(x.^2);
  
  C = tot_grand^2/N;                        % Sums of squares
  ss_tot = tot_grand2 - C;
  ss_cell = sum((tot_cell.^2)./n_cell) - C;
  ss_error = ss_tot - ss_cell;
  ssA = sum((totA.^2)./nA) - C;
  ssB = sum((totB.^2)./nB) - C;
  ssAB = ss_cell - ssA - ssB;

  df_tot = N-1;                             % Degrees of freedom for sums of squares
  dfA = nlevA-1;
  dfB = nlevB-1;
  dfAB = dfA*dfB;
  df_cell = nlevA*nlevB - 1;
  df_error = sum(n_cell-1);
  
  msA = ssA/dfA;                            % Mean squares
  msB = ssB/dfB;
  msAB = ssAB/dfAB;
  mse = ss_error/df_error;
  
  FA = msA/mse;                             % F-statistics
  FB = msB/mse;
  FAB = msAB/mse;

  df_FA = [dfA df_error];                   % Degrees of freedom for F-statistics
  df_FB = [dfB df_error];
  df_FAB = [dfAB df_error];
  
  F = [FA; FB; FAB];
  Fdf = [df_FA; df_FB; df_FAB];
  ss = [ssA; ssB; ssAB; ss_error; ss_tot];
  df = [dfA; dfB; dfAB; df_error; df_tot];
  ms = [msA; msB; msAB; mse];
  
  return;
  
