% VONBERT: Fits a von Bertalanffy growth function to k sets of size-at-age data.  
%          Ages must be the same for all k sets of size-at-age data.
%
%     Usage: [params,predSizes,percSatTimes,growthRates,sizeCrds] = vonbert(obsAges,obsSizes,{doPlot})
%
%           obsAges =       vector (length n) of ages.
%           obsSizes =      [k x length(obsAges)] matrix of k sets of size-at-age data.  The 
%                             matrix may include missing data (NaN) but, if so, the Sj and 
%                             Sk parameters might not be equivalent across all data sets.
%           doPlot =        optional boolean flag indicating whether plot is to be produced
%                             [default = false].
%           -------------------------------------------------------------------------------------
%           params =        [k x 7] matrix of parameters: c, K, t0, S0, Sj, Sk, Sa.
%           predSizes =   	[k x n] matrix of predicted sizes at each input age.
%           percSatTimes = 	[k x 9] matrix of percent-saturation times: t10, t20, ..., t90.
%           growthRates =  	[k x n] matrix of instantaneous growth rates at each age.
%           sizeCrds =      [k x 100] matrix of predicted sizes for ages linspace(t0,obsAges(n)), 
%                             suitable for plotting.
%

% RE Strauss 10/22/98
%   11/5/98 - allow missing data in obsSizes matrix.
%   1/4/00 -  changed fminu() to fmins().
%   3/1/00 -  allow obsAges & obsSizes to be column vectors.
%   2/28/02 - changed fmins() to fminsearch(); make plot optional.
%   5/4/07 -  rename variables.

function [params,predSizes,percSatTimes,growthRates,sizeCrds] = Vonbert(obsAges,obsSizes,doPlot)
  if (nargin < 3), doPlot = []; end;
  
  if (isempty(doPlot)), doPlot = false; end;

  if (isvect(obsAges))
    obsAges = (obsAges(:))';
  else
    error('  Vonbert: age must be a vector.');
  end;
  if (isvect(obsSizes))
    obsSizes = (obsSizes(:))';
  end;
  
  nAges = length(obsAges);
  [nSets,nSizes] = size(obsSizes);
  
  nParams = 7;                                  % Number of parameters estimated
  percSaturation = 0.1:0.1:0.9;                 % Percent-saturation levels

  getPredSizes = false;                         % Determine which output parameters have been
  getPercSatTimes = false;                      % requested, set flags and allocate matrices
  getGrowthRates =  false;
  getSizeCrds = false;
  
  predSizes = [];
  percSatTimes = [];
  growthRates = [];
  sizeCrds = [];

  if (nargout > 1)
    getPredSizes = true;
    predSizes = zeros(nSets,nAges);
  end;
  if (nargout > 2)
    getPercSatTimes = true;
    percSatTimes = zeros(nSets,length(percSaturation));
  end;
  if (nargout > 3)
    getGrowthRates = true;
    growthRates = zeros(nSets,nAges);
  end;
  if (nargout > 4)
    getSizeCrds = true;
    sizeCrds = zeros(nSets,100);
  end;
  
  if (doPlot)
    getSizeCrds = true;
  end;

  if (nSizes ~= nAges)
    error('  Vonbert: Age vector and size-at-age matrix incompatible.');
  end;

  params = zeros(nSets,nParams);          % Parameter estimates
  weights = ones(1,nAges);                % Weights vector

  for iSet = 1:nSets                      % Cycle thru data sets
    bodysize = obsSizes(iSet,:);

    fvals = find(finite(bodysize));
    bodysize = bodysize(fvals);
    age = obsAges(fvals);
    w = weights(fvals);
    nAges = length(age);

    init = [bodysize(1),bodysize(nAges),0.5];
    p1 = fminsearch('vbfunc',init,[],age,bodysize,w); % Fit function

    si = p1(1);
    sk = p1(2);
    c =  p1(3);

    ti = age(1);
    tk = age(nAges);

    cexp = c.^(tk-ti);

    K = -log(c);
    t0 = ti - log((sk-si)/(sk-si*cexp)) / log(c);
    Sa = (sk-si*cexp)/(1-cexp);
    s0 = si + (sk-si)*(1-c.^(-ti))/(1-cexp);

    params(iSet,:) = [c K t0 s0 si sk Sa];

    if (getPredSizes)                      % Predicted size-at-age
      predSizes(iSet,:) = Sa .* (1-exp(-K.*(obsAges-t0)));
    end;

    if (getPercSatTimes)              % Percent-saturation times
      percSatTimes(iSet,:) = t0 + log(1-percSaturation)/log(c);
    end;

    if (getGrowthRates)
      growthRates(iSet,:) = log(c) .* (si-sk).*(c.^obsAges)./(c^ti-c^tk);
    end;
  end;

  if (getSizeCrds)
    K =  params(:,2);
    t0 = params(:,3);
    Sa = params(:,7);

    minAge = min(t0);
    maxAge = max(obsAges);
    t = linspace(minAge,maxAge);

    for iSet = 1:nSets                    % Cycle thru data sets
      sizeCrds(iSet,:) = Sa(iSet) .* (1-exp(-K(iSet).*(t-t0(iSet))));
    end;

    if (doPlot)
      hold on;
      plot(t,sizeCrds(1,:),'k',obsAges,obsSizes(1,:),'ok');
      if (nSets>1)
        for iSet = 2:nSets
          plot(t,sizeCrds(iSet,:),'k');
          plot(obsAges,obsSizes(iSet,:),'ok');
        end;
        v = axis;
        v = [0,1.05*maxAge,0,v(4)];
        axis(v);
      end;
      hold off;
      box on;
    end;
  end;

  return;
