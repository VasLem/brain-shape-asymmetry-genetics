% Rarefact: Calculation of expected number of objects (species, alleles, etc.)
%           at a standard sample size, by the rarefaction method.
%           Randomized confidence intervals are estimated by randomizing the 
%           observed absolute frequencies; see prbcount().
%
%     Usage: [es,esCI,nObjs,nTot] = Rarefact(freq,{nIters},{ciLevel},{doPlot})
%
%           freq =      vector (length nObjs) of absolute frequencies (counts) of 
%                         individuals per object, for nObjs object.
%           nIters =    optional number of randomization iterations at each value 
%                         of n, for confidence intervals [default = 0].
%           ciLevel =   optional level of confidence level [default = 95].
%           doPlot =    optional boolean flag indicating, if true, that 
%                         rarefaction curve is to be plotted [default = false].
%           ---------------------------------------------------------------------
%           es =        [nTot x 1] vector of expected number of objects in a random 
%                         sample of n individuals, for n = 1 to observed nTot.
%           esCI =      [nTot x 2] matrix of randomized confidence limits for 
%                         corresponding ES estimates.
%           nObjs =     number of objects in sample.
%           nTot =      total number of individuals in sample.
%

% Krebs, CJ. 1989. Ecological Methodology.  Harper & Row.  Chapter 10.
% Hurlbert, SH. 1971. The non-cept of species diversity: a critique and 
%   alternative parameters. Ecology 52:577-586.
% Sanders, H.L. 1968. Marine benthic diversity: a comparative study. Am. Nat. 
%   102:243-282.

% RE Strauss, 2/19/00
%   2/24/06 - generalize from species to objects.

function [es,esCI,nObjs,nTot] = Rarefact(freq,nIters,ciLevel,doPlot)
  if (~nargin), help Rarefact; return; end;
  
  if (nargin < 2), nIters = []; end;
  if (nargin < 3), ciLevel = []; end;
  if (nargin < 4), doPlot = []; end;

  getEsci = false;
  if (nargout > 1),      getEsci = true; end;
  if (isempty(nIters)),  nIters = 0; end;
  if (isempty(ciLevel)), ciLevel = 95; end;
  if (isempty(doPlot)),  doPlot = false; end;

  if (~isvect(freq))
    error('  Rarefact: frequencies must be in vector form.');
  end;

  freq = freq(:);
  i = find(freq==0);
  if (~isempty(i)), freq(i) = []; end;

  nObjs = length(freq);
  nTot = sum(freq);

  es = zeros(nTot,1);
  esCI = [];

  for n = 1:nTot                                  % Rarefaction curve
    ess = 0;
    for s = 1:nObjs
      ess = ess + (1-comb(nTot-freq(s),n)/comb(nTot,n));
    end;
    es(n) = ess;
  end;

  if (nIters)                                     % Randomized confidence intervals
    if (~getEsci && ~doPlot)
      disp('  Rarefact warning: no output, randomization not performed.');
      return;
    end;

    distrib = zeros(nIters,nTot);                 % Allocate sampling distribs

    for it = 1:nIters                             % Iterate
      f = prbcount(freq./nTot,nTot,nTot,0,0);      	% Randomize frequencies
      for n = 1:nTot                                % Rarefaction for each n
        es = 0;
        for s = 1:nObjs
          es = es + (1-comb(nTot-f(s),n)/comb(nTot,n));
        end;
        distrib(it,n) = es;
      end;
    end;

    esCI = bootci(distrib,es,[],ciLevel)';        % Confidence intervals
  end;

  if (doPlot)
    figure;
    n = 1:nTot;
    plot(n,es,'k');

    if (nIters)
      hold on;
      plot(n,esCI(:,1),'k--');
      plot(n,esCI(:,2),'k--');
      putbnd([n,n,n]',[es;esCI(:,1);esCI(:,2)]);
      hold off;
    else
      putbnd(n,es);
    end;

    putxlab('Number of individuals in sample');
    putylab('Expected number');
  end;

  return;


