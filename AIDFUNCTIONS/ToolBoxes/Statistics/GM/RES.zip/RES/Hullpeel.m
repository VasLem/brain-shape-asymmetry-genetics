% Hullpeel: Finds a set of nested convex hulls characterizing 2-dimensional 
%           percentiles by hull peeling (Barnett 1976, Bebbington 1978).  
%           The (1-a)% hull is the largest hull containing no more 
%           than (1-a)% of the data (Riani Zani & Corbellini 1997).
%
%     Usage: [ptPctile,hullPctile,hullArea,med] = Hullpeel(crds,{doPlot})
%
%           crds =        [n x 2] matrix of point coordinates.
%           doPlot =      optional boolean flag indicating, if true, that points 
%                           and hulls are to be plotted [default = 0].
%           --------------------------------------------------------------------
%           ptPctile =    [n x 1] vector of percentiles of individual points.
%           hullPctile =  [h x 1] vector of percentile values of nested hulls,
%                           for h hulls.
%           hullArea =    [h x 1] vector of areas within each hull.
%           med =         [1 x 2] vector of coordinates of 2D median.
%

% Barnett, V. 1976. The ordering of multivariate data.  J.Am.Statist.Assoc. 
%   A139:318-339.
% Bebbington, AC. 1978. A method of bivariate trimming for robust estimation
%   of the correlation coefficient.  Appl.Statist. 27:221-226.
% Riani, M., S. Zani & A. Corbellini. 1997. Robust bivariate boxplots and
%   visualization of multivariate data.  In: I. Balderjahn, R. Mathar &
%   M. Schader (eds.), Classification, Data Analysis, and Data Highways,
%   pp. 93-100.  Springer-Verlag.

% RE Strauss, 1/5/99
%   5/31/99 - output the 2D median.
%   9/3/99 -  changed plot color for Matlab v5.
%   5/20/00 - added percentile values to plot; added hull areas.

function [ptPctile,hullPctile,hullArea,med] = Hullpeel(crds,doPlot)
  if (nargin<2), doPlot = []; end;

  getAreas = 0;
  getMedian = 0;
  if (nargout >= 3)
    getAreas = 1;
  end;
  if (nargout >= 4)
    getMedian = 1;
  end;

  if (isempty(doPlot))
    doPlot = 0;
  end;
  if (doPlot)
    getMedian = 1;
  end;

  [n,p] = size(crds);
  if (p~=2)
    error('HULLPEEL: coordinates must be two-dimensional');
  end;

  hullID = zeros(n,1);               % Allocate output matrices
  hullPctile = [];
  hullArea = [];
  med = []; 

  if (doPlot)                         % Initialize plot
    Scatterplot(crds);
    hold on;
  end;

  incl = ones(n,1);
  h = 0;
  
  while (sum(incl)>=3)                 % Peel hulls
    p = sum(incl)*100/n;
    hullPctile = [hullPctile; p];
    in = find(incl==1);
    [hullPts,index] = hull(crds(in,:));
    index = in(index);
    nh = length(index);
    incl(index) = zeros(nh,1);
    h = h+1;
    hullID(index) = h*ones(nh,1);

    if (getAreas)
      hullArea = [hullArea; polyarea(hullPts)];
    end;

    if (getMedian)
      med = mean(crds(index,:));
    end;

    if (doPlot)
      plot(hullPts(:,1),hullPts(:,2),'k');
      [mh,ih] = max(hullPts(:,1));
      text(hullPts(ih,1),hullPts(ih,2),sprintf('  %1.0f',p));
    end;
  end;

  ptPctile = hullID;                % Identify percentiles of individual points
  lenHPctile = length(hullPctile);  
  for h = 1:lenHPctile
    i = find(ptPctile==h);
    ptPctile(i) = hullPctile(h)*ones(length(i),1);
  end;

  i = find(ptPctile==0);             % Points within central hull
  if (~isempty(i))
    leni = length(i);
    p = leni*100/n;
    ptPctile(i) = p*ones(length(i),1);

    if (getMedian)
      if (leni>1)
        med = mean(crds(i,:));
      else
        med = crds(i,:);
      end;
    end;
  end;

  if (doPlot)
    plot(med(1),med(2),'+k');
    hold off;
  end;

  return;