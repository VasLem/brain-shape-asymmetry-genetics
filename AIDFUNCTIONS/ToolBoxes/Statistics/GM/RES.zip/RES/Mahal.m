% Mahal: Mahalanobis distances among groups, based on the pooled covariance  
%        matrix among all groups.  Reduces the number of variables to an optimal 
%        subset if the pooled covariance matrix is singular.
%        Note: D2 is summed across variables, and therefore is dependent on
%          (not adjusted for) the number of variables.
%
%     Syntax: [D2,CI,prob,power] = Mahal(X,grps,{iter},{CI_level})
%
%        X =         [n x p] data matrix (obs x vars).
%        grps =      row or column vector of group identifiers.
%        iter =      number of bootstrap and randomization iterations [default=0].
%        CI_level =  percent width of confidence intervals [default=95].
%        ---------------------------------------------------------------------
%        D2 =    [g x g] symmetric distance matrix.
%        CI =    [g x g] matrix of low (lower triangular matrix) and
%                  high (upper triangular matrix) confidence limits.
%                  If iter=0, they are asymptotic estimates using a
%                    noncentral F-distribution.
%                  If iter>0, they are unbiased bootstrapped estimates.
%        prob =  [g x g] matrix of probabilities of H0:D2=0.
%                  If iter=0, they are asymptotic estimates based on an
%                    F-statistic.
%                  If iter>0, both asymptotic (lower triangular matrix) and
%                    randomized (upper triangular matrix) estimates are given.
%        power = [g x g] symmetric matrix of power estimates.
%

% RE Strauss, 5/21/95
%   3/20/98 -   major rewrite.
%   11/27/99 -  handle singular covar matrix.
%   11/29/99 -  reversed X and grps in calling sequence.
%   6/13/00 -   added check for missing data.
%   8/29/08 -   change to pass arguments to new function Dfa.m.

function [D2,CI,prob,power] = Mahal(X,grps,iter,CI_level)
  if (nargin < 3), iter = []; end;
  if (nargin < 4), CI_level = []; end;
  
  getCI = false;
  getProb = false;
  if (nargout>1), getCI = true; end;
  if (nargout>2), getProb = true; end;

  if (getCI && getProb)
    [D2,CI,prob] = MahalDist(X,grps,iter,CI_level);
  elseif (getCI)
    [D2,CI] = MahalDist(X,grps,iter,CI_level);   
  else
    D2 = MahalDist(X,grps,iter,CI_level);
  end;
  power = [];
  
  return;
