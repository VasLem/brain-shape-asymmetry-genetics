% Revise Matlab function names and content

clear all;
close all;

oldFuncnames = LoadTxt('c:\RES\TTU\Programming\Matlab\OldFunctionNames.txt');
newFuncnames = LoadTxt('c:\RES\TTU\Programming\Matlab\NewFunctionNames.txt');

oldDir = 'c:\RES\TTU\Programming\Matlab\RES6';
newDir = 'c:\RES\TTU\Programming\Matlab\RES';

ChangeFunctionNames(oldFuncnames,newFuncnames,oldDir,newDir);

