% CrdsSizeStandardize: Given a set of landmark coordinates for a set of forms, removes size 
%         variation by calculating all pairwise distances among landmarks, regressing them 
%         individually on PC1 scores and substituting residuals, and refitting the landmark
%         coordinates by multidimensional scaling (MDS).
%
%     Usage: crdsSizefree = ...
%               CrdsSizeStandardize(crds,medianLandmarks,pairedLandmarks,specimens,{plotSpecs})
%
%         crds -            [nPts x nSpecs,2] matrix of landmark coordinates.
%         medianLandmarks - vector of indices of median landmarks.
%         pairedLandmraks - [nPairedPts,2] matrix of indices of corresponding landmarks.
%         specimens -       vector of specimen identifiers.
%         plotSpecs -       optional boolean variable indicating that size-adjusted specimen
%                             configurations are to be plotted [default = false].
%         ----------------------------------------------------------------------------------
%         crdsSizefree -    [nPts x nSpecs,2] matrix of landmark coordinates.
%         percVar -         percentage of total variance accounted for by PC1.
%

% RE Strauss, 4/29/08

function [crdsSizefree,percVar] = ...
                CrdsSizeStandardize(crds,medianLandmarks,pairedLandmarks,specimens,plotSpecs)
  if (~nargin), help CrdsSizeStandardize; return; end;
  
  if (nargin < 5), plotSpecs = []; end;
  if (isempty(plotSpecs)), plotSpecs = false; end;
  
  [nPts,p] = size(crds);
  if (p~=2)
    error('  CrdsBilateralAvg: coordinates must be 2D.');
  end;
  
  [nPairedPts,p] = size(pairedLandmarks);
  if (p~=2)
    error('  CrdsBilateralAvg: paired landmarks must be 2D.');
  end;
  
  medianLandmarks = medianLandmarks(:);
  nMedianPts = length(medianLandmarks);
  
  [uSpecs,fSpecs] = UniqueValues(specimens);
  nSpecs = length(uSpecs);
  
  if (nSpecs>1)
    if (sum(fSpecs-fSpecs(1))>0)
      error('  CrdsBilateralAvg: not all specimens have same number of coordinates.');
    end;
  end;
  nPts = nPts/nSpecs;
  
  if ((nMedianPts+2*nPairedPts)~=nPts)
    error('  CrdsBilateralAvg: numbers of specified landmarks not equal to number of point coordinates.');
  end;
  
  crdsSizefree = zeros(size(crds));             % Allocate output matrix
  
  nVars = nPts*(nPts-1)/2;
  vars = zeros(nSpecs,nVars);                 % Allocate data matrix for interlandmark dists
  
  e = 0;
  for iSpec = 1:nSpecs                          % Convert landmarks to distances for all specimens
    b = e+1;
    e = b+nPts-1;
    vars(iSpec,:) = trilow(eucl(crds(b:e,:)))';
  end;  
  
  vars = log(vars);                           % Log-transform distances
  rankCovMatrix = rank(cov(vars));            	% Rank of covariance matrix
  varsUsed = 1:nVars;
  if (rankCovMatrix < nVars)                   % If cov matrix singular, get subset of vars
    varsUsed = StepRank(cov(vars));
    varsUsed = varsUsed(1:(end-1));
    nUsed = length(varsUsed);
    while (rank(cov(vars(:,varsUsed))) < nUsed)
    	varsUsed = varsUsed(1:(end-1));
      nUsed = length(varsUsed);
    end;
  end;

  [loadings,percVar,pc1Scores] = PcaCovar(vars(:,varsUsed),1); % Calculate PC1 scores
  grandMeanPc1Score = mean(pc1Scores);          % Score at which distances are to be predicted
  
  for iDist = 1:nVars                          % Regr univariate interlandmark distances on PC1 scores
    [b,stats,distPred,distResids] = linregr(pc1Scores,vars(:,iDist),[],grandMeanPc1Score);
    vars(:,iDist) = distPred + distResids;
  end;
  vars = exp(vars);                             % Inverse log-transformation
  
  e = 0;
  for iSpec = 1:nSpecs                          % Reconstruct landmark coordinates from adjusted distances
    b = e+1;
    e = b+nPts-1;
    dists = trisqmat(vars(iSpec,:)');             % Reconvert dists to square symmetric matrix
    c = mds(dists,[],[],[],[],true);              % Map landmarks via multidimensional scaling
    if (c(medianLandmarks(1),1) > c(medianLandmarks(2),1))  % Standardize configuration with respect to landmarks
      c(:,1) = -c(:,1);
    end;
    if (c(pairedLandmarks(1,1),2) > c(pairedLandmarks(1,2),2))
      c(:,2) = -c(:,2);
    end;
    crdsSizefree(b:e,:) = c;
    
    if (plotSpecs)
      figure;                                       % Plot of adjusted landmark configuration
      plotnum(c(:,1),c(:,2));
      axis equal;
      puttitle(sprintf('Specimen %d',uSpecs(iSpec)));
      drawnow;
    end;
  end;

  return;
  
