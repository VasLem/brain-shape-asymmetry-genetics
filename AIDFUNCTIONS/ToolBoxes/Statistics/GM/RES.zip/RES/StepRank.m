% StepRank: To cure a singular correlation or covariance matrix with rank r < p 
%           for p variables, uses a stepwise procedure to find the subset of 
%           r variables such that the log-ratio of the first two eigenvalues of the 
%           reduced matrix is similar as possible to that of the original matrix.
%
%     Usage: vars = StepRank(covMat,{nVars})
%
%           covMat = square symmetric matrix.
%           nVars =  optional number of reduced variables [default = rank(covMat)].
%           -------------------------------------------------------------------
%           vars =   row vector of indices of the subset of variables (unsorted).
%

% RE Strauss, 11/25/98
%   9/27/01 - use issqsym() to check matrix structure;
%             compare condition  of reduced matrix against that of full matrix.
%   7/2/02 -  call condfactor() for condition factor;
%             allow input of nVars.
%   5/20/08 - standardize variable names.

function vars = StepRank(covMat,nVars)
  if (~nargin), help StepRank; return; end;

  if (nargin<2), nVars = []; end;

  [n,matSize] = size(covMat);

  if (~issqsym(covMat))
    error('  StepRank: input matrix must be square symmetric.');
  end;

  if (isempty(nVars))
    nVars = rank(covMat);                      % Rank of original matrix
    if (nVars < 2)
      error('  StepRank: input matrix is of rank 1');
    end;
  else
    if (nVars < 2)
      error('  StepRank: at least two variables must be returned.');
    end;
  end; 
  
  v = 1:matSize;
  if (nVars == matSize)
    vars = v;
    return;
  end;

  origCond = condfactor(covMat);              % Condition of original matrix
  if (~isfinite(origCond))
    vars = 1:nVars;
    disp('  StepRank warning: covariance matrix ill-conditioned; variable subset not optimal.');
    return;
  end;

  bestDiff = Inf;
  for i = 1:(matSize-1)                       % Find two best vars
    for j = (i+1):matSize
      cf = condfactor(covMat([i,j],[i,j]));     % Condition of reduced matrix
      diff = abs(cf-origCond);
      if (diff < bestDiff)
        bestDiff = diff;
        isave = i;
        jsave = j;
      end;
    end;
  end;

  vars = [isave jsave];                       % Initialize lists of variables
  v(vars) = [];

  if (nVars > 2)                              % Find vars 3 ... nVars
    for ir = 3:nVars
      bestDiff = Inf;
      for i = 1:length(v)
        j = [vars v(i)];
        bc = condfactor(covMat(j,j));           % Condition of reduced matrix
        diff = abs(bc-origCond);
        if (diff < bestDiff)
          bestDiff = diff;
          isave = i;
        end;
      end;
      vars = [vars v(isave)]; %#ok<AGROW>
      v(isave) = [];
    end;
  end;

  return;

