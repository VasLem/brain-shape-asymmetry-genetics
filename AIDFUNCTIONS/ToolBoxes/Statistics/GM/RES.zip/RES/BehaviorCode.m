% BehaviorCode:  Function used to encode discrete behaviors as they are being observed.
%
%     Usage:  [sequences,durations] = BehaviorCode(maxTime,{sequences},{durations})
%
%         maxTime -   maximum observation time, in minutes.
%         sequences - optional matrix of pre-existing sequences.
%         durations - optional matrix of pre-existing durations.
%         ---------------------------------------------------------------
%         sequences - matrix containing pre-existing + current sequences.
%         durations - matrix containing pre-existing + current durations.

% RE Strauss, 2/15/09
%   3/24/09 - fixed problem with negative minutes.

function [sequences,durations] = BehaviorCode(maxTime,sequences,durations)
  if (~nargin), help BehaviorCode; return; end;
  warning('off','MATLAB:dispatcher:InexactCaseMatch');
  
  if (nargin<2), sequences = []; end;
  if (nargin<3), durations = []; end;

  codeValues = [          % First number is ascii value of keystroke, second is behavior code
    49 1
    50 2
    51 3
    52 4
    53 5
    54 6
    55 7
    56 8
    57 9
    48 0
    ];
  terminateValue = 115;   % 's' for stop

  initSize = 5000;                              % Allocate large matrices,
  code = zeros(initSize,1);                     %   to be truncated later
  time = zeros(initSize,2);

  t = 0;
  keystroke = 0;

  disp('     Code / min sec =');
  while (keystroke ~= terminateValue)
    keystroke = Getkey;                           % Get keystroke
      i = find(codeValues(:,1)==keystroke);
      if (~isempty(i))
        if (t==0)                                 % Init time (in seconds) at first keystroke
          initTime = ToSecs(clock);
        end;
        t = t+1;
        currentTime = ToSecs(clock) - initTime;   % Current time in seconds
        dSec = rem(currentTime,60);               % Convert to minutes and seconds
        dMin = round((currentTime-dSec)/60);
        time(t,:) = [dMin,dSec];                  % Stash minutes/seconds since first keystroke
        code(t) = codeValues(i,2);                % Stash corresponding code
        disp(sprintf('      %2.0f  / %3.0f %3.1f',code(t),time(t,:)));
      elseif (keystroke ~= terminateValue)
        disp('      Invalid keystroke');
      end;  
  end;

  code = code(1:t);                             % Truncate matrices to observed rows
  time = time(1:t,:);

  i = find(time(:,1)<maxTime);                  % Truncate observations at max time 
  code = code(i);
  time = time(i,:);
  time = time(:,1)*60 + time(:,2);              % Convert min/sec to sec

  repeatLoop = true;                            % Remove duplicate events
  while (repeatLoop)
    codeDiff = abs(code(2:end)-code(1:(end-1)));
    i = find(codeDiff==0);
    if (~isempty(i))
      i = i(1);
      time(i+1) = [];
      code(i+1) = [];
    else
      repeatLoop = false;
    end;
  end;

  time = [time; 60*maxTime];                    % Append max time (in secs)
  duration = time(2:end)-time(1:(end-1));       % Convert to durations, in sec

  sequence = code';                             % Transpost to row vectors
  duration = duration';
  
  sequences = AppendRows(sequences,sequence);
  durations = AppendRows(durations,duration);

  if (length(sequence)>1)
    [transitionProbs,stderrsProbs,freqs,states] = SequenceToTransition(sequence);
    figure;
    EthogramPlot(transitionProbs,freqs,states);
  end;
  
  save BehaviorCodeData sequences durations;
  
  return;
  
% ----------------------------------------------------------------------------------

function secs = ToSecs(clockTime)
  secsPerMin = 60;
  secsPerHr = secsPerMin*60;
  secsPerDay = secsPerHr*24;

  secs = clockTime(3)*secsPerDay + clockTime(4)*secsPerHr ...
       + clockTime(5)*secsPerMin + clockTime(6);

  return;
  
  



