% KsTest1SampleDiscrete: Randomized 1-sample Kolmogorov-Smirnov test of the goodness of fit
%           of a data distribution to a discrete probability distribution.
%           The data and reference distributions are given as correspondng vectors of 
%           frequencies representing the discrete 'bins' of the distributions.
%           Calculates either an MSE-statistic (mean squared difference), or the 
%           KS-statistic (max difference between distributions).
%
%     NOTE: Must randomize null distribution by drawing samples randomly from reference distribution.
%
%     Syntax: [statHat,pValue] = KsTest1SampleDiscrete(x,xFreqs,nullFreqs,...
%                                                      {statistic},{nIters},{doPlots})
%
%         x =          [n x 1] vector of abscissa values of discrete distributions.
%         xFreqs =     [n x 1] vector of data frequencies (absolute counts), one per abscissa.
%         nullFreqs =  [n x 2] matrix of corresponding freqencies (absolute or relative) for 
%                        reference distribution.
%         statistic  = flag indicating the statistic to be calculated:
%                         0 = MSE statistic [default],
%                         1 = KS statistic.
%         nIters  =    optional number of randomization iterations; if nIters=0 [default], then 
%                        the approximate asymptotic probability is returned.
%         doPlots =    optional boolean flag indicating whether or not to plot the observed and 
%                        theoretical cumulative functions [default = false].
%         -------------------------------------------------------------------------------------
%         statHat =    observed statistic value.
%         pValue =     estimated significance level.
%

% RE Strauss, 9/26/96
%   12/12/06 - renamed from KSTest1D(); renamed some variables.

function [statHat,pValue] = KsTest1SampleDiscrete(x,xFreqs,nullFreqs,statistic,nIters,doPlots)
  if (~nargin), help KsTest1SampleDiscrete; return; end;
  
  if (nargin < 4), statistic = []; end;
  if (nargin < 5), nIters = []; end;
  if (nargin < 6), doPlots = []; end;
  
  KS = 0; 
  MSE = 1;

  x = x(:);

  if (isempty(statistic)), statistic = 0; end;       % Default input values
  if (isempty(doPlots)),   doPlots = false; end;
  if (isempty(nIters)),    nIters = 0; end;

  if (statistic < 0 | statistic > 2)
    error('  KsTest1SampleDiscrete: invalid statistic flag');
  end;

  xval = makegrps(x,xFreqs);                      % Expand freqs into observations

  dataMinMax = [min(x),max(x)];
  statHat = ks1df(x,nullFreqs,statistic,dataMinMax);   % Get observed statistic value

  if (doPlots)
    x = sort(x);                              % x = sorted data sample
    y = [0:1/(length(x)-1):1]';               % Cumulative increments

    leny = length(y);
    leny2 = 2*leny-1;
    xy = zeros(leny2,1);
    xx = xy;

    xx(1:2:leny2) = x(1:leny);                % Expand to staircase form
    xx(2:2:(leny2-1)) = x(2:leny);
    xy(1:2:leny2) = y(1:leny);
    xy(2:2:(leny2-1)) = y(1:(leny-1));

    t = nullFreqs(:,1);                       % Theor cdf
    ft = nullFreqs(:,2);                      % Increments

    lent = length(t);
    lent2 = 2*lent-1;
    xt = zeros(lent2,1);
    xFreqst = xt;

    xt(1:2:leny2) = t(1:leny);                % Expand to staircase form
    xt(2:2:(leny2-1)) = t(2:leny);
    xFreqst(1:2:leny2) = ft(1:leny);
    xFreqst(2:2:(leny2-1)) = ft(1:(leny-1));

    clf;                                      % Plot cum functions
    hold on;
    plot(xx,xy);
    plot(xt,xFreqst);
    putxlab('x');
    putylab('Cumulative relative frequency');
    hold off;
  end;

  return;
  
% -----------------------------------------------------------------------------  
  
% KS1DF: Objective function for KsTest1SampleDiscrete.
%
%     Usage: solution = ks1df(X,tdist,stat,rnge)
%
%         Xf =        [n x 1] vector of data scores.
%         tdist =     row vector representing the discrete theoretical 
%                       cumulative distribution.
%         stat =      flag indicating the statistic to be calculated:
%                         0 = KS statistic [default],
%                         1 = MSE statistic.
%         rnge =      2-element vector specifying min & max of original data.
%         ----------------------------------------------------------------------
%         solution =  test-statistic value.
%

% RE Strauss, 9/25/96

function solution = ks1df(Xf,tdist,stat,rnge)
  KS = 0; MSE = 1;

  X = sort(X);                          % X = sorted data sample
  x = [0:1/(length(X)-1):1]';           % Cumulative increments

  lenx = length(X);
  t = zeros(lenx,1);

  for i = 1:lenx
    j = max(1,max(find(tdist(:,2) <= X(i))));
    t(i) = tdist(j,1);
  end;

  diff = x - t;                         % Difference between distribs
  if (stat==KS)                           % Calc KS statistic
    solution = max(abs(diff));
  elseif (stat==MSE)                      % Calc MSE statistic
    solution = mean(diff.*diff);
  end;

  return;


  
