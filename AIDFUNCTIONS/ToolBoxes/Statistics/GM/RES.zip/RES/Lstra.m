% Lstra:  Orthogonal least-squares theta-rho analysis for the Procrustes
%         mapping of one form (form2) onto another (form1) in any number of dimensions.
%
%     Usage: [map1,map2,mapa,sse] = Lstra(form1,form2,{form2a},{doScale},{noLabels},{noPlot})
%
%         form1,form2 = [p x k] matrices of point configurations for p points and k 
%                         dimensions; form2 is mapped onto form1.
%         form2a =      optional [q x k] set of auxiliary points to be mapped along 
%                         with form2.
%         doScale =     optional boolean flag indicating that forms are be be scaled
%                         [default = true].
%         noLabels =    optional boolean flag indicating that points are not to be labeled
%                         on plot [default = false];
%         noPlot =      optional boolean flag indicating that no plots are to be 
%                         produced [default = false].
%         --------------------------------------------------------------------------------
%         map1,map2 =   [p x k] matrices of mapped point configurations, scaled and 
%                         zero-centered.
%         mapa =        [q x k] matrix of mapped auxiliary points, to same scale as map2.
%         sse =         sum of squared distances between corresponding points.
%

% Rohlf and Slice. 1990. Extensions of the Procrustes method for the optimal
%   superimposition of landmarks.  Syst. Zool. 39:40-59.

% RE Strauss, 9/1/95
%   11/24/98 - allow auxiliary set of points to be carried along with form2.
%    4/30/00 - changed default for plot.
%    6/11/03 - convert input vectors to column vectors;
%              plot only 2D points.
%    2/18/04 - added 'doScale' and 'nonlab' options.
%    8/10/05 - corrected scaling equations.
%    4/28/09 - white background on plot.

function [map1,map2,map2a,sse] = Lstra(form1,form2,form2a,doScale,noLabels,noPlot)
  if (nargin < 3), form2a = []; end;
  if (nargin < 4), doScale = []; end;
  if (nargin < 5), noLabels = []; end;
  if (nargin < 6), noPlot = []; end;
  
  if (isempty(doScale)),  doScale = true; end;       % Default flag values
  if (isempty(noLabels)), noLabels = false; end;
  if (isempty(noPlot)),   noPlot = false; end;

  if (isvect(form1)), form1 = form1(:); end;          % Convert 1D input to column vectors
  if (isvect(form2)), form2 = form2(:); end;

  [p,k] = size(form1);
  [p2,k2] = size(form2);

  if (isempty(form2a))
    isAuxilPts = false;
    q = p2;
    k2a = k2;
    map2a = [];
  else
    [q,k2a] = size(form2a);
    isAuxilPts = true;
  end;

  if (any(abs([p-p2,k-k2,k2-k2a])))    % Check conformability of forms
    error('  LSTRA: Forms must be identical in dimension and numbers of points');
  end;

  % Translate the centroids of the two forms to a common origin

  map1 = form1 - ones(p,1)*mean(form1);
  map2 = form2 - ones(p,1)*mean(form2);
  if (isAuxilPts)
    map2a = form2a - ones(q,1)*mean(form2);
  end;

  % Scale each form by the square root of the sum of the squared distances
  % from the centroid (centroid size)

  if (doScale)
    ip = eye(p) - ones(p)/p;
    s1 = sqrt(trace(ip*map1*map1'*ip));
    s2 = sqrt(trace(ip*map2*map2'*ip));
    map1 = ip*map1./s1;
    map2 = ip*map2./s2;
    if (isAuxilPts)
      iq = eye(q) - ones(q)/q;
      map2a = iq*map2a./s2;
    end;
  end;

  % Rotate the second form to achieve the best approximation to the first.
  % If 2D, iteratively optimize the sse (otherwise too many parameters).

  [U,sigma,V] = svd(map1'*map2);
  S = sign(sigma);
  H = V*S*U';

  map2 = map2*H;
  if (isAuxilPts)
    map2a = map2a*H;
  end;

  % Compute sse

  sse = trace((map1-map2)*(map1-map2)');
  
  % Plot 2D forms

  if (~noPlot && k==2)                      
    plot(map1(:,1),map1(:,2),'ro');          % Reference form
    hold on;
    plot(map2(:,1),map2(:,2),'bo');          % Mapped form
    for i = 1:size(map2,1)
      plot([map1(i,1) map2(i,1)],[map1(i,2) map2(i,2)],'k');
    end;

    xcrd = [map1(:,1) map2(:,1)];
    [maxxcrd,i] = max(xcrd'); %#ok<UDIM>

    if (~noLabels)
      textcrd = map1;
      j = find(i==2);
      textcrd(j,:) = map2(j,:);
      textcrd(:,1) = textcrd(:,1) + 0.02*range([map1(:,1);map2(:,1)]);
      for i = 1:size(map1,1)
        text(textcrd(i,1),textcrd(i,2),tostr(i));
      end;
    end;

    if (isAuxilPts)
      plot(map2a(:,1),map2a(:,2),'ko');      % Auxiliary landmarks
    end;
    
    axis(sqplot([map1;map2;map2a]));
    hold off;
    PutWhite;
  end;

  return;
