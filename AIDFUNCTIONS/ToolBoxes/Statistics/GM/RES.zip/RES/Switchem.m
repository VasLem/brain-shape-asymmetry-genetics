% SWITCHEM: Switch contents of two matrices.
%
%     [X,Y] = switchem(X,Y)
%

% RE Strauss, 11/7/00

function [Y,X] = switchem(X,Y)
  return;
