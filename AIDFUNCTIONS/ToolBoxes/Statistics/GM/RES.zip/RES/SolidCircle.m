% SolidCircle: plots a set of filled circles on an existing plot.
%
%     Usage: SolidCircle(x,y)
%

% RE Strauss, 11/4/2003

% 10/12/10 - use range of existing plot rather than range of data.

function SolidCircle(x,y)
  x = x(:);
  y = y(:);
  
  nPts = length(x);
  v = axis;
  xRange = v(2)-v(1);
  yRange = v(4)-v(3);
  
  hold on;
  for i = 1:nPts
    a = 0.013*xRange;
    b = 0.013*yRange;
    [ex,ey] = EllipseBound(0.8*a,b,x(i),y(i),0,50);
    fill(ex,ey,'k');
  end;
  hold off;

  return;
