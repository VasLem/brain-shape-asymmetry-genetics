% Dfa: Discriminant function analysis.  If the inv(W)*B matrix is singular (based on the
%         determinant of E+H), estimates the best subset of variables by stepwise DFA and
%         uses those instead.
%
%     Usage: [df,score,manovaStats,mahalStats] = Dfa(X,grps,{nDFs},{nVarsIncl},{nIters},{noPlots},...
%                                  {grpLabels},{varLabels},{grpSymbols},{plotTitle},{floatX},{ciLevel})
%
%         X -           [nObs x nVars] data matrix.
%         grps -        corresponding [nObs x 1] vector of group-membership labels for nGrps
%                         groups.
%         nDFs -        optional number of discriminant functions to be output
%                         [default = min(max(nGrps-1,2),nVars)].
%         nVarsIncl -   optional number of 'best' variables to be included in calculation of
%                         discriminant functions [default = all, if possible].
%         nIters -      optional number of bootstrap iterations [default = 0].
%         noPlots -     optional boolean variable indicating that scatterplot and vectorplot
%                         are not to be produced [default = false].
%         grpLabels -   optional character labels for groups (rows), for plotting.
%         varLabels -   optional character labels for input variables, for plotting.
%         grpSymbols -  optional character matrix of group symbols and colors (rows), for plotting.
%                         If symbols are standard Matlab linespec characters (see documentation for
%                         plot function), Matlab conventions are used; if not, symbols are printed
%                         as text characters.
%         plotTitle -   optional title for score and loading plots [default = none].
%         floatX -      optional [nFloatObs x nVars] matrix of data for observations
%                         to be 'floated' onto discriminant functions.
%         ciLevel -     optional confidence level for bootstrapped confidence intervals
%                         [default = 95].
%         -----------------------------------------------------------------------------------------
%         df - structure containing information on discriminant functions:
%                       nVarsUsed - number of variables used to calculate discriminant functions.
%                       varsUsed -  variables used to calculate discriminant functions.
%                       grpLabels - character labels for groups.
%                       varLabels - character labels for variables.
%                       loadings -  discriminant coefficients as vector correlations.
%                       percVar -   scaled eigenvalues: percent among-group variance 
%                                     accounted for.
%
%                       ciLLoadings - lower confidence bounds of loadings.
%                       ciULoadings - upper confidence bounds of loadings.
%                       ciLPercVar -  lower confidence bounds of percVar values.
%                       ciUPercVar -  upper confidence bounds of percVar values.
%
%                       ssBetween - between-group sums-of-squares matrix (B,=H).
%                       ssWithin -  within-group sums-of-squares matrix (W,=E).
%
%                       eVectors - eigenvectors of inv(W)*B matrix.
%                       eValues -  eigenvalues of inv(W)*B matrix.
%         score - structure containing scores:
%                       rawScores - unstandardized discriminant scores.
%                       scores -    corresponding standardized discriminant scores.
%                       fScores -   standardized discriminant scores for observations 
%                                     'floated' on discriminant functions.
%         manovaStats - structure containing manova statistics:
%                       lambda - observed Wilks' lambda.
%                       fStat -  estimated F-statistic value.
%                       pr -     significance level of the test, either asymptotic
%                                  (if nIters=0) or randomized (if nIters>0).
%                       dfs -    [1 x 3] vector of degrees of freedom (among-group,
%                                  within-group, total).
%                       fDfs -   [1 x 2] vector of degrees of freedom for the F test  
%                                   (numerator, denominator).
%         mahalStats - structure containing statistics on Mahalanobis statistics:
%                       dist -   [nGrps x nGrps] square symmetric distance matrix.
%                       ciDist - corresponding matrix of confidence intervals.
%                       ciProb - correpsonding matrix of significance levels.
%        

% RE Strauss, 3/6/08 to replace function discrim.m.
%   6/2/08 -   removed plots to function DfaPlots.m
%   6/3/08 -   added plots for confidence intervals.
%   8/16/08 -  CalcWB: allow for nVars<nGrps-1 in expansion of eigenvalue and eigenvector matrices;
%               reversed sequence of nDFs and nVarsIncl input variables;
%               added Manova statistics.
%   8/27/08 -  added group labels for plots.
%   8/28/08 -  added Mahalanobis statistics.
%   10/29/08 - add ability to plot symbols and colors for different groups.
%   6/18/09 -  changed reporting of manova df, as per function Manova.m.

function [df,score,manovaStats,mahalStats] = Dfa(X,grps,nDFs,nVarsIncl,nIters,noPlots,...
                                        grpLabels,varLabels,grpSymbols,plotTitle,floatX,ciLevel)
  if (~nargin), help Dfa; return; end;
  
  if (nargin< 3), nDFs = []; end;
  if (nargin< 4), nVarsIncl = []; end;
  if (nargin< 5), nIters = []; end;
  if (nargin< 6), noPlots = []; end;
  if (nargin< 7), grpLabels = []; end;
  if (nargin< 8), varLabels = []; end;
  if (nargin< 9), grpSymbols = []; end;
  if (nargin<10), plotTitle = []; end;
  if (nargin<11), floatX = []; end;
  if (nargin<12), ciLevel = []; end;
  
  if (isempty(nIters)),  nIters = 0; end;
  if (isempty(noPlots)), noPlots = false; end;
  if (isempty(ciLevel)), ciLevel = 95; end;
  
  getManova = false;
  getMahal = false;
  if (nargout>2), getManova = true; end;
  if (nargout>3), getMahal = true; end;
  
  if (ciLevel<1), ciLevel = ciLevel/100; end;
  
  grps = grps(:);
  nGrps = length(unique(grps));
  if (isvect(grpSymbols))
    grpSymbols = grpSymbols(:);
  end;
  
  [nObs,nVars] = size(X);
  if (length(grps)~=nObs)
    error('  Dfa: data matrix and grouping vector must have same number of observations.');
  end;
  if (ndims(X)>2)
    error('  Dfa: data matrix must be 2D.');
  end;
  
  if (isempty(nVarsIncl))
    if (nVars < nGrps-1)
      error('  Dfa: too few variables to support number of groups.');
    end;
  else
    if (nVarsIncl < nGrps-1)
      error('  Dfa: too few variables (nVarsIncl) to support number of groups.');
    end;    
  end;
  
  if (~isempty(varLabels))
    if (~ischar(varLabels))
      varLabels = tostr(varLabels);
    end;
    if (isvect(varLabels))
      varLabels = varLabels(:);
    end;
    if (size(varLabels,1) ~= nVars)
      error('  Dfa: number of var labels must be equal to number of input variables.');
    end;
  else
    varLabels = tostr(1:nVars);
  end;
  
  if (nVars<2)
    error('  Dfa: too few variables.');
  end;
  
  if (isempty(nDFs))
    nDFs = min([max(nGrps-1,2),nVars]);
  end;
  
  varsUsed = 1:nVars;                                
  nVarsUsed = nVars;
  vCum = [];
  vpCum = [];
  probManova = [];
  useSubset = false;
  detTolerance = 1e-8;
  
  [W,B] = CalcWB(X,grps,nDFs);
  detWB = det(W+B);
  if (detWB<detTolerance || ~isempty(nVarsIncl)) % Reduce number of variables to nonsingularity
    useSubset = true;
    [incl,vCum,vpCum] = StepDiscrim(X,grps);
    
    if (~isempty(nVarsIncl))
      nIncl = min([nVarsIncl,length(incl)]);
      incl = incl(1:nIncl);
    end;
    
    nVarsIncl = length(incl);
    [W,B] = CalcWB(X(:,incl),grps,nDFs);
    detWB = det(W+B);
    
    nv = nVarsIncl;
    while (nv>2 && detWB<detTolerance)
      nv = nv-1;
      [W,B] = CalcWB(X(:,incl(1:nv)),grps,nDFs);
      detWB = det(W+B);
    end;
    nVarsUsed = nv;
    varsUsed = incl(1:nVarsUsed); 
    
    if (nVarsUsed < nVarsIncl)
      disp('  Dfa warning: variables reduced due to singularity');
    end;

    vCum = vCum(1:nVarsUsed);
    vpCum = vpCum(1:nVarsUsed);
    probManova = StepManova(X,grps,varsUsed);
  end;
  
  if (~isempty(floatX) && useSubset)
    floatX = floatX(:,varsUsed);
  end;
  
  loadingsType = 0;
  doRescale = false;
  [loadings,percVar,scores,rawScores,fScores,W,B,eVectors,eValues] = ...
                      DfaFn(X(:,varsUsed),grps,nDFs,floatX,loadingsType,doRescale);
                    
  if (useSubset)                                      % If subset of vars has been used,
    loadings = corr(X,scores);                        %   recover loadings for all variables
  end;
  
  if (nIters>0)                                       % Bootstrapped confidence intervals
    [r,c] = size(loadings);
    dLoadings = zeros(nIters,r*c);
    dPercVar = zeros(nIters,length(percVar));
    for it = 1:nIters
      bX = bootsamp(X,grps);
      [bLoadings,bPercVar,bScores] = DfaFn(bX(:,varsUsed),grps,nDFs,[],loadingsType,doRescale);
      if (useSubset)
        bLoadings = corr(bX,bScores);
      end;
      for iDf = 1:nDFs                                 % If necessary, reverse DF direction
        if (corr(bLoadings(:,iDf),loadings(:,iDf))<0)
          bLoadings(:,iDf) = -bLoadings(:,iDf);
        end;
      end;
      dLoadings(it,:) = bLoadings(:)';
      dPercVar(it,:) = bPercVar';
    end;
    ciLoadings = BootCIBounds(dLoadings,[],[],ciLevel);
    ciPercVar = BootCIBounds(dPercVar,[],[],ciLevel);
    
    ciLLoadings = reshape(ciLoadings(1,:),r,c);
    ciULoadings = reshape(ciLoadings(2,:),r,c);
    ciLPercVar = reshape(ciPercVar(1,:),c,1);
    ciUPercVar = reshape(ciPercVar(2,:),c,1);
  else
    ciLLoadings = [];
    ciULoadings = [];
    ciLPercVar = [];
    ciUPercVar = [];
  end;
  
  df.varsUsed = varsUsed;                             % Stash variables in output structures
  df.nVarsUsed = nVarsUsed;
  df.grpLabels = grpLabels;
  df.varLabels = varLabels;
  df.loadings = loadings;                             
  df.percVar = percVar;
  df.ssBetween = B;
  df.ssWithin = W;
  df.eVectors = eVectors;
  df.eValues = eValues;
  df.ciLLoadings = ciLLoadings;
  df.ciULoadings = ciULoadings;
  df.ciLPercVar = ciLPercVar;
  df.ciUPercVar = ciUPercVar;
  
  score.scores = scores;
  score.rawScores = rawScores;
  score.fScores = fScores;

  if (getManova)                                      % Optional MANOVA
    [lambda,fStat,pr,dfs] = Manova(X(:,varsUsed),grps,nIters);
    
    manovaStats.lambda = lambda;
    manovaStats.fStat = fStat;
    manovaStats.pr = pr;
    manovaStats.dfs = dfs;
  end;
  
  if (getMahal)
    [dist,ciDist,prDist] = MahalDist(X(:,varsUsed),grps,nIters,ciLevel);
   
    mahalStats.dist = dist;
    mahalStats.ciDist = ciDist;
    mahalStats.prDist = prDist;
  end;
  
  if (~noPlots)                                       % Optional scatterplot and vector plot
    DfaPlots(df,score,grps,vCum,vpCum,probManova,plotTitle,grpSymbols);
    
    if (nDFs>2)
      vCum = [];
      DfaPlots(df,score,grps,vCum,vpCum,probManova,plotTitle,grpSymbols,[2,3]);
    end;
  end;  
                    
  return;
  
% -----------------------------------------------------------------------------------------

function [loadings,percVar,scores,rawScores,fScores,W,B,eVectors,eValues] = ...
                      DfaFn(X,grps,nDFs,floatX,loadingsType,doRescale)

  [W,B,eVectors,eValues] = CalcWB(X,grps,nDFs);            
                    
  percVar = 100*eValues/sum(eValues);             % Percents variance
  percVar = percVar(1:nDFs,1);                    % Retain subset

  [loadings,rawScores] = LoadingsScores(X,eVectors,nDFs,loadingsType,false);
  [l,scores,meanscr,wvar] = LoadingsScores(X,eVectors,nDFs,loadingsType,grps);


  fScores = [];
  if (~isempty(floatX))                           % Scores to be 'floated'
    fScores = ScoreCalc(floatX,eVectors,nDFs);
    nFloat = size(floatX,1);
    if (~doRescale)
      fScores = (fScores-ones(nFloat,1)*meanscr)./(ones(nFloat,1)*sqrt(wvar));
    end;
  end;

  for d = 1:nDFs                                  % Check if DF direction positive
    if (sum(loadings(:,d))<0)
      loadings(:,d) = -loadings(:,d);
      scores(:,d) = -scores(:,d);
      if (~isempty(fScores))
        fScores(:,d) = -fScores(:,d);
      end;
    end;
  end;

  return;
  
% -----------------------------------------------------------------------------------------

function [W,B,eVectors,eValues] = CalcWB(X,grps,nDFs)
  nObs = length(grps);

  G = design(grps);                               % ANOVA-type design matrix
  meanW = (G'*G)\G'*X;                            % Within-group means
  devsW = X-G*meanW;                              % Within-group deviations
  W = devsW'*devsW;                               % Within-group SSCP matrix

  devsT = X - ones(nObs,1)*mean(X);               % Total deviations
  T = devsT'*devsT;                               % Total SSCP matrix
  B = T - W;                                      % Among-sample SSCP matrix
  
  [eVectors,eValues] = geneigen(B,W);             % Generalized eigen analysis
  eVectors = real(eVectors);                      % If complex, convert to real
  eValues =  real(eValues);
  eValues = max([eValues'; zeros(size(eValues'))])';  % Ignore negative eigenvalues
  
  if (length(eValues)<nDFs)                       % Pad short eigen lists with zeros
    eLen = length(eValues);
    diff = nDFs-eLen;
    eValues = [eValues; zeros(diff,1)];
    eVectors = [eVectors,zeros(eLen,diff); zeros(diff,nDFs)];
  end;

  eVectors = eVectors(:,1:nDFs);                  % Save subset of eigenvectors and eigenvalues
  eValues = eValues(1:nDFs);

  return;
