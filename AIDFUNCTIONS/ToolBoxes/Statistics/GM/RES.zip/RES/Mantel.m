% Mantel: Mantel's test (Daniels 1944) for the positive association between two square 
%         symmetric distance matrices of identical size.  Diagonal values are 
%         assumed to be zeros or ones; non-zero diagonal elements are ignored.
%         Estimates post-hoc power (for simulation to estimate prior power) via a 
%         parametric bootstrap if standard errors are provided for the input distance 
%         matrices, and via nonparametric bootstrap if standard errors are not provided.
%
%     Syntax: [r,Z,pValue,power] = Mantel(x,y,{nIters},{xStdErrs},{yStdErrs})
%
%         x,y =     square symmetric matrices with zeros on the diagonal.
%         nIters =    optional number of permutation iterations [default=0].
%         xStdErrs = optional square symmetric matrix of standard errors for the 
%                     distances in x, for power estimation.
%         yStdErrs = optional standard-error matrix for y.
%         ----------------------------------------------------------------------
%         r =       correlation between matrix cells.
%         Z =       sum of cross products of matrix cells.
%         pValue =      right-tailed significance level (p-value), either 
%                     asymptotic (if nIters=0) or randomized.
%         power =   randomized estimate of post-hoc power.
%

% Daniels, HE. 1944. Biometrika 33:129-135.

% RE Strauss, 10/27/95
%   11/19/99 - error messages changed; ignore non-zero diagonal values rather 
%               than treat as error condition.
%   10/19/00 - added power estimation.
%   6/18/02 -  added reference to original work by Daniels 1944.
%   11/12/03 - added checks for NaNs.
%   4/27/10 -  forced zeros onto diagonals of x and y; miscellaneous editorial changes.
%   5/4/10 -   removed warning for diagonal elements.

function [r,Z,pValue,power] = Mantel(x,y,nIters,xStdErrs,yStdErrs)
  if (nargin < 3), nIters = []; end;
  if (nargin < 4), xStdErrs = []; end;
  if (nargin < 5), yStdErrs = []; end;

  getPower = false;
  paramBoot = false;
  power = [];

  if (nargout > 3)
    getPower = true;
  end;
  if (xor(~isempty(xStdErrs), ~isempty(yStdErrs)))
    disp( '  Mantel: if one matrix of standard errors is provided,');
    error('          both must be provided.');
  end;
  if (~isempty(xStdErrs)), paramBoot = true; end;
  if (isempty(nIters)),    nIters = 0; end;
  nItersSave = nIters;
  
  if (~isfinite(sum(sum(x))))
    error('  Mantel: X contains NaNs.');
  end;
  if (~isfinite(sum(sum(y))))
    error('  Mantel: Y contains NaNs.');
  end;

  n = size(x,1);
  if (~issqsym(x) || ~issqsym(y) || abs(sum(size(x)-size(y)))>0)
    error('  Mantel: matrices must be square, symmetric, and of same size.');
  end;
  if (getPower)
    if (paramBoot)
      if (~issqsym(xStdErrs) || ~issqsym(yStdErrs))
        error('  Mantel: matrices must be square, symmetric, and of same size.');
      end;
    end;
    if (~nIters)
      error('  Mantel: number of iterations must be provided for power estimation.');
    end;
  end;
%   if (sum(diag(x)) || sum(diag(y)))
%     disp('  Mantel warning: diagonal values ignored in test');
%   end;
  
  x = x - diag(diag(x));              % Force zeros onto diagonal
  y = y - diag(diag(y));

  % Observed test statistics

  r = corr(trilow(x),trilow(y));
  Z = sum(sum(x.*y));

  if (~nIters)                          % Asymptotic probability
    sumx = sum(x);
    Ax = sum(sumx);
    Bx = sum(sum(x.*x));
    Dx = sum(sumx.*sumx);
    Gx = Ax.*Ax;
    Hx = Dx-Bx;
    Kx = Gx + 2*Bx - 4*Dx;

    sumy = sum(y);
    Ay = sum(sumy);
    By = sum(sum(y.*y));
    Dy = sum(sumy.*sumy);
    Gy = Ay.*Ay;
    Hy = Dy-By;
    Ky = Gy + 2*By - 4*Dy;

    L = 2*Bx*By;
    O = 4*Hx*Hy/(n-2);
    P = Kx*Ky/((n-2)*(n-3));
    Q = Gx*Gy/(n*(n-1));
    R = L+O+P-Q;

    expZ = Ax*Ay/(n*(n-1));
    seZ = sqrt(R/(n*(n-1)));
    z = (Z-expZ)/seZ;
    pValue = 1-normcdf(z);
  end;

  if (nIters)                           % Randomized probability
    nperm = prod(1:n);
    if (nperm <= nIters)                % Use all possible permutations
      disp(sprintf('  Mantel: using all %d possible permutations',nperm));
      nIters = nperm; %#ok<NASGU>
      Zp = zeros(nperm,1);
      Zp(1) = Z;
      i = 1:n;

      for it = 2:nperm
        i = permnext(i);
        xp = x(i,i);
        Zp(it) = sum(sum(xp.*y));
      end;

    else                                % Use random permutations
      disp(sprintf('  Note: %d possible permutations',nperm));
      Zp = zeros(nIters,1);             % Allocate matrix for permutation 
      Zp(1) = Z;                        %   test statistic values

      for it = 2:nIters
        i = randperm(n);
        xp = x(i,i);
        Zp(it) = sum(sum(xp.*y));
      end;
    end;

    Zp = sort(Zp);
    pValue = randprob(Z,Zp);

    if (getPower)                      % Power estimation
      nIters = nItersSave;
      Zcrit = prctiles(Zp,95);            % Critical value from null distribution
      Zp = zeros(nIters,1);               % Reallocate matrix

      for it = 1:nIters                   % Randomize
        if (paramBoot)                      % Parametric bootstrap
          xb = mantelb(x,xStdErrs);         % See function below
          yb = mantelb(y,yStdErrs);
        else                                % Nonparametric bootstrap
          b = ceil(n*rand(n,1));
          xb = x(b,b);
          yb = y(b,b);
        end;
        Zp(it) = sum(sum(xb.*yb));
      end;
      power = sum(Zp >= Zcrit)/nIters;
    end;
  end;

  return;
  
% -------------------------------------------------------------------------  
  
% mantelb:  Returns a bootstrapped sample from a distance matrix based on a 
%           parametric bootstrap, given the standard errors of the distances.
%
%     Usage: Db = mantelb(D,Dstderr)
%
%           D =       square symmetric distance matrix.
%           Dstderr = corresponding matrix of standard errors.
%           --------------------------------------------------
%           Db =      bootstrapped distance matrix.
%

% RE Strauss, 10/19/00

function Db = mantelb(D,Dstderr)
  d = trilow(D);                          % Convert to col vectors
  ds = trilow(Dstderr);

  Db = trisqmat(d + randn(size(d)).*ds);  % Add noise to observed distances

  return;


