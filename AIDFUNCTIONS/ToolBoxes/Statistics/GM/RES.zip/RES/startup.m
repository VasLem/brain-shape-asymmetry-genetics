% startup.m

warning('off','MATLAB:dispatcher:InexactCaseMatch');


% Call Psychtoolbox-3 specific startup function:
if exist('PsychStartup'), PsychStartup; end;

