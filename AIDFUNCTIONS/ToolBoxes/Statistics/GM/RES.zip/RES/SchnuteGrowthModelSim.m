% SchnuteGrowthModelSim: Given params=[a,b,y1,y2] and minmaxAges=[T1,T2], a sample size N, and an error stddev,
%     generates a simulated data set with uniform-random ages.
%

function [ages,sizes] = SchnuteGrowthModelSim(params,minmaxAges,N,mseSqrt)
  [a,b,y1,y2] = ExtractCols(params);
  [T1,T2] = ExtractCols(minmaxAges);  

  ages = sort((T2-T1)*rand(N,1)+T1);
  ages(1) = T1;
  ages(end) = T2;
  t = ages;

  tol = eps;
  aIsZero = (abs(a)<tol);                             % Check for a or b effectively equal to zero
  bIsZero = (abs(b)<tol);
  
  if (~aIsZero & ~bIsZero)                            % Schnute case 1
    sizesPred = (y1^b+(y2^b-y1^b)*(1-exp(-a*(t-T1)))/(1-exp(-a*(T2-T1)))).^(1/b);
  elseif (~aIsZero & bIsZero)                         % Schnute case 2
    sizesPred = y1*exp(log(y2/y1)*(1-exp(-a*(t-T1)))/(1-exp(-a*(T2-T1))));
  elseif (aIsZero & ~bIsZero)                         % Schnute case 3
    sizesPred = (y1^b+(y2^b-y1^b)*(t-T1)/(T2-T1)).^(1/b);
  else % (aIsZero & bIsZero)                          % Schnute case 4
    sizesPred = y1*exp(log(y2/y1)*(t-T1)/(T2-T1));
  end;
  
  sizes = sizesPred + mseSqrt*randn(size(sizesPred));

  return;
  