% Triangulate: Finds the Delaunay triangulation among a set of landmarks, based on one
%         or more digitized landmark configurations, and returns a matrix of connected landmarks.
%         If >1 landmark configurations are passed, they are scaled and averaged via Procrustes
%         mapping; any configurations having missing landmarks are ignored in this mapping step.  
%         If a matrix of paired lateral landmark identifiers is passed, finds the 
%         triangulations for the two sides and applies the one having the most equilateral 
%         triangulation.  Filters any final longer distance that is almost redundant with the
%         sum of the shorter sides of the triangle
%           Returns distance specifications in the format used by function Distance().
%         
%     Usage: [distSpecs,plotCrds] = Triangulate(crds,{specimens},{distThreshold},...
%                     	{missRefPt},{ptsIgnore},{distsIgnore},{pairedPts},{averageBilat},{noPlot})
%
%         crds =          [n x 2] set of point coordinates.
%         specimens =     optional vector [length n] specifying k individuals, each represented 
%                           by the same number (np) of point coordinates (so that np x k = n).  
%                           [Default: all coordinates for a single individual].
%         distThreshold = optional min interpoint distance to be included in specifications,
%                           as proportion of maximum interpoint distance [default = 0.03].
%         missRefPt =     optional specification of index of a point (1-element vector) or the
%                           coordinates of a point (2-element vector), below which landmark 
%                           coordinates are ignored.  This point is ignored for the triangulation.
%         ptsIgnore =     optional vector of indices of point coordinates that are to be ignored
%                           (e.g., scale-bar points and pseudolandmarks) [default = null].
%         distsIgnore =   optional 2-column matrix of inter-point distances that are to be ignored
%                           in the final specifications [default = null].
%         pairedPts =     optional 2-column matrix in which rows indicate corresponding bilateral
%                           landmarks [default = null].  If null, all landmarks are singletons.
%                           If passed, any landmark not listed is assumed to be midsagittal.
%         averageBilat =	optional boolean flag indicating, if true, that lateral distances 
%                           produced by the function Distance() are to be bilaterally averaged
%                           [default = false].
%         noPlot =        optional boolean flag indicating, if true, that a plot of landmarks
%                           and connections is not to be produced [default = false].
%         ----------------------------------------------------------------------------------------
%         distSpecs =     [m x 2] matrix of distance specifications, in which each row represents
%                           two connected landmarks.
%         plotCrds =      [np x 2] mapped coordinates for plotting.
%

% RE Strauss, 8/9/05
%   9/27/05 - add capability of ignoring subset of landmarks.
%   2/8/06 -  return coordinates for plotting.
%   2/13/07 - correct error with ignoring landmarks for single specimen;
%             standardize variable names;
%             disregard any specimens having missing data;
%             reorganize into set of local functions.
%   5/31/07 - replaced 'pcacov' call with 'PcaCovar'.
%   7/15/09 - replaced Rows2Values() with Matlab unique function.

function [distSpecs,plotCrds] = Triangulate(crds,specimens,distThreshold,...
                                      missRefPt,ptsIgnore,distsIgnore,pairedPts,averageBilat,noPlot)
  if (~nargin), help TriangLandmarks; return; end;

  if (nargin < 2), specimens = []; end;
  if (nargin < 3), distThreshold = []; end;
  if (nargin < 4), missRefPt = []; end;
  if (nargin < 5), ptsIgnore = []; end;
  if (nargin < 6), distsIgnore = []; end;
  if (nargin < 7), pairedPts = []; end;
  if (nargin < 8), averageBilat = []; end;
  if (nargin < 9), noPlot = []; end;
  
  if (isempty(distThreshold)), distThreshold = 0.03; end;
  if (isempty(averageBilat)),  averageBilat = false; end;
  if (isempty(noPlot)),        noPlot = false; end;
  
  ptsIgnore = ptsIgnore(:);
  if (~isempty(distsIgnore))
    if (size(distsIgnore,2)~=2)
      error('  TriangLandmarks: invalid distsIgnore matrix.');
    end;
  end;
  
  if (isempty(specimens))                     % Provide specimen id for single configuration
    nPts = size(crds,1);
    specimens = ones(nPts,1);
  end;
  
  [u,f] = UniqueValues(specimens);
  if (var(f)>0)
    error('  TriangLandmarks: all specimens must have same number of landmarks.');
  end;
  pos = find(specimens==u(1));                % Initial number of points
  nPts = length(pos);
  ptsUsed = 1:nPts;
  
  uSpecimens = UniqueValues(specimens);       % Specimen identifiers

  % If a missing-point reference point is provided, identify missing data
  if (~isempty(missRefPt))                  
    [crds,ptsIgnore] = FindMissingData(crds,specimens,uSpecimens,missRefPt,ptsIgnore);
  end;
  
  % Delete points to be ignored
  if (~isempty(ptsIgnore))                  
    [crds,specimens,pairedPts,ptsUsed] = ...
                            DeleteIgnoredPts(crds,specimens,uSpecimens,ptsIgnore,pairedPts);
  end;  
  
  % Delete any specimens having missing points
  [crds,specimens] = DeleteSpecsMissingPts(crds,specimens,uSpecimens);  
  if (isempty(crds))
    error('  TriangLandmarks: no specimens have complete data.');
  end;
  
  % Use LSTRA to find consensus form
  crds = LstraGeneral(crds,specimens);
  
  % Triangulate
  if (isempty(pairedPts))                     % No bilateral landmarks -- single triangulation
    distSpecs = SingleTriangulation(crds);
  else                                        % Bilateral landmarks -- paired triangulations
    distSpecs = BilateralTriangulation(crds,ptsUsed,pairedPts,averageBilat);
  end;
  distSpecs = SortSpecifications(distSpecs);  % Sort specifications by landmark id
  
  % Schedule redundant distances for removal
  distsIgnore = DeleteRedundantDists(crds,distSpecs,distsIgnore,ptsUsed);
  
  % Schedule tiny distances for removal
  distsIgnore = DeleteTinyDists(distThreshold,crds,distSpecs,distsIgnore,ptsUsed);

  % Remove any ignored distances from specs
  if (~isempty(distsIgnore))              	
    distSpecs = DeleteIgnoredDistanceSpecs(distSpecs,distsIgnore,ptsUsed);
  end;
  
  % Plot points and distances
  if (~noPlot)                            	
    PlotTriangulation(crds,distSpecs,ptsUsed,averageBilat);
  end;
  
  % Recover original pt identifiers
  distSpecs = RecoverPtIds(distSpecs,ptsUsed);
  
  plotCrds = crds;
  
  return;
  
% --------------------------------------------------------------------------------------
% FindMissingData: replace missing points with NaNs

function [crds,ptsIgnore] = FindMissingData(crds,specimens,uSpecimens,missRefPt,ptsIgnore)
  nSpecimens = length(uSpecimens);
  
  if (length(missRefPt)==1)                   % Add ref pt to list of pts to ignore
    if (~ismember(missRefPt,ptsIgnore))
      ptsIgnore = [ptsIgnore; missRefPt];
    end;
    missRefPt = crds(missRefPt,:);            % Replace index of point with coordinates
  elseif (length(missRefPt)~=2)
    error('  TriangLandmarks (FindMissingData): invalid missing-data reference point.');
  end;

  for spec = 1:nSpecimens                     % Cycle thru specimens, substituting NaNs
  	i = (specimens==uSpecimens(spec));
    c = crds(i,:);
    pos = find(c(:,2)<missRefPt(2));
    if (~isempty(pos))
      c(pos,:) = NaN*ones(length(pos),2);
      crds(i,:) = c;
    end;
  end;

  return;
  
% --------------------------------------------------------------------------------------
% DeleteIgnoredPts: delete points to be ignored from all specimen configurations.

function [crds,specimens,pairedPts,ptsUsed] = ...
                            DeleteIgnoredPts(crds,specimens,uSpecimens,ptsIgnore,pairedPts)
  nSpecimens = length(uSpecimens);
  
  if (isempty(specimens))
    crds(ptsIgnore,:) = [];
  else
    newCrds = [];
    newSpecs = [];
    for spec = 1:nSpecimens
      i = find(specimens==uSpecimens(spec));
      c = crds(i,:);
      nPts = length(i);
      c(ptsIgnore,:) = [];
      s = specimens(i);
      s(ptsIgnore) = [];
      newCrds = [newCrds; c];
      newSpecs = [newSpecs; s];
    end;
    crds = newCrds;
    specimens = newSpecs;
  end;
  ptsUsed = 1:nPts;
  ptsUsed(ptsIgnore) = [];
  
  if (~isempty(pairedPts))                % Adjust paired-point list for deleted points
    for i = 1:size(pairedPts,1)
      for j = 1:2
        k = find(pairedPts(i,j)==ptsUsed);
        if (isempty(k))                     % Delete if paired-pt id is not in list of points used
          pairedPts(i,j) = NaN;
        else                                % Else convert paired-pt id to actual coordinate identifier
          pairedPts(i,j) = k;
        end;
      end;
    end;
    i = isfinite(sum(pairedPts,2));
    pairedPts = pairedPts(i,:);
  end;

  return;

% --------------------------------------------------------------------------------------
% DeleteSpecsMissingPts: delete any specimens having missing points.

function [crds,specimens] = DeleteSpecsMissingPts(crds,specimens,uSpecimens)
  newCrds = [];
  newSpecs = [];
  nSpecimens = length(uSpecimens);
  for spec = 1:nSpecimens                       
    i = find(specimens==uSpecimens(spec)); 
    rc = Rowsum(crds(i,:));
    if (all(isfinite(rc)))
      newCrds = [newCrds; crds(i,:)];
      newSpecs = [newSpecs; specimens(i)];
    end;
  end;
  crds = newCrds;
  specimens = newSpecs;

  return;

% --------------------------------------------------------------------------------------
% SingleTriangulation: single triangulation for unpaired landmarks.

function distSpecs = SingleTriangulation(crds)
  tri = delaunay(crds(:,1),crds(:,2));        % Delaunay triangulation
  dist = [tri(:,1:2); tri(:,2:3); tri(:,[1,3])];  % Isolate pairs of connected landmarks
  dist = sort(dist,2);                        % Sort landmark pairs
%   r = Rows2Values(dist);                      % Find unique landmark pairs
%   [u,f,i] = UniqueValues(r);
  distSpecs = unique(dist,'rows');
%   distSpecs = dist(i,:);

  return;
      
% --------------------------------------------------------------------------------------
% BilateralTriangulation: triangulations for paired+midsagital landmarks.

function distSpecs = BilateralTriangulation(crds,ptsUsed,pairedPts,averageBilat)
  nPts = length(ptsUsed);

  midsag = ones(nPts,1);                      % Identify midsagittal and lateral landmarks
  right = zeros(nPts,1);
  left = zeros(nPts,1);
  np = size(pairedPts,1);
  left(pairedPts(:,1)) = ones(np,1);
  right(pairedPts(:,2)) = ones(np,1);
  left = find(left);
  right = find(right);
  midsag(left) = zeros(np,1);
  midsag(right) = zeros(np,1);
  midsag = find(midsag);
    
  eucldist = eucl(crds);                    	% Euclidean distances among landmarks
    
  i = [midsag; left];                         % Isolate mid and left landmarks
  tri1 = delaunay(crds(i,1),crds(i,2));       % Delaunay triangulation
  tri1 = replace(tri1,1:length(i),i);         % Recover landmark identities
  dist = [tri1(:,1:2); tri1(:,2:3); tri1(:,[1,3])];  % Isolate pairs of connected landmarks
  dist = sort(dist,2);                        % Sort landmark pairs
  distSpecs1 = unique(dist,'rows');           % Find unique landmark pairs

  i = [midsag; right];                        % Isolate mid and left landmarks
  tri2 = delaunay(crds(i,1),crds(i,2));       % Delaunay triangulation
  tri2 = replace(tri2,1:length(i),i);         % Recover landmark identities
  dist = [tri2(:,1:2); tri2(:,2:3); tri2(:,[1,3])];  % Isolate pairs of connected landmarks
  dist = sort(dist,2);                        % Sort landmark pairs
  distSpecs2 = unique(dist,'rows');           % Find unique landmark pairs

  % Choose side having best triangulation
  eq1 = Equilaterality(eucldist,tri1);        % Measures of total equilaterality of triangulations
  eq2 = Equilaterality(eucldist,tri2); 
    
  if (eq1 > eq2)                                
    distSpecs2 = replace(distSpecs1,pairedPts(:,1),pairedPts(:,2));
  else
    distSpecs1 = replace(distSpecs2,pairedPts(:,2),pairedPts(:,1));
  end;
    
  % Concatenate triagulations for two sides
  if (averageBilat)                             
    dist = [distSpecs1, zeros(size(distSpecs1,1),1), distSpecs2];
  else
    dist = [distSpecs1; distSpecs2];      
  end;
    
  % Append cross-distances between pairs of lateral landmarks
  [dist,pairedPts] = PadCols(dist,pairedPts,0);             % If necessary, pad 'pairedPts' for concatenation
  dist = [dist; pairedPts];
    
  % Remove redundant distances among midsagittal landmarks
  if (~isempty(midsag))
    i = (isin(dist(:,1),midsag) & isin(dist(:,2),midsag));  % Find distances involving only midsag
    dist(i,:) = [];                                         % Remove from distance matrix
    if (length(midsag)>2)
      x = crds(midsag,:);                                   % Replace with consecutive pairs
      evects = eigen(cov(x));    
      [loadings,scores] = loadscrs(x,evects,1);
    else
      scores = 1:length(midsag);
    end;
    [scores,midsag] = sortmat(scores,midsag);
    if (corr(midsag,1:length(midsag)) < 0)
      midsag = flipud(midsag);
    end;
    for i = 1:(length(midsag)-1)
      m = [midsag(i),midsag(i+1)];
      [dist,m] = PadCols(dist,m,0);
      dist = [dist; m];
    end;
  end;
  distSpecs = dist;

  return;
  
% --------------------------------------------------------------------------------------
% Equaliterality: measure of triangle equilaterality for triangulation.

function eq = Equilaterality(eucldist,tri)
  n = size(tri,1);
  d = zeros(3,n);
  for i = 1:n
    d(1,i) = eucldist(tri(i,1),tri(i,2));
    d(2,i) = eucldist(tri(i,1),tri(i,3));
    d(3,i) = eucldist(tri(i,2),tri(i,3));
  end;
  
  eq = 1/sqrt(sum(var(d)));     % Variance among side lengths is measure of inequality
  
  return;
  
% --------------------------------------------------------------------------------------
% DeleteRedundantDists: for each triangle, delete long sides that are nearly the
%   sum of the shorter sides.

function distsIgnore = DeleteRedundantDists(crds,distSpecs,distsIgnore,ptsUsed)
  [nSpecs,lenSpecRow] = size(distSpecs);

  pairwiseDistSpecs = distSpecs;
  if (lenSpecRow>2)
    pairwiseDistSpecs = [distSpecs(:,1:2); distSpecs(:,4:5)];
    pos = (sum(pairwiseDistSpecs,2)>0);
    pairwiseDistSpecs = pairwiseDistSpecs(pos,:);
  end;

  triangles = [];

  for iSpec = 1:size(pairwiseDistSpecs,1)     % Cycle thru rows of specifications
    curPair = pairwiseDistSpecs(iSpec,:);       % Current point pair
    [r,c] = find(curPair(1)==distSpecs); %#ok<NASGU> % Find occurrences of 1st pt in specifications
    nOccur = length(r);
    if (nOccur>0)
      s = distSpecs(r,:);
      s = s(:);
      pos = (s>0 & s~=curPair(1) & s~=curPair(2));
      list1 = unique(s(pos));                     % List of pts linked to 1st pt
    end;
    [r,c] = find(curPair(2)==distSpecs); %#ok<NASGU> % Find occurrences of 2nd pt in specifications
    nOccur = length(r);
    if (nOccur>0)
      s = distSpecs(r,:);
      s = s(:);
      pos = (s>0 & s~=curPair(1) & s~=curPair(2));
      list2 = unique(s(pos));                     % List of pts linked to 2nd pt
    end;
    
    if (~isempty(list1) && ~isempty(list2))       % Add pts in common to list of triangles
      b = ismember(list1,list2);
      for ib = 1:length(b)
        if (b(ib))
          triangles = [triangles; sort([curPair, list1(ib)])];
        end;
      end;
    end;
  end;
  
  base = max(max(triangles));
  rowValues = triangles(:,1)*base^3 + triangles(:,2)*base^2 + triangles(:,3)*base;
  uValues = unique(rowValues);
  [b,pos] = isin(uValues,rowValues);
  triangles = triangles(sort(pos),:);             % List of all possible triangles
  nTriangles = size(triangles,1);
  
  threshold = 0.97;                               % Threshold for deletion: length(max edge)/sum(other 2 edges)
  
  for iTri = 1:nTriangles                         % Cycle thru triangles
    d = trilow(eucl(crds(triangles(iTri,:),:)));    % Get 3 pairwise distances
    dMax = max(d);
    deleteEdge = false;
    if (d(1)==dMax)                                 % d12 is largest
      if (dMax/sum(d(2:3)) > threshold)
        deleteEdge = true;
        deletePtPair = [1,2];
      end;
    elseif (d(2)==dMax)                             % d13 is largest
      if (dMax/sum(d([1,3])) > threshold)
        deleteEdge = true;
        deletePtPair = [1,3];
      end;
    else                                            % d23 is largest
      if (dMax/sum(d(1:2)) > threshold)
        deleteEdge = true;
        deletePtPair = [2,3];
      end;
    end;
    
    if (deleteEdge)                               % If edge is to be deleted,
      ptPair = triangles(iTri,deletePtPair);          % Get identities of point pair
      distsIgnore = [distsIgnore; ptsUsed(ptPair)];   % Translate pt ids, add to deletion list
    end;
  end;

  return;

% --------------------------------------------------------------------------------------
% DeleteTinyDists: schedule tiny distances for removal

function distsIgnore = DeleteTinyDists(threshold,crds,distSpecs,distsIgnore,ptsUsed)
  [nSpecs,lenSpecRow] = size(distSpecs);

  pairwiseDistSpecs = distSpecs;
  if (lenSpecRow>2)
    pairwiseDistSpecs = [distSpecs(:,1:2); distSpecs(:,4:5)];
    pos = (sum(pairwiseDistSpecs,2)>0);
    pairwiseDistSpecs = pairwiseDistSpecs(pos,:);
  end;

  pairwiseDists = eucl(crds);               % Matrix of pairwise interpoint distances
  maxDist = max(max(pairwiseDists));        % Max interpoint distance
  
  for iSpec = 1:size(pairwiseDistSpecs,1)
  	curPair = pairwiseDistSpecs(iSpec,:);       % Current point pair
    if (pairwiseDists(curPair(1),curPair(2)) < threshold*maxDist) % If distance is tiny,
    	distsIgnore = [distsIgnore; ptsUsed(curPair)];  % Translate pt ids, add to deletion list
    end;
  end;

  return;
  
% --------------------------------------------------------------------------------------
% DeleteIgnoredDistanceSpecs: delete ingored distance specifications.

function distSpecs = DeleteIgnoredDistanceSpecs(distSpecs,distsIgnore,ptsUsed)
  distsIgnore = sort(distsIgnore,2);          % Sort pairs of point identifiers within rows
  [distSpecsRows,distSpecsCols] = size(distSpecs);
  useSpec = true(distSpecsRows,1);
    
  for iSpec = 1:distSpecsRows                 % Check each row of distance specs against list
    specPts = ptsUsed(distSpecs(iSpec,1:2));
    isInSpec = (isin(distsIgnore(:,1),specPts) & isin(distsIgnore(:,2),specPts));
      
    if (~any(isInSpec) && distSpecsCols>2 && sum(distSpecs(iSpec,4:5))>0)
    	specPts = ptsUsed(distSpecs(iSpec,4:5));
      isInSpec = (isin(distsIgnore(:,1),specPts) & isin(distsIgnore(:,2),specPts));
    end;
      
    if (any(isInSpec))                       % If not in list, keep the distance spec
      useSpec(iSpec) = false;
    end;
  end;
  distSpecs = distSpecs(useSpec,:);

  return;

% --------------------------------------------------------------------------------------
% SortSpecifications: sort specifications by landmark.

function distSpecs = SortSpecifications(distSpecs)
  [d,distSpecs] = sortmat(distSpecs(:,2),distSpecs);  
  [d,distSpecs] = sortmat(distSpecs(:,1),distSpecs);

  return;
  
% ---------------------------------------------------------------------------------------
% PlotTriangulation: plot points and distances, first labeling points and then distances.

function PlotTriangulation(crds,distSpecs,ptsUsed,averageBilat)
  x = crds(:,1);
  y = crds(:,2);
  fontSize = 10;
  
  figure;                                 % Plot with landmarks numbered
  deltaX = 0.011 * range(x);
  plot(x,y,'k.');
  hold on;
  for i = 1:length(x)
    h = text(x(i)+deltaX,y(i),int2str(ptsUsed(i)));
    set(h,'fontsize',fontSize);
  end;
  hold off;
  putbnd([x,y],0.06);
    
  axis equal;
  hold on;
  for i = 1:size(distSpecs,1);
    d = distSpecs(i,1:2);
    plot(crds(d,1),crds(d,2),'k');
  end;
  if (averageBilat)
    for i = 1:size(distSpecs,1);
      d = distSpecs(i,4:5);
      if (sum(d)>0)
        plot(crds(d,1),crds(d,2),'k');
      end;
    end;
  end;
  hold off;
  axis off;
  drawnow;

  figure;                                 % Plot with distances numbered
  plot(x,y,'k.');
  putbnd([x,y],0.06);
  axis equal;
  hold on;
  for i = 1:size(distSpecs,1);
    d = distSpecs(i,1:2);
    LineLabel(crds(d(1),:),crds(d(2),:),int2str(i),[],[],fontSize);
  end;
  if (averageBilat)
    for i = 1:size(distSpecs,1);
      d = distSpecs(i,4:5);
      if (sum(d)>0)
        plot(crds(d,1),crds(d,2),'k');
      end;
    end;
  end;
  hold off;
  axis off;
  drawnow;

  return;
  
% --------------------------------------------------------------------------------------
% Recover original pt identifiers

function distSpecs = RecoverPtIds(distSpecs,ptsUsed)
  [r,c] = size(distSpecs);
  for i = 1:r
    for j = 1:c
      if (distSpecs(i,j)>0)
        d = distSpecs(i,j);
        distSpecs(i,j) = ptsUsed(d);
      end;
    end;
  end;
  
  return;
  

