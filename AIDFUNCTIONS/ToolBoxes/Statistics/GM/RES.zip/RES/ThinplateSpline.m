% ThinplateSpline: Thin-plate splines and principal warps.  Produces plots of grids, spline mesh,
%            affine dilatations, and Procrustes superimpositions.
%
%     Usage: [warp,eval,evec,D,theta1,theta2,LV,T2,auxTargPts] = ...
%                   ThinplateSpline(base,targ,{auxBasePts},{keepScale},{gridSize},{trimGrids},{noPlots})
%
%         base =       [n x 2] matrix of base points.
%         targ =       [n x 2] matrix of correponding target points.
%         auxBasePts = [m x 2] matrix of auxialary points to be mapped ('floated').
%         keepScale =  optional boolean flag indicating whether or not 
%                        to maintain original scaling of base and target point 
%                        configurations on grid displays [default=false].
%         gridSize =   optional number of points along edge of square grid for display
%                        [default=30].
%         trimGrids =  optional boolean flag indicating that base and target grids are
%                       to be trimmed within the convex hulls of the landmarks
%                        [default = false].
%         noPlots =    optional boolean flag indicating that no plots are to be produced
%                        [default = false].
%         ---------------------------------------------------------------------------
%         warp =       [n x n] matrix of bending energy as a function of changes
%                        in the target coordinates.
%         eval =       [k x 1] vector of k<n nonzero eigenvalues of warp.
%         evec =       [n x k] matrix of corresponding eigenvectors (columns).
%         D =          principal dilatations of affine transformation.
%         theta1 =     directions (degrees counterclockwise) of principal dilatations.
%         theta2 =     final rotation (degrees counterclockwise) of affine 
%                        transformation.
%         LV -         transformation map: L-inverse * V.
%         T2 -         net rotation matrix.
%         auxTargPts - mapped coordinates of auxiliary points.
%

% RE Strauss, 8/20/98, based on Bookstein 1989.
%   8/20/99 - changed plot colors for Matlab v5.
%   1/4/00 -  changed usage of sqplot().
%   4/6/02 -  changed ellips() to ellipsebound();
%             addd error message for forms with different numbers of landmarks;
%             renamed from thinplat() to Thinplate();
%             addd 'trimGrids' option.
%   4/28/09 - added spline mesh plots.
%   5/6/09 -  set axis('equal') for all plots.
%   7/22/09 - added no-plot option.
%   7/27/09 - added LV and T2 to output argument list.
%   5/14/10 - added ability to float auxiliary points onto deformation;
%             renamed from Thinplate() to ThinplateSpline().
%   5/21/10 - initially map base points onto target.

% Bookstein, F.L.  1989.  Principal warps: thin-plate splines and the
%   decomposition of deformations.  IEEE Trans. Patt. Anal. Mach. Intell.
%   11:567-585.

function [warp,eval,evec,D,theta1,theta2,LV,T2,auxTargPts] = ...
                  ThinplateSpline(base,targ,auxBasePts,keepScale,gridSize,trimGrids,noPlots)
  if (nargin < 3), auxBasePts = []; end;
  if (nargin < 4), keepScale = []; end;
  if (nargin < 5), gridSize = [];  end;
  if (nargin < 6), trimGrids = []; end;
  if (nargin < 7), noPlots = []; end;

  if (isempty(keepScale)), keepScale = false; end;
  if (isempty(trimGrids)), trimGrids = false; end;
  if (isempty(gridSize)),  gridSize = 30; end;
  if (isempty(noPlots)),   noPlots = false; end;
  
  isAuxPts = true;
  if (isempty(auxBasePts)), isAuxPts = false; end;
  
  steps = gridSize-1;

  nBase = size(base,1);
  nTarg = size(targ,1);
  if (nTarg ~= nBase)
    error('  ThinplateSpline: base and target forms must have same number of landmarks.');
  end;

  targCentroid = mean(targ);                % Center base & target points and map base onto target
  [targ,base,auxBasePts] = Lstra(targ,base,auxBasePts,~keepScale,true,true);
  targ = targ + ones(nTarg,1)*targCentroid; % Restore target centroid

  x = (base(:,1)*ones(1,nBase) - ones(nBase,1)*base(:,1)').^2;
  y = (base(:,2)*ones(1,nBase) - ones(nBase,1)*base(:,2)').^2;
  r = sqrt(x+y);                            % U function evaluation
  r2 = r.^2;
  logr2 = log(r2 + eye(nBase));

  K = r2 .* logr2;                          % Construct L matrix
  P = [ones(nBase,1) base];
  L = [K P; P' zeros(3,3)];

  Linv = inv(L);                            % Warp matrix
  Lred = Linv(1:nBase,1:nBase);
  warp = Lred * K * Lred;

  LV = Linv * [targ; zeros(3,2)];           % Transformation map
  A = LV((nBase+2):(nBase+3),:)';           % Linear terms
  [U,S,V] = svd(A);                         % Decomposition
  D = diag(S);                              % Affine dilatations
  theta1 = zeros(2,1);                      % Orientations of dilatations
  theta1(1) = -asin(V(1,2));
  theta1(2) = theta1(1)+pi/2;
  t = theta1(1);
  T1 = [cos(t) sin(t);-sin(t) cos(t)];      % Orientation matrix
  theta2 = asin(U(1,2))+t;                  % Net affine rotation
  t = -theta2;
  T2 = [cos(t) sin(t);-sin(t) cos(t)];      % Net rotation matrix

  [evec,eval] = eigen(warp);                % Eigenanalysis of warp matrix
  i = find(eval>eps);
  eval = eval(i);
  evec = evec(:,i);

  bounds = sqplot(base,[],1);               % Make rectangular grid of points
  xmin = bounds(1);
  xmax = bounds(2);
  ymin = bounds(3);
  lenStep = (xmax-xmin)/steps;
  m1 = meshgrid(0:steps,0:steps);
  m2 = m1';
  intgrid = [m1(:) m2(:)];
  baseGrid = [intgrid(:,1)*lenStep+xmin, intgrid(:,2)*lenStep+ymin];

  targGrid = zeros(size(baseGrid));        	% Non-affine transformation mapping
  for i=1:size(baseGrid,1)
    U = ((base-ones(nBase,1)*baseGrid(i,:)).^2)*[1; 1];
    U = U .* log(U+(U==0));
    U = [U; 1; baseGrid(i,:)']';
    targGrid(i,:) = U*LV;
  end;
  targGrid = targGrid * T2;                 % Affine rotation for display
  targ = targ * T2;
  
  auxTargPts = zeros(size(auxBasePts));    	% Float auxiliary points
  if (isAuxPts)
    for i=1:size(auxBasePts,1)
      U = ((base-ones(nBase,1)*auxBasePts(i,:)).^2)*[1; 1];
      U = U .* log(U+(U==0));
      U = [U; 1; auxBasePts(i,:)']';
      auxTargPts(i,:) = U*LV;
    end;
    auxTargPts = auxTargPts * T2; 
  end;

  noProcustesPlot = true;
  [map2,map1] = Lstra(targ,base,[],[],[],noProcustesPlot); % Procrustes mapping for figures

  if (keepScale)
    xmin = min(min([baseGrid(:,1) targGrid(:,1)]));
    xmax = max(max([baseGrid(:,1) targGrid(:,1)]));
    ymin = min(min([baseGrid(:,2) targGrid(:,2)]));
    ymax = max(max([baseGrid(:,2) targGrid(:,2)]));
  end;
  
  if (trimGrids)
    isin = isinpoly(baseGrid,hull(base));
    plotBaseGrid = baseGrid(isin==true,:);
    targHull = hull(targ);
    isin = isinpoly(targGrid,targHull);
    plotTargGrid = targGrid(isin==true,:);
    isinTarg = isin;
  else
    plotBaseGrid = baseGrid;
    plotTargGrid = targGrid;
    targHull = hull(targ);
    isinTarg = isinpoly(targGrid,hull(targ));
  end;

  tg(:,:,1) = reshape(targGrid(:,1),gridSize,gridSize);   % Reform matrices to plot spline
  tg(:,:,2) = reshape(targGrid(:,2),gridSize,gridSize);
  targGrid= tg;
  isinTarg = reshape(isinTarg,gridSize,gridSize);
  
% Fig 1, base form + grid  

  if (~noPlots)
    figure;
    hold on;
  %   title('Base');
    plot(plotBaseGrid(:,1),plotBaseGrid(:,2),'b.');
    plot(base(:,1),base(:,2),'k*',base(:,1),base(:,2),'ko');
    if (isAuxPts)
      plot(auxBasePts(:,1),auxBasePts(:,2),'rx',auxBasePts(:,1),auxBasePts(:,2),'ro');
    end;
    if (keepScale)
      axis([xmin xmax ymin ymax]);
    else
      axis([min(plotBaseGrid(:,1)) max(plotBaseGrid(:,1)) min(plotBaseGrid(:,2)) max(plotBaseGrid(:,2))]);
    end;
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 2, target form + grid

  if (~noPlots)
    figure;
    hold on;
  %   title('Target');
    plot(plotTargGrid(:,1),plotTargGrid(:,2),'b.');
    plot(targ(:,1),targ(:,2),'k*',targ(:,1),targ(:,2),'ko',targ(:,1),targ(:,2),'ko');
    if (isAuxPts)
      plot(auxTargPts(:,1),auxTargPts(:,2),'rx',auxTargPts(:,1),auxTargPts(:,2),'ro');
    end;
    if (keepScale)
      axis([xmin xmax ymin ymax]);
    else
      axis([min(plotTargGrid(:,1)) max(plotTargGrid(:,1)) min(plotTargGrid(:,2)) max(plotTargGrid(:,2))]);
    end;
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 3, spline  

  if (~noPlots)
    figure;
    hold on;
    plot(targHull(:,1),targHull(:,2),'k');
    for r = 1:gridSize
      for c = 1:(gridSize-1)
        if (isinTarg(r,c) && isinTarg(r,c+1))
          plot(targGrid(r,[c,c+1],1),targGrid(r,[c,c+1],2),'k');
        elseif (isinTarg(r,c) || isinTarg(r,c+1))
          [doIntersect,x,y] = Intrsect(targHull,[targGrid(r,c,1),targGrid(r,c,2),targGrid(r,c+1,1),targGrid(r,c+1,2)]);
          x = x(doIntersect);
          y = y(doIntersect);
          if (isinTarg(r,c))
            plot([targGrid(r,c,1),x],[targGrid(r,c,2),y],'k');
          else
            plot([x,targGrid(r,c+1,1)],[y,targGrid(r,c+1,2)],'k');
          end;
        end;
      end;
    end;
    for c = 1:gridSize
      for r = 1:(gridSize-1)
        if (isinTarg(r,c) && isinTarg(r+1,c))
          plot(targGrid([r,r+1],c,1),targGrid([r,r+1],c,2),'k');
        elseif (isinTarg(r,c) || isinTarg(r+1,c))
          [doIntersect,x,y] = Intrsect(targHull,[targGrid(r,c,1),targGrid(r,c,2),targGrid(r+1,c,1),targGrid(r+1,c,2)]);
          x = x(doIntersect);
          y = y(doIntersect);
          if (isinTarg(r,c))
            plot([targGrid(r,c,1),x],[targGrid(r,c,2),y],'k');
          else
            plot([x,targGrid(r+1,c,1)],[y,targGrid(r+1,c,2)],'k');
          end;
        end;
      end;
    end;
    putBnds(targHull);
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 4, spline + landmarks

  if (~noPlots)
    figure;
    hold on;
    plot(targ(:,1),targ(:,2),'ko',targHull(:,1),targHull(:,2),'k');
    for r = 1:gridSize
      for c = 1:(gridSize-1)
        if (isinTarg(r,c) && isinTarg(r,c+1))
          plot(targGrid(r,[c,c+1],1),targGrid(r,[c,c+1],2),'k');
        elseif (isinTarg(r,c) || isinTarg(r,c+1))
          [doIntersect,x,y] = Intrsect(targHull,[targGrid(r,c,1),targGrid(r,c,2),targGrid(r,c+1,1),targGrid(r,c+1,2)]);
          x = x(doIntersect);
          y = y(doIntersect);
          if (isinTarg(r,c))
            plot([targGrid(r,c,1),x],[targGrid(r,c,2),y],'k');
          else
            plot([x,targGrid(r,c+1,1)],[y,targGrid(r,c+1,2)],'k');
          end;
        end;
      end;
    end;
    for c = 1:gridSize
      for r = 1:(gridSize-1)
        if (isinTarg(r,c) && isinTarg(r+1,c))
          plot(targGrid([r,r+1],c,1),targGrid([r,r+1],c,2),'k');
        elseif (isinTarg(r,c) || isinTarg(r+1,c))
          [doIntersect,x,y] = Intrsect(targHull,[targGrid(r,c,1),targGrid(r,c,2),targGrid(r+1,c,1),targGrid(r+1,c,2)]);
          x = x(doIntersect);
          y = y(doIntersect);
          if (isinTarg(r,c))
            plot([targGrid(r,c,1),x],[targGrid(r,c,2),y],'k');
          else
            plot([x,targGrid(r+1,c,1)],[y,targGrid(r+1,c,2)],'k');
          end;
        end;
      end;
    end;
    putBnds(targHull);
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 5, affine dilatations  

  if (~noPlots)
    figure;
    hold on;
  %   title('Affine dilatations');
    a = D(1)/2;                               % Half-dilatations
    b = D(2)/2;
    t = theta1(1);                            % Orientation of major dilatation
    [x,y] = ellipsebound(a,b,0,0,t);          % Locus of ellipse
    plot(x,y,'k');                            % Plot ellipse
    ma = [-a 0;a 0]*T1;                       % Plot major axis
    plot(ma(:,1),ma(:,2),'k');
    ma = [0 -b;0 b]*T1;                       % Plot minor axis
    plot(ma(:,1),ma(:,2),'k');
    bounds = sqplot(x,y,40);
    axis(bounds);
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 6, Procrustes mapping as superimposed landmarks

  if (~noPlots)
    figure;
    hold on;
  %   title('Procrustes mapping');
    plot(map1(:,1),map1(:,2),'k*',map1(:,1),map1(:,2),'ko'); 	% Plot base coordinates
    plot(map2(:,1),map2(:,2),'ko');                           % Plot superimposed target coordinates
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;
  
% Fig 7, Procrustes mapping as displacement vectors  

  if (~noPlots)
    figure;
    hold on;
  %   title('Procrustes mapping');
    for i = 1:size(map1,1)
      plot(map1(i,1),map1(i,2),'k.');                         % Plot base coordinates
      plot([map1(i,1),map2(i,1)],[map1(i,2),map2(i,2)],'k');  % Plot line to superimposed target coordinates
    end;
    axis('equal');
    axis('off');
    PutWhite;
    hold off;
  end;

  theta1(1) = theta1(1)*360/(2*pi);         % Convert angles to degrees
  theta1(2) = theta1(1)+90;
  theta2 = theta2*360/(2*pi);

  return;
