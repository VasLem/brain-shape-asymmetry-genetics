% LineSegShift: orthogonally shifts a line segment (specified by two endpoints) to the left 
%         (positive direction) or right (negative direction) by distance D, given a line segment 
%         parallel to the initial line by D units from it.
%
%     Usage: [newPt1,newPt2] = LineSegShift(pt1,pt2,shiftDist)
%
%         pt1,pts = 2-element vectors specifying the endpoints of the line segment.
%         shiftDist = distance to be shifted left or right (with respect to vector pt1-pt2).
%

% RE Strauss, 2/15/07

function [newPt1,newPt2] = LineSegShift(pt1,pt2,shiftDist)
  if (~nargin), help LineSegShift; return; end;
  
  if (length(pt1)~=2 || length(pt2)~=2)
    error('  LineSegShift: invalid endpoints.');
  end;
  if (~isscalar(shiftDist))
    error('  LineSegShift: shift distance must be a scalar.');
  end;
  
  [regRotPts,theta] = RegisterRotate(1,2,[pt1;pt2]);
  regRotPts = [regRotPts; regRotPts];
  regRotPts(3:4,2) = regRotPts(1:2,2) + shiftDist;
  newPts = Rotate(regRotPts,-theta,regRotPts(1,:));
  newPts = newPts + ones(4,1)*pt1;
  
  newPt1 = newPts(3,:);
  newPt2 = newPts(4,:);
  
  return;
  