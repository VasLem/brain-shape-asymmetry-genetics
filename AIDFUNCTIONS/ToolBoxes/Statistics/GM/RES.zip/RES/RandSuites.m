% RandSuites: Generate data matrix for one or more groups, allowing for character 
%           suites and multiple groups.  By default, groups differ only in character means,
%           not variances.  For multiple groups, correlations are sampled within-group.
%
%     Usage: [X,suites,groups] = RandSuites(nObsPerGrp,nVarsPerSuite,...
%                                     {charMeans},{charVars},{wCorr},{bCorr},{exactCorrs})
%
%         nObsPerGrp =    vector of numbers of observations per group; 
%                           length = number of groups, sum = total sample size (N).
%         nVarsPerSuite =	vector of numbers of characters per suite; length = 
%                           number of suites (S), sum = number of characters (P).
%         charMeans =     [N x P] matrix of character means for each group
%                            [default = 10 for all chars of first group, 12 for 
%                           second group, etc.].
%         charVars =      vector (length P) of character variances; if charVars is a scalar, 
%                           it is used for all characters and all groups [default = 1].
%         wCorr =         within-suite correlation (constant for all suites) 
%                           [default = 0.85].
%         bCorr =         among-suite correlation (constant for all pairs of suites) 
%                           [default = 0.65].
%         exactCorrs =    optional boolean flag indicating, if true, that correlations 
%                           among variables are exact rather than sampled with error 
%                           [default = false: sampled correlations].
%         ----------------------------------------------------------------------------------
%         X =             [N x P] data matrix.
%         suites =        grouping vector (1 x P) for S character suites.
%         groups =        grouping vector (N x 1) for K groups of observations.
%

% RE Strauss, 10/5/99
%   12/12/99 - added capability for multiple groups.
%   10/5/00 -  fixed problem with propagating scalar charVars.
%   4/19/04 -  added error message for correlation out of range.
%   6/26/07 -  set initial rand seed via clock.
%   7/6/07 -   updated variable names; renamed from randsuit.m.
%   11/3/07 -  corrected problem with 'exactCorrs'.

function [X,suites,groups] = RandSuites(nObsPerGrp,nVarsPerSuite,charMeans,charVars,wCorr,bCorr,exactCorrs)
  if (nargin < 3), charMeans = []; end;
  if (nargin < 4), charVars = []; end;
  if (nargin < 5), wCorr = []; end;
  if (nargin < 6), bCorr = []; end;
  if (nargin < 7), exactCorrs = []; end;

  if (isempty(wCorr)),    	wCorr = 0.85; end;
  if (isempty(bCorr)),    	bCorr = 0.65; end;
  if (isempty(exactCorrs)), exactCorrs = false; end;
  
  rand('state',sum(100*clock));         % Reset seed

  if (min(size(nObsPerGrp))>1 || min(size(nVarsPerSuite))>1)
    error('  RandSuites: nObsPerGrp and nVarsPerSuite must be vectors.');
  end;
  if (wCorr<0 || wCorr>1 || bCorr<0 || wCorr>1)
    error('  RandSuites: correlation out of range.');
  end;

  grps =    nObsPerGrp;
  nObs =    sum(nObsPerGrp);
  nGrps =   length(nObsPerGrp);

  vars =    nVarsPerSuite;
  nVars =   sum(nVarsPerSuite);
  nSuites = length(nVarsPerSuite);
  
  if (isempty(charMeans))
    charMeans = zeros(nGrps,nVars);
    initCharMeans = 10;
    deltaCharMeans = 2;
    for i = 1:nGrps
      charMeans(i,:) = initCharMeans*ones(1,nVars);
      initCharMeans = initCharMeans + deltaCharMeans;
    end;
  end;
  if (~isequal(size(charMeans),[nGrps,nVars]))
    error('  RandSuites: charMeans and input vectors incompatible');
  end;

  if (isscalar(charVars))
    charVars = charVars * ones(nGrps,nVars);
  end;
  if (isempty(charVars))
    charVars = ones(nGrps,nVars);
  end;

  if (~exactCorrs && nObs<=nVars)
    error('  RandSuites: number of observations be greater than number of variables.');
  end;
  if (exactCorrs && min(nObsPerGrp)<=nVars)
    disp('  RandSuites: for exact covariances, min observations per group must be greater than');
    disp('              number of variables.');
    disp('  RandSuites warning:  shifting to exact covariances across groups,');
    disp('              approximate covariances within groups.');
    exactCorrs = false;
  end;

  suites = makegrps((1:nSuites),vars)';           % Grouping vectors for variables and observations
  groups = makegrps((1:nGrps),grps);

  R = ones(nVars,nVars);                          % Fill in target correlation matrix
  for i = 1:(nVars-1)
    for j = (i+1):nVars
      if (suites(i)==suites(j))
        R(i,j) = wCorr;
        R(j,i) = wCorr;
      else
        R(i,j) = bCorr;
        R(j,i) = bCorr;
      end;
    end;
  end;

  X = zeros(nObs,nVars);                          % Allocate data matrix
  
  eObs = 0;                                         
  for i = 1:nGrps                                 % Adjust means and variances by group
    bObs = eObs + 1;                                % First and last obs in current group
    eObs = eObs + nObsPerGrp(i);
    X(bObs:eObs,:) = randmvn(nObsPerGrp(i),charMeans(i,:),charVars(i,:),R,exactCorrs);
  end;

  return;
