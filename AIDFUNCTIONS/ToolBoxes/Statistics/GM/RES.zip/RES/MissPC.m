% MissPC:  Estimates missing data by multiple regression on principal components
%          of complete data.  Requires at least 3 observations with complete data.
%          It is assumed that input data have already been log-transformed, if appropriate.
%
%     Usage: [Y,pMiss,failFlag] = MissPC(X,{useCorr})
%
%         X =         [n x p] matrix of original values, with missing data 
%                       indicated by non-finite values (NaN, Inf, -Inf).
%         useCorr =   optional boolean flag indicating, if true, that principal 
%                       components are to be estimated from the correlation 
%                       matrix [default = 0 = covariance matrix].
%         ---------------------------------------------------------------------------------
%         Y =         [n x p] matrix with missing data replaced by estimated 
%                       values.
%         pMiss =     proportion of missing values in original matrix.
%         failFlag =  boolean flag indicating, if true, that the estimation
%                       procedure couldn't be completed due to too much missing data.
%                       1 = too few complete observations for all variables;
%                       2 = too few complete observations for subset of complete variables.
%

% RE Strauss, 10/26/00 - modified for Matlab v5 from original function written by 
%                        Joao Alves de Oliveira for Matlab v4.
%   12/11/01 - added flag to suppress printing of warnings by pcacov() & pcacorr().
%   2/26/02 -  added failure flag.
%   3/3/02 -   added check for too few complete data.
%   10/1/02 -  modified output argument sequence of linregr().
%   10/8/02 -  modified output argument sequence of linregr().
%   10/9/02 -  copied and renamed from misspca().
%   10/30/02 - permit minimum number of complete vars for pca to be 1 rather than 2;
%              ignore cases of no missing vars in unique combinations.
%   11/18/02 - transposed 'scorescmpl' and 'scorespred' to allow for changes to linregr().
%   2/14/08 -  replace pcacov() by PcaCovar().
%   3/18/08 -  updated variable names, per convention; 
%              rewrote code dealing with 'combMiss'.

function [x,pMiss,failFlag] = MissPC(x,useCorr)
  if (nargin < 2), useCorr = []; end;

  if (isempty(useCorr)), useCorr = false; end;
  failFlag = 0;
  [nObs,nVars] = size(x);

  posMiss = (~isfinite(x));                 % Boolean positions of missing values
  nObsMiss = rowsum(posMiss);               % Numbers of missing values per obs
  uMissPerObs = unique(nObsMiss);           % Unique numbers of missing vals per obs

  if (sum(nObsMiss)==0)                     % If no missing data, return
    pMiss = 0;
    return;
  else
    pMiss = sum(nObsMiss)/(nObs*nVars);     % Proportion of missing data in matrix
  end;

  if (uMissPerObs(1)==0)
    uMissPerObs = uMissPerObs(2:end);
  end;

  for iun = 1:length(uMissPerObs)           % Cycle thru unique numbers of missing values per row
    if (~failFlag)
      iCmplObs = find(~nObsMiss);               % Row indices of complete obs
      
      xCmplObs = x(iCmplObs,:);                 % Isolate submatrix of complete obs
      lenCmplObs = length(iCmplObs);            % Number of complete obs
      if (lenCmplObs<3)
        failFlag = 1;
      end;
  
      iPred = find(nObsMiss==uMissPerObs(iun));	% Indices for obs to be predicted
      xPred = x(iPred,:);                       % Isolate current submatrix of incomplete data
  
      combMiss = bin2dec(bin2str(double(~isfinite(xPred))));  % Identify unique combinations with row values
      uCombMiss = unique(combMiss);                           %   of missing vars
      if (uCombMiss(1)==0)                      % Ignore cases of no missing vars
        uCombMiss = uCombMiss(2:end);
      end;
    
      for icm = 1:length(uCombMiss)             % Cycle thru combs of missing vars
        if (~failFlag)
          pos = find(combMiss==uCombMiss(icm));   % Obs having current combination
          posCmplVars = find(isfinite(xPred(pos(1),:)));   % List of complete vars
          incomplVars = 1:nVars;
          incomplVars(posCmplVars) = [];        	% List of incomplete vars
          xCmplVars = [xCmplObs(:,posCmplVars); xPred(pos,posCmplVars)]; % Complete submatrix for complete vars
          if (size(xCmplVars,1)<3 || rank(cov(xCmplVars))<1)
            failFlag = 2;
          end;
        
          if (~failFlag)
            if (useCorr)                            % PCA of this matrix
              [loadings,percvar,scores] = pcacorr(xCmplVars,nVars,[],[],[],[],1);
            else
              [loadings,percvar,scores] = PcaCovar(xCmplVars,nVars,[],[],[],[],1);
            end;
      
            scorescmpl = scores(1:lenCmplObs)';    	% Scores for complete obs
            scorespred = scores(lenCmplObs+1:size(xCmplVars,1))';  % Scores for incomplete obs
            [b,stats,predict] = linregr(scorescmpl,xCmplObs(:,incomplVars),[],scorespred);  % Predicted vars
            xPred(pos,incomplVars) = predict;     	% Plug these predicted values into matrix
          end;
        end;
      end;

      x(iPred,:) = xPred;                         % Stash all predicted values into matrix
      nObsMiss(iPred) = zeros(length(iPred),1);
    end;
  end;

  return;
