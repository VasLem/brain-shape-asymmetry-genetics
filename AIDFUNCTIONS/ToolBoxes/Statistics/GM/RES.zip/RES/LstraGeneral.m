% LstraGeneral: Generalized procrustes superimposition of multiple forms.
%
%     Usage: [consensus,stdCrds,rho] = LstraGeneral(crds,{forms},{regRot},{doPlot})
%
%         crds =      [n*k x p] 2D matrix or [n x p x k] 3D matrix of k point configurations 
%                       each having n points in p dimensions.
%         forms =     optional vector (length n*k) of form indentifiers, necessary if
%                       'crds' is passed as a 2D matrix.  If present, matches coordinates
%                       with forms.
%         regRot =    2-element vector indicating indices of landmarks for optional registration
%                       and rotation [default = nor registration/rotation].
%         doPlot =    optional boolean flag indicating, if true, that plots of the consensus
%                       and rescaled forms are to be produced for 2D forms [default = false].
%         --------------------------------------------------------------------------------------
%         consensus = [n x p] matrix of consensus form.
%         stdCrds =   [n x p x k] matrix of centered and scaled point configurations.
%         rho =       [k x 1] vector of scaling factors (sizes) for individual forms.
%                 

% Rohlf and Slice. 1990. Extensions of the Procrustes method for the optimal
%   superimposition of landmarks.  Syst. Zool. 39:40-59.

% RE Strauss, 8/9/05
%   12/1/05 - changed dimensions of 3D matrix from [nforms x npts x ndims] to 
%               [npts x ndims x nforms].
%   10/2/06 - added option for registration/rotation of forms.

function [consensus,stdCrds,rho] = LstraGeneral(crds,forms,regRot,doPlot)
  if (~nargin), help LstraGeneral; return; end;
  
  if (nargin < 2), forms = []; end;
  if (nargin < 3), regRot = []; end;
  if (nargin < 4), doPlot = []; end;
  
  if (isempty(doPlot)), doPlot = false; end;

  sizeCrds = size(crds);
  nDims = length(sizeCrds);
  
  if (nDims==2)                        % Convert 2D format to 3D format
    if (isempty(forms))
      error('  LstraGeneral: form identifiers needed.');
    else
      [uForms,freq] = UniqueValues(forms);
      nForms = length(uForms);
      if (any(abs(freq(2:nForms)-freq(1:nForms-1)))>0)
        error('  LstraGeneral: all forms should have same number of landmarks.');
      end;
      nPts = freq(1);
      stdCrds = zeros(nPts,sizeCrds(2),nForms);
      for ifm = 1:nForms
        i = find(forms==uForms(ifm));
        stdCrds(:,:,ifm) = crds(i,:);
      end;
    end;
  else
    stdCrds = crds;
  end;
  
  nPts =   size(stdCrds,1);
  nDims =  size(stdCrds,2);
  nForms = size(stdCrds,3);
  
  if (~isempty(regRot))
    regRot = regRot(:)';
    if (length(regRot)~=2)
      error('  LstraGeneral: invalid registration or rotation landmarks.');
    end;
    if (max(regRot) > nPts)
      error('  LstraGeneral: invalid registration or rotation landmarks.');
    end;
  end;
 
  % Optionally register and rotate all forms to common orientation.
  % Translate the centroids of all forms to a common origin.
  % Scale each form by the square root of the sum of the squared distances
  % from the centroid.

  imp = eye(nPts) - ones(nPts,nPts)/nPts;
  for i = 1:nForms
    X = stdCrds(:,:,i);
    if (~isempty(regRot))
      X = RegisterRotate(regRot(1),regRot(2),X);
    end;
    centr = mean(X);
    X = X - ones(nPts,1)*centr;
    si = sqrt(trace(imp*X*X'*imp));
    stdCrds(:,:,i) = imp*X./si;
  end;
  
  % Set initial consensus form Y as X1.  Rotate each Xi to fit Y.
  % New consensus Y is mean of original X1 and rotated Xi.

  Y = stdCrds(:,:,1);
  for i = 2:nForms
    [con,stdCrds(:,:,i)] = lstra(Y,stdCrds(:,:,i),[],1,1,1);
  end;
  Y = MeanForm(stdCrds);                    % Updated consensus form
  
  sse = nForms*(1-trace(Y*Y'));             % Initial sse
  rho = ones(nForms,1);                     % Initial individual scale factors
  
  % Converge on rotations
  
  tol = 1e-4;
  maxiter = 100;
  sseUpdate = 0;
  
  iter = 0;
  while (abs(sse-sseUpdate)>tol && iter<maxiter)
    for i = 1:nForms                        % Rotate and scale forms to consensus
      X = stdCrds(:,:,i);
      [U,sigma,V] = svd(Y'*X);
      S = sign(sigma);
      H = V*S*U';
      stdCrds(:,:,i) = rho(i)*X*H;
    end;
    Y = MeanForm(stdCrds);                  % Updated consensus estimate
    
    for i = 1:nForms                        % Rescale so that sum(tr(X*X'))= nForms
      X = stdCrds(:,:,i);
      rhoRatio = sqrt(trace(X*Y')/trace(X*X')/trace(Y*Y'));
      stdCrds(:,:,i) = rhoRatio*X;
      rho(i) = rhoRatio*rho(i);
    end;
    Y = MeanForm(stdCrds);                  % Updated consensus estimate
    sseUpdate = nForms*(1-trace(Y*Y'));     % Updated sse
    iter = iter + 1;
  end;
  consensus = Y;
  
  if (doPlot && nDims==2)
    figure;
    hold on;
    plot(consensus(:,1),consensus(:,2),'ko',consensus(:,1),consensus(:,2),'kx');
    for i = 1:nForms
      X = stdCrds(:,:,i);
      plot(X(:,1),X(:,2),'k.');
    end;
    hold off;
    axis off;
    axis equal;
    putwhite;
  end;
  
  return;
  
% ---------------------------------------------------------------------------------  
  
function form = MeanForm(stdCrds)
  form = mean(stdCrds,3);
  return;
  
