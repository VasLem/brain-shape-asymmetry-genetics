% richnessdiff: Uses within-group bootstrap sampling to test for significant non-zero
%     differences in "richness" (number of unique objects, such as species or alleles)
%     between pairs of samples.  Constructs a randomized distribution of richness differences.
%     The smaller area of the resulting sampling distribution lying to one side of zero is
%     doubled to yield a 2-tailed P-value.
%
%     [d,prob,s2d,ci] = richnessdiff(objects,grps,{iter},{hold_size},{ci_level})
%
%         objects =   vector of numeric object values.
%         grps =      corresponding vector of group identifications for k groups.
%         iter =      optional number of iterations for bootstrapped confidence 
%                       interval and probability [default = 1000].
%         hold_size = optional boolean flag indicating, if true, that each pairwise group
%                       comparison is to be done using the smaller sample size for each.
%         ci_level =  optional confidence level for interval [default = 0.95].
%         ------------------------------------------------------------------------------------
%         diff =      [k x k] symmetric matrix of observed differences in richness abs(r1-r2),
%                       or scalar for two groups.
%         prob =      corresponding matrix of 2-tailed probabilites under the null hypothesis 
%                       that delta=0.
%         s2d =       corresponding matrix of sampling variances of the differences.
%         ci =        corresponding matrix of lower (lower triangular entries) and upper (upper
%                       triangular entries) confidence bounds, or [1 x 2] vector of two groups.
%

% Thomas, M.G., M.E. Weale, A.L. Jones, M. Richards, A. Smith, N. Redhead, A. Torroni, 
%   R. Scozzari, F. Gratrix, A. Tarekegn, J.F. Wilson, C. Capelli, N. Bradman, and B.D. Goldstein.
%   2002.  Founding mothers of Jewish communities: geographically separated Jewish groups were 
%   independently founded by very few female ancestors.  Am. J. Hum. Genet. 70:1411-1420.

% RE Strauss, 2/26/06

function [diff,prob,s2d,ci] = richnessdiff(objects,grps,iter,hold_size,ci_level)
  if (nargin < 3) iter = []; end;
  if (nargin < 4) hold_size = []; end;
  if (nargin < 5) ci_level = []; end;
  
  if (isempty(iter)) iter = 1000; end;
  if (isempty(ci_level)) ci_level = 0.95; end;
  if (isempty(hold_size)) hold_size = 0; end;
  
  if (ci_level > 1)
    ci_level = ci_level/100;
  end;
  
  i = find(isfinite(objects));            % Remove missing data
  objects = objects(i);
  grps = grps(i);
  
  [ugrps,fgrps] = uniquef(grps);
  ngrps = length(ugrps);
  
  diff = zeros(ngrps,ngrps);
  s2d = zeros(ngrps,ngrps);
  ci = zeros(ngrps,ngrps);
  prob = zeros(ngrps,ngrps);
  
  distrib = zeros(iter,1);
  
  for g1 = 1:(ngrps-1)                    % Cycle thru pairs of groups
    obs1 = find(grps==ugrps(g1));
    n1 = length(obs1);
    u1 = uniquef(objects(obs1));
    
    for g2 = (g1+1):ngrps
      obs2 = find(grps==ugrps(g2));
      n2 = length(obs2);
      u2 = uniquef(objects(obs2));
      
      d = abs(length(u1)-length(u2));
      diff(g1,g2) = d;
      diff(g2,g1) = d;
      
      min_size = min([n1,n2]);
      
      for it = 1:iter                           % Generate sampling distribution
        boot_obj1 = bootsamp(objects(obs1));    %   by within-sample bootstrap
        boot_obj2 = bootsamp(objects(obs2));
        if (hold_size)
          boot_obj1 = boot_obj1(1:min_size);
          boot_obj2 = boot_obj2(1:min_size);
        end;
        ru1 = uniquef(boot_obj1);
        ru2 = uniquef(boot_obj2);
        distrib(it) = length(ru1)-length(ru2);
      end;
      v = var(distrib);                         % Sampling variance
      s2d(g1,g2) = v;
      s2d(g2,g1) = v;
      
      c = bootci(distrib,d,[],ci_level);        % Confidence interval
      ci(g2,g1) = c(1);
      ci(g1,g2) = c(2);
      
      lt0 = sum(distrib<0);                     % Left-tail size
      gt0 = sum(distrib>0);                     % Right-tail size
      tot_nonzero = lt0+gt0;
      if (tot_nonzero>0)
        pr = 2*min([lt0,gt0])/(lt0+gt0);               % 2-tailed probability
      else
        pr = 1;
      end;
      if (pr < 1/iter)
        pr = 1/iter;
      end;
      prob(g1,g2) = pr;
      prob(g2,g1) = pr;
    end;
  end;
  
  if (ngrps==2)
    diff = d;
    prob = pr;
    s2d = v;
    ci = c(:)';
  end;

  return;
  
