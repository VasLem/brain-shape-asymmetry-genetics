% JaccardIndex: the Jaccard coefficient Sj, a pairwise measure of similarity between 
%     observations for binary variables (Jaccard 1908):
%         Sj = m11/(m11+m01+m10)
%     where m = number of matches or mismatches.  Takes into account only 1s present in 
%     at least one of two individuals, so that joint absences are ignored.  
%     A corresponding measure of distance is Dj = 1-Sj.
%
%     index = JaccardIndex(X,{useDistance})
%
%         X =     [n x p] binary data matrix for n observations and p variables.
%         ----------------------------------------------------------------------------
%         index = [n x n] similarity matrix.
%         useDistance = optional boolean flag indicating that the distance measure is 
%                 to be returned rather than the similarity measure [default = false].
%

% RE Strauss, 10/21/07

function index = JaccardIndex(X,useDistance)
  if (~nargin), help JaccardIndex; return; end;
  
  if (nargin < 2), useDistance = []; end;
  
  if (isempty(useDistance)), useDistance = false; end;

  nObs = size(X,1);
  index = ones(nObs,nObs);
  
  uVals = UniqueValues(X,1);
  if (length(uVals)~=2)
    error('  JaccardIndex: input matrix must be binary.');
  end;
  
  for i1 = 1:(nObs-1)
    v1 = X(i1,:);
    for i2 = (i1+1):nObs
      v2 = X(i2,:);
      a = sum(v1==uVals(2) & v1==v2);
      bc = sum(v1~=v2);
%       d = sum(v1==uVals(1) & v1==v2);
      index(i1,i2) = a/(a+bc);
      index(i2,i1) = index(i1,i2);
    end;
  end;
  
  if (useDistance)
    index = 1-index;
  end;

  return;
  
