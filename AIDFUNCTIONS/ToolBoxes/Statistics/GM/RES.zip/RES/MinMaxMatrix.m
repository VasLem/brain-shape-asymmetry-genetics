% MinMaxMatrix: finds the minima and maxima of a 1-, 2- or 3-dimensional matrix, 
%               returning both the values and the addresses.
%
%     Syntax: [minval,minaddr,maxval,maxaddr] = MinMaxMatrix(X)
%
%         X = 1-, 2- or 3-dimensional matrix.
%         ------------------------------------------------------------------------------
%         minval = minimum value within the matrix.
%         minaddr = [n x ndim] matrix containing the n addresses of the occurrences of
%                     the minimum value, where ndim is the dimensionality of the matrix.
%                     Returns a row vector if the minimum value is unique.
%         maxval = maximum value within the matrix.
%         maxaddr = [n x ndim] matrix containing the n addresses of the occurrences of
%                     the maximum value, where ndim is the dimensionality of the matrix.
%                     Returns a row vector if the minimum value is unique.
%

% RE Strauss, 8/14/05

function [minval,minaddr,maxval,maxaddr] = MinMaxMatrix(X)
  if (isvect(X))
    matsize = length(X);
    ndim = 1;
  else
    matsize = size(X);
    ndim = length(matsize);
  end;

  x = X(:);
  minval = min(x);
  maxval = max(x);
  
  minaddr = [];
  maxaddr = [];
  
  switch (ndim)
    case 1,
      minaddr = find(X==minval);
      maxaddr = find(X==maxval);
      
    case 2,
      [minaddr(:,1),minaddr(:,2)] = find(X==minval);
      [maxaddr(:,1),maxaddr(:,2)] = find(X==maxval);
      
    case 3,
      for i = 1:matsize(1)
        for j = 1:matsize(2)
          for k = 1:matsize(3)
            if (X(i,j,k)==minval)
              minaddr = [minaddr; i j k];
            end;
            if (X(i,j,k)==maxval)
              maxaddr = [maxaddr; i j k];
            end;
          end;
        end;
      end;
  end;

  return;
  